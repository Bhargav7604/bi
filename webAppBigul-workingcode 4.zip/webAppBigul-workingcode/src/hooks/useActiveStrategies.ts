/**
 * Shared hook for fetching active strategies
 * Prevents duplicate API calls by using a singleton pattern
 */

import { useState, useEffect, useCallback, useRef } from "react"
import { strategyService } from "@/lib/api/strategy.service"
import { useAuthStore } from "@/store/auth.store"
import type { ActiveStrategy } from "@/lib/api/types"

// Global state to prevent duplicate calls
let activeStrategiesCache: ActiveStrategy[] | null = null
let activeStrategiesPromise: Promise<ActiveStrategy[]> | null = null
let lastFetchTime = 0
const CACHE_DURATION = 30000 // 30 seconds cache

export const useActiveStrategies = () => {
  const [activeStrategies, setActiveStrategies] = useState<ActiveStrategy[]>(activeStrategiesCache || [])
  const [loading, setLoading] = useState(false)
  const { userId } = useAuthStore()
  const hasFetchedRef = useRef(false)

  const fetchActiveStrategies = useCallback(async () => {
    if (!userId) {
      return
    }

    // If we have cached data and it's recent, use it
    const now = Date.now()
    if (activeStrategiesCache && (now - lastFetchTime) < CACHE_DURATION) {
      setActiveStrategies(activeStrategiesCache)
      return
    }

    // If there's already a pending request, wait for it
    if (activeStrategiesPromise) {
      try {
        const cached = await activeStrategiesPromise
        setActiveStrategies(cached)
        return
      } catch (error) {
        // If the promise fails, continue to make a new request
        activeStrategiesPromise = null
      }
    }

    // Prevent duplicate calls
    if (hasFetchedRef.current && activeStrategiesPromise) {
      return
    }

    hasFetchedRef.current = true
    setLoading(true)

    try {
      // Create a promise that can be shared
      activeStrategiesPromise = (async () => {
        const response = await strategyService.getActiveStrategies(userId)
        
        if (response.success && response.data) {
          const responseData = response.data as any
          let strategiesData: ActiveStrategy[] = []
          
          if (responseData?.data?.activeStrategiesResponse) {
            strategiesData = responseData.data.activeStrategiesResponse
          } else if (responseData?.activeStrategiesResponse) {
            strategiesData = responseData.activeStrategiesResponse
          }
          
          // Update cache
          activeStrategiesCache = strategiesData
          lastFetchTime = Date.now()
          
          return strategiesData
        }
        
        return []
      })()

      const strategiesData = await activeStrategiesPromise
      setActiveStrategies(strategiesData)
      activeStrategiesPromise = null
      hasFetchedRef.current = false
    } catch (err) {
      console.error("❌ Failed to fetch active strategies:", err)
      activeStrategiesPromise = null
      hasFetchedRef.current = false
    } finally {
      setLoading(false)
    }
  }, [userId])

  // Track which userId we've fetched for
  const fetchedUserIdRef = useRef<string | null>(null)

  useEffect(() => {
    // Only fetch if userId changed or not fetched yet
    if (userId && fetchedUserIdRef.current !== userId) {
      fetchedUserIdRef.current = userId
      fetchActiveStrategies()
    } else if (!userId) {
      // Clear when userId is removed
      fetchedUserIdRef.current = null
      activeStrategiesCache = null
      activeStrategiesPromise = null
      lastFetchTime = 0
      hasFetchedRef.current = false
      setActiveStrategies([])
    }
  }, [userId]) // Only depend on userId, not fetchActiveStrategies

  const refetch = useCallback(() => {
    hasFetchedRef.current = false
    activeStrategiesCache = null
    activeStrategiesPromise = null
    lastFetchTime = 0
    fetchActiveStrategies()
  }, [fetchActiveStrategies])

  return {
    activeStrategies,
    loading,
    refetch,
  }
}

