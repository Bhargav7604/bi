/**
 * Authentication Hook
 * React hook for managing authentication API calls
 */

import { useState, useCallback } from "react"
import { authService } from "@/lib/api/auth.service"
import { strategyService } from "@/lib/api/strategy.service"
import { useAuthStore } from "@/store/auth.store"
import type { CheckTokenResponse, UserDetailsResponse, ActiveStrategyResponse } from "@/lib/api/types"

interface UseAuthReturn {
  checkToken: (token: string, xtsToken: string) => Promise<void>
  getUserDetails: (clientId: string) => Promise<void>
  getActiveStrategies: (userId: string | number) => Promise<void>
  loading: boolean
  error: string | null
  userDetails: UserDetailsResponse | null
  checkResult: CheckTokenResponse | null
  activeStrategies: ActiveStrategyResponse | null
  clearAuth: () => void
  isAuthenticated: boolean
}

/**
 * Hook for authentication operations
 */
export const useAuth = (): UseAuthReturn => {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [userDetails, setUserDetails] = useState<UserDetailsResponse | null>(null)
  const [checkResult, setCheckResult] = useState<CheckTokenResponse | null>(null)
  const [activeStrategies, setActiveStrategies] = useState<ActiveStrategyResponse | null>(null)

  const { isAuthenticated, clearAuth: clearAuthStore } = useAuthStore()

  const checkToken = useCallback(async (token: string, xtsToken: string) => {
    setLoading(true)
    setError(null)
    setCheckResult(null)

    try {
      const response = await authService.checkToken(token, xtsToken)

      if (response.success && response.data) {
        setCheckResult(response.data)
      } else {
        setError(response.error?.message || "Failed to check token")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unexpected error occurred")
    } finally {
      setLoading(false)
    }
  }, [])

  const getUserDetails = useCallback(async (clientId: string) => {
    setLoading(true)
    setError(null)
    setUserDetails(null)

    try {
      const response = await authService.getUserDetails(clientId)

      if (response.success && response.data) {
        setUserDetails(response.data)
      } else {
        setError(response.error?.message || "Failed to get user details")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unexpected error occurred")
    } finally {
      setLoading(false)
    }
  }, [])

  const getActiveStrategies = useCallback(async (userId: string | number) => {
    setLoading(true)
    setError(null)
    setActiveStrategies(null)

    try {
      const response = await strategyService.getActiveStrategies(userId)

      if (response.success && response.data) {
        setActiveStrategies(response.data)
      } else {
        setError(response.error?.message || "Failed to get active strategies")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unexpected error occurred")
    } finally {
      setLoading(false)
    }
  }, [])

  const clearAuth = useCallback(() => {
    clearAuthStore()
    setUserDetails(null)
    setCheckResult(null)
    setActiveStrategies(null)
    setError(null)
  }, [clearAuthStore])

  return {
    checkToken,
    getUserDetails,
    getActiveStrategies,
    loading,
    error,
    userDetails,
    checkResult,
    activeStrategies,
    clearAuth,
    isAuthenticated,
  }
}

export default useAuth
