import { Routes, Route } from "react-router-dom"
import { lazy, Suspense } from "react"
import { AuthProvider } from "./components/AuthProvider"
import { ThemeProvider } from "@components/theme-provider"
import ProtectedRoute from "./components/ProtectedRoute"
import { ErrorBoundary } from "./components/ErrorBoundary"
import { Toaster } from "@components/ui/sonner"
import { Loader2 } from "lucide-react"

// Code splitting - lazy load pages for better performance
const HomePage = lazy(() => import("./pages/HomePage"))
const DiscoverStrategyPage = lazy(() => import("./pages/DiscoverStrategyPage"))
const CreateStrategyPage = lazy(() => import("./pages/CreateStrategyPage"))
const MyStrategyPage = lazy(() => import("./pages/MyStrategyPage"))
const PerformancePage = lazy(() => import("./pages/PerformancePage"))
const ProfilePage = lazy(() => import("./pages/ProfilePage"))
const BacktestResultsPage = lazy(() => import("./pages/BacktestResultsPage"))
const NotFoundPage = lazy(() => import("./pages/NotFoundPage"))

// Loading fallback component
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center bg-[#F5F5F5] dark:bg-gray-950">
    <div className="flex flex-col items-center gap-3">
      <Loader2 className="w-8 h-8 animate-spin text-[#5266FC] dark:text-blue-400" />
      <p className="text-gray-500 dark:text-gray-400 text-sm">Loading...</p>
    </div>
  </div>
)

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <AuthProvider>
          <Suspense fallback={<PageLoader />}>
            <Routes>
              {/* Public route - home page */}
              <Route path="/" element={<ProtectedRoute requireAuth={false}><HomePage /></ProtectedRoute>} />
              
              {/* Protected routes - require authentication */}
              <Route path="/discover" element={<ProtectedRoute><DiscoverStrategyPage /></ProtectedRoute>} />
              <Route path="/create-strategy" element={<ProtectedRoute><CreateStrategyPage /></ProtectedRoute>} />
              <Route path="/my-strategy" element={<ProtectedRoute><MyStrategyPage /></ProtectedRoute>} />
              <Route path="/performance" element={<ProtectedRoute><PerformancePage /></ProtectedRoute>} />
              <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
              <Route path="/backtest-results" element={<ProtectedRoute><BacktestResultsPage /></ProtectedRoute>} />
              
              {/* 404 page */}
              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </Suspense>
          <Toaster />
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  )
}
