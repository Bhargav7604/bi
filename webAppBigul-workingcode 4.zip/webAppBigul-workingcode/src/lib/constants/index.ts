/**
 * Application Constants
 * Centralized constants to avoid magic strings and hardcoded values
 */

/**
 * Query parameter names for URL-based authentication
 */
export const QUERY_PARAMS = {
  TOKEN: "token",
  XTS_TOKEN: "xtsToken",
} as const

/**
 * JWT Token field names
 */
export const JWT_FIELDS = {
  UNIQUE_NAME: "unique_name",
  LOGIN_ID: "LoginId",
  USER_ID: "userId",
  USER_ID_ALT: "userID",
} as const

/**
 * Storage keys
 */
export const STORAGE_KEYS = {
  AUTH: "auth-storage",
} as const

/**
 * Error messages
 */
export const ERROR_MESSAGES = {
  NO_TOKEN: "No authentication token found. Please authenticate first.",
  NO_TOKEN_CHECK: "No authentication token found. Please check token first.",
  TOKEN_CHECK_FAILED: "Token check failed",
  AUTH_INIT_ERROR: "Authentication initialization error",
  AUTH_VERIFICATION_ERROR: "Auth verification error",
  NETWORK_ERROR: "Network error occurred",
  FAILED_TO_DECODE_JWT: "Failed to decode JWT",
  INVALID_TOKEN: "Invalid token format",
} as const

/**
 * Loading messages
 */
export const LOADING_MESSAGES = {
  INITIALIZING_AUTH: "Initializing authentication...",
} as const

