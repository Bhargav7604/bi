/**
 * API Configuration
 * Centralized configuration for API endpoints and settings
 * Uses environment variables for base URL and origin
 */

import { ENV } from "@/lib/config/env"

export const API_CONFIG = {
  BASE_URL: ENV.API_BASE_URL,
  ENDPOINTS: {
    AUTH: {
      CHECK: "/ql/auth/check",
      USER_DETAILS: "/ql/auth/userDetails",
      WELCOME: "/ql/auth/welcome",
      SAVE_PROFILE: "/ql/auth/saveProfile",
    },
    STRATEGY: {
      ACTIVE: "/ql/strategy/v2/active",
      TO_FORWARD_TEST: "/ql/strategy/v2/toForwardTest",
      TO_LIVE_TRADING: "/ql/strategy/v2/toLiveTrading",
      EXIT_ALL: "/ql/strategy/exitall",
      READY_TO_DEPLOY: "/ql/strategy/v2/readytodeploy",
      ONE_CLICK_DEPLOY: "/ql/strategy/v2/oneclickdeploy",
      UNDEPLOY: "/ql/strategy/v2/undeploy",
      DETAILS: "/ql/strategy/v2/details",
      CHANGE_MULTIPLIER: "/ql/strategy/v2/changemultiplier",
      STANDBY: "/ql/strategy/v2/standby",
      EXIT_STRATEGY: "/ql/strategy/v2/exitstrategy",
      EDIT_STRATEGY: "/ql/strategy/v2/editstrategy",
      LOGS: "/ql/strategy/logs/today",
    },
    ORDER: {
      CUSTOM_ORDERS: "/ql/order/custom-orders",
    },
    REPORTS: {
      ALL: "/ql/reports/all",
      STRATEGY_REPORTS: "/ql/reports/strategyreports",
      DEFAULT_STRATEGY: "/ql/reports/default/strategy",
    },
    STATISTICS: {
      GET: "/ql/statistics",
    },
    ERROR_MANAGEMENT: {
      MANUALLY_TRADED: "/ql/errormanagement/v2/manuallytraded",
      RETRY: "/ql/errormanagement/v2/retry",
      CANCELLED: "/ql/errormanagement/v2/cancelled",
    },
    DIY: {
      DROPDOWNS: "/ql/diy/dropdowns",
      SAVE: "/ql/diy/save",
    },
  },
  HEADERS: {
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9,te;q=0.8",
    "Content-Type": "application/json",
    "Connection": "keep-alive",
    "Origin": ENV.ORIGIN_URL,
    "Referer": `${ENV.ORIGIN_URL}/`,
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
  },
} as const

export default API_CONFIG

