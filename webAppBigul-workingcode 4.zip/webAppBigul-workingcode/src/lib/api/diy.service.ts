/**
 * DIY API Service
 * Handles DIY (Do It Yourself) strategy related API calls
 */

import { get } from "./client"
import { API_CONFIG } from "./config"
import { useAuthStore } from "@/store/auth.store"
import { ERROR_MESSAGES } from "@/lib/constants"
import { logger } from "@/lib/utils/logger"
import type {
  DropdownsResponse,
  ApiResponse,
} from "./types"

/**
 * Get DIY dropdowns
 * GET /ql/diy/dropdowns
 * 
 * @returns Promise with dropdowns response
 */
export const getDropdowns = async (): Promise<ApiResponse<DropdownsResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 DIYService: Getting dropdowns")
    
    const response = await get<DropdownsResponse>(
      API_CONFIG.ENDPOINTS.DIY.DROPDOWNS
    )

    console.log("📡 DIYService: Dropdowns response:", response)
    return response
  } catch (error) {
    logger.error("Failed to get dropdowns", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to get dropdowns",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

// Export all DIY service functions
export const diyService = {
  getDropdowns,
}

export default diyService

