/**
 * Strategy API Service
 * Handles all strategy-related API calls
 */

import { get, post } from "./client"
import { API_CONFIG } from "./config"
import { useAuthStore } from "@/store/auth.store"
import { ERROR_MESSAGES } from "@/lib/constants"
import { logger } from "@/lib/utils/logger"
import { getClientIdFromToken, decodeJWT } from "@/lib/utils/jwt"
import type {
  ActiveStrategyParams,
  ActiveStrategyResponse,
  StrategyActionResponse,
  ExitAllParams,
  ExitAllResponse,
  ReadyToDeployParams,
  ReadyToDeployResponse,
  OneClickDeployRequest,
  OneClickDeployResponse,
  UndeployResponse,
  ChangeMultiplierRequest,
  ChangeMultiplierResponse,
  CustomOrdersRequest,
  CustomOrdersResponse,
  StandbyResponse,
  ExitStrategyRequest,
  ExitStrategyResponse,
  EditStrategyParams,
  EditStrategyResponse,
  LogsParams,
  LogsResponse,
  SaveDIYStrategyRequest,
  SaveDIYStrategyResponse,
  ApiResponse,
} from "./types"

/**
 * Get active strategies
 * GET /ql/strategy/v2/active?UserId={UserId}
 * 
 * Matches curl: GET with UserId as query parameter
 * 
 * @param userId - User ID (must be provided, not hardcoded)
 * @returns Promise with active strategy response
 */
export const getActiveStrategies = async (
  userId: string | number
): Promise<ApiResponse<ActiveStrategyResponse>> => {
  const params: ActiveStrategyParams = {
    UserId: userId,
  }

  try {
    // Verify token exists before making request
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 StrategyService: Making API call to:", API_CONFIG.ENDPOINTS.STRATEGY.ACTIVE)
    console.log("📡 StrategyService: With params:", params)
    console.log("📡 StrategyService: Full URL will be:", `${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS.STRATEGY.ACTIVE}?UserId=${userId}`)

    const response = await get<ActiveStrategyResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.ACTIVE,
      params as unknown as Record<string, string | number>
    )

    console.log("📡 StrategyService: API Response received:", response)

    return response
  } catch (error) {
    logger.error("Failed to get active strategies", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to get active strategies",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Switch strategy to Forward Test mode
 * POST /ql/strategy/v2/toForwardTest?strategyId={strategyId}
 * 
 * @param strategyId - Strategy ID to switch to forward test
 * @returns Promise with action response
 */
export const switchToForwardTest = async (
  strategyId: string | number
): Promise<ApiResponse<StrategyActionResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 StrategyService: Switching to Forward Test, strategyId:", strategyId)
    
    const response = await post<StrategyActionResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.TO_FORWARD_TEST,
      {}, // Empty body as per curl
      { strategyId } // Query parameter
    )

    console.log("📡 StrategyService: Switch to Forward Test response:", response)

    return response
  } catch (error) {
    logger.error("Failed to switch strategy to forward test", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to switch strategy to forward test",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Switch strategy to Live Trading mode
 * POST /ql/strategy/v2/toLiveTrading?strategyId={strategyId}
 * 
 * @param strategyId - Strategy ID to switch to live trading
 * @returns Promise with action response
 */
export const switchToLiveTrading = async (
  strategyId: string | number
): Promise<ApiResponse<StrategyActionResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 StrategyService: Switching to Live Trading, strategyId:", strategyId)
    
    const response = await post<StrategyActionResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.TO_LIVE_TRADING,
      {}, // Empty body as per curl
      { strategyId } // Query parameter
    )

    console.log("📡 StrategyService: Live Trading response:", response)
    return response
  } catch (error) {
    logger.error("Failed to switch to live trading", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to switch to live trading",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Exit all strategies
 * POST /ql/strategy/exitall
 * Body: { "userId": "..." }
 * 
 * @param userId - User ID to exit all strategies for
 * @returns Promise with exit all response
 */
export const exitAllStrategies = async (
  userId: string | number
): Promise<ApiResponse<ExitAllResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 StrategyService: Exiting all strategies for userId:", userId)
    
    const body: ExitAllParams = {
      userId: userId,
    }

    const response = await post<ExitAllResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.EXIT_ALL,
      body
    )

    console.log("📡 StrategyService: Exit all strategies response:", response)

    return response
  } catch (error) {
    logger.error("Failed to exit all strategies", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to exit all strategies",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Get ready to deploy strategies
 * GET /ql/strategy/v2/readytodeploy?category={category}
 * 
 * @param category - Strategy category (e.g., "inhouse")
 * @returns Promise with ready to deploy strategies response
 */
export const getReadyToDeployStrategies = async (
  category: string
): Promise<ApiResponse<ReadyToDeployResponse>> => {
  const params: ReadyToDeployParams = {
    category,
  }

  try {
    // Verify token exists before making request
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 StrategyService: Making API call to:", API_CONFIG.ENDPOINTS.STRATEGY.READY_TO_DEPLOY)
    console.log("📡 StrategyService: With params:", params)
    console.log("📡 StrategyService: Full URL will be:", `${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS.STRATEGY.READY_TO_DEPLOY}?category=${category}`)

    const response = await get<ReadyToDeployResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.READY_TO_DEPLOY,
      params as unknown as Record<string, string | number>
    )

    console.log("📡 StrategyService: Ready to deploy strategies response received:", response)

    return response
  } catch (error) {
    logger.error("Failed to get ready to deploy strategies", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to get ready to deploy strategies",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * One click deploy strategy
 * POST /ql/strategy/v2/oneclickdeploy
 * Body: { strategyId, multiplier, executionTypeId }
 * 
 * Matches curl: POST with token and clientid headers
 * 
 * @param request - One click deploy request parameters
 * @returns Promise with deploy response
 */
export const oneClickDeploy = async (
  request: OneClickDeployRequest
): Promise<ApiResponse<OneClickDeployResponse>> => {
  try {
    // Verify token exists before making request
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    // Extract clientId from token with multiple fallback methods
    let clientId = getClientIdFromToken(token)
    
    // If clientId not found, try decoding token directly and checking multiple fields
    if (!clientId) {
      logger.warn("ClientId not found via getClientIdFromToken, attempting direct decode")
      const decoded = decodeJWT(token)
      
      if (decoded) {
        console.log("Decoded token for clientId extraction:", decoded)
        
        // Try multiple possible fields that might contain clientId
        const possibleClientId = 
          (decoded.unique_name as string) || 
          (decoded.LoginId as string) || 
          (decoded.loginId as string) ||
          (decoded["unique_name"] as string) ||
          (decoded["LoginId"] as string) ||
          (decoded.clientId as string) ||
          (decoded["clientId"] as string) ||
          (decoded.client_id as string) ||
          (decoded["client_id"] as string) ||
          null
        
        if (possibleClientId && typeof possibleClientId === "string") {
          clientId = possibleClientId
        }
        
        if (clientId) {
          logger.info("ClientId found via direct token decode:", clientId)
        }
      }
    }
    
    // If still no clientId, try to get it from checkToken response if available
    if (!clientId) {
      logger.warn("ClientId still not found, attempting to get from checkToken response")
      try {
        // Try to call checkToken to get clientId from response
        const { checkToken } = await import("@/lib/api/auth.service")
        const xtsToken = useAuthStore.getState().xtsToken
        if (xtsToken) {
          const checkResponse = await checkToken(token, xtsToken)
          if (checkResponse.success && checkResponse.data?.clientId) {
            const responseClientId = checkResponse.data.clientId
            if (typeof responseClientId === "string") {
              clientId = responseClientId
              logger.info("ClientId found from checkToken response:", clientId)
            }
          }
        }
      } catch (error) {
        logger.warn("Failed to get clientId from checkToken:", error)
      }
    }
    
    if (!clientId) {
      logger.error("ClientId not found in token after all attempts")
      console.error("Token decode attempt failed. Decoded token:", decodeJWT(token))
      return {
        success: false,
        error: {
          message: "ClientId not found in token. Please ensure you are properly authenticated.",
        },
      }
    }

    console.log("📡 StrategyService: Making one click deploy API call")
    console.log("📡 StrategyService: Request body:", request)
    console.log("📡 StrategyService: ClientId:", clientId)

    // Build custom headers matching the curl request
    // The API expects 'token' header (not Authorization Bearer) and 'clientid' header
    const customHeaders: Record<string, string> = {
      "token": token,
      "clientid": clientId,
      "accept": "application/json, text/plain, */*",
      "accept-language": "en-US,en;q=0.9,en-IN;q=0.8",
    }

    const response = await post<OneClickDeployResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.ONE_CLICK_DEPLOY,
      request,
      undefined, // no query params
      customHeaders
    )

    console.log("📡 StrategyService: One click deploy response:", response)

    return response
  } catch (error) {
    logger.error("Failed to deploy strategy", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to deploy strategy",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Undeploy strategy
 * POST /ql/strategy/v2/undeploy?strategyId={strategyId}
 * Body: {}
 * 
 * Matches curl: POST with strategyId as query parameter and empty body
 * 
 * @param strategyId - Strategy ID to undeploy
 * @returns Promise with undeploy response
 */
export const undeployStrategy = async (
  strategyId: number
): Promise<ApiResponse<UndeployResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 StrategyService: Making undeploy API call for strategyId:", strategyId)
    const response = await post<UndeployResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.UNDEPLOY,
      {}, // Empty body as per curl
      { strategyId } // Query parameter
    )

    console.log("📡 StrategyService: Undeploy response:", response)
    return response
  } catch (error) {
    logger.error("Failed to undeploy strategy", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to undeploy strategy",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Change multiplier for a strategy
 * POST /ql/strategy/v2/changemultiplier
 * Body: { strategyId, multiplier, executionTypeId }
 * 
 * @param request - Change multiplier request parameters
 * @returns Promise with change multiplier response
 */
export const changeMultiplier = async (
  request: ChangeMultiplierRequest
): Promise<ApiResponse<ChangeMultiplierResponse>> => {
  try {
    // Verify token exists before making request
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 StrategyService: Making change multiplier API call")
    console.log("📡 StrategyService: Request body:", request)

    const response = await post<ChangeMultiplierResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.CHANGE_MULTIPLIER,
      request
    )

    console.log("📡 StrategyService: Change multiplier response:", response)

    return response
  } catch (error) {
    logger.error("Failed to change multiplier", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to change multiplier",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Get custom orders for a specific date
 * POST /ql/order/custom-orders
 * Body: { customDate: "2025-12-04T00:00:00.000Z" }
 * 
 * @param request - Custom orders request with date
 * @returns Promise with custom orders response
 */
export const getCustomOrders = async (
  request: CustomOrdersRequest
): Promise<ApiResponse<CustomOrdersResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 StrategyService: Making custom orders API call with date:", request.customDate)
    const response = await post<CustomOrdersResponse>(
      API_CONFIG.ENDPOINTS.ORDER.CUSTOM_ORDERS,
      request
    )

    console.log("📡 StrategyService: Custom orders response:", response)
    return response
  } catch (error) {
    logger.error("Failed to get custom orders", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to get custom orders",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Set strategy to standby
 * POST /ql/strategy/v2/standby?strategyId={strategyId}
 * 
 * @param strategyId - Strategy ID to set to standby
 * @returns Promise with standby response
 */
export const setStandby = async (
  strategyId: number
): Promise<ApiResponse<StandbyResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 StrategyService: Setting strategy to standby, strategyId:", strategyId)
    
    const response = await post<StandbyResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.STANDBY,
      {}, // Empty body as per curl
      { strategyId } // Query parameter
    )

    console.log("📡 StrategyService: Standby response:", response)
    return response
  } catch (error) {
    logger.error("Failed to set strategy to standby", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to set strategy to standby",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Exit a specific strategy
 * POST /ql/strategy/v2/exitstrategy
 * Body: { strategyId, signalId }
 * 
 * @param request - Exit strategy request parameters
 * @returns Promise with exit strategy response
 */
export const exitStrategy = async (
  request: ExitStrategyRequest
): Promise<ApiResponse<ExitStrategyResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 StrategyService: Exiting strategy:", request)
    
    const response = await post<ExitStrategyResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.EXIT_STRATEGY,
      request
    )

    console.log("📡 StrategyService: Exit strategy response:", response)
    return response
  } catch (error) {
    logger.error("Failed to exit strategy", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to exit strategy",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Edit strategy (get strategy data for editing)
 * GET /ql/strategy/v2/editstrategy?strategyId={strategyId}
 * 
 * @param params - Edit strategy params with strategy ID
 * @returns Promise with edit strategy response
 */
export const getEditStrategy = async (
  params: EditStrategyParams
): Promise<ApiResponse<EditStrategyResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 StrategyService: Getting strategy for editing, strategyId:", params.strategyId)
    
    const response = await get<EditStrategyResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.EDIT_STRATEGY,
      params as unknown as Record<string, string | number>
    )

    console.log("📡 StrategyService: Edit strategy response:", response)
    return response
  } catch (error) {
    logger.error("Failed to get strategy for editing", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to get strategy for editing",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Get strategy logs for today
 * GET /ql/strategy/logs/today?strategyId={strategyId}
 * 
 * @param params - Logs params with strategy ID
 * @returns Promise with logs response
 */
export const getStrategyLogs = async (
  params: LogsParams
): Promise<ApiResponse<LogsResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 StrategyService: Getting strategy logs, strategyId:", params.strategyId)
    
    const response = await get<LogsResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.LOGS,
      params as unknown as Record<string, string | number>
    )

    console.log("📡 StrategyService: Strategy logs response:", response)
    return response
  } catch (error) {
    logger.error("Failed to get strategy logs", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to get strategy logs",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Save DIY Strategy
 * POST /ql/diy/save
 * Body: SaveDIYStrategyRequest
 * 
 * Matches curl: POST with token, clientId, mobileNumber headers
 * 
 * @param request - DIY strategy save request parameters
 * @param mobileNumber - Optional mobile number for header (if available)
 * @returns Promise with save response
 */
export const saveDIYStrategy = async (
  request: SaveDIYStrategyRequest,
  mobileNumber?: string
): Promise<ApiResponse<SaveDIYStrategyResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    // Extract clientId from token
    let clientId = getClientIdFromToken(token)
    
    // If clientId not found, try decoding token directly and checking multiple fields
    if (!clientId) {
      logger.warn("ClientId not found via getClientIdFromToken, attempting direct decode")
      const decoded = decodeJWT(token)
      
      if (decoded) {
        console.log("Decoded token for clientId extraction:", decoded)
        
        // Try multiple possible fields that might contain clientId
        const possibleClientId = 
          (decoded.unique_name as string) || 
          (decoded.LoginId as string) || 
          (decoded.loginId as string) ||
          (decoded["unique_name"] as string) ||
          (decoded["LoginId"] as string) ||
          (decoded.clientId as string) ||
          (decoded["clientId"] as string) ||
          (decoded.client_id as string) ||
          (decoded["client_id"] as string) ||
          null
        
        if (possibleClientId && typeof possibleClientId === "string") {
          clientId = possibleClientId
        }
        
        if (clientId) {
          logger.info("ClientId found via direct token decode:", clientId)
        }
      }
    }
    
    // If still no clientId, try to get it from checkToken response if available
    if (!clientId) {
      logger.warn("ClientId still not found, attempting to get from checkToken response")
      try {
        // Try to call checkToken to get clientId from response
        const { checkToken } = await import("@/lib/api/auth.service")
        const xtsToken = useAuthStore.getState().xtsToken
        if (xtsToken) {
          const checkResponse = await checkToken(token, xtsToken)
          if (checkResponse.success && checkResponse.data?.clientId) {
            const responseClientId = checkResponse.data.clientId
            if (typeof responseClientId === "string") {
              clientId = responseClientId
              logger.info("ClientId found from checkToken response:", clientId)
            }
          }
        }
      } catch (error) {
        logger.warn("Failed to get clientId from checkToken:", error)
      }
    }
    
    if (!clientId) {
      logger.error("ClientId not found in token after all attempts")
      console.error("Token decode attempt failed. Decoded token:", decodeJWT(token))
      return {
        success: false,
        error: {
          message: "ClientId not found in token. Please ensure you are properly authenticated.",
        },
      }
    }

    console.log("📡 StrategyService: Saving DIY strategy")
    console.log("📡 StrategyService: Request body:", request)
    console.log("📡 StrategyService: ClientId:", clientId)

    // Build custom headers matching the curl request
    const customHeaders: Record<string, string> = {
      "token": token,
      "clientId": clientId,
      "accept": "application/json, text/plain, */*",
      "accept-language": "en-US,en;q=0.9,en-IN;q=0.8",
    }

    // Add mobileNumber header if provided
    if (mobileNumber) {
      customHeaders["mobileNumber"] = mobileNumber
    }

    const response = await post<SaveDIYStrategyResponse>(
      API_CONFIG.ENDPOINTS.DIY.SAVE,
      request,
      undefined, // no query params
      customHeaders
    )

    console.log("📡 StrategyService: Save DIY strategy response:", response)

    return response
  } catch (error) {
    logger.error("Failed to save DIY strategy", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to save DIY strategy",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

// Export all strategy service functions
export const strategyService = {
  getActiveStrategies,
  switchToForwardTest,
  switchToLiveTrading,
  exitAllStrategies,
  getReadyToDeployStrategies,
  oneClickDeploy,
  undeployStrategy,
  changeMultiplier,
  getCustomOrders,
  setStandby,
  exitStrategy,
  getEditStrategy,
  getStrategyLogs,
  saveDIYStrategy,
}

export default strategyService

