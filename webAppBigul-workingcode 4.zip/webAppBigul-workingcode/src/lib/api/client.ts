/**
 * HTTP Client
 * Centralized HTTP client with error handling and token management
 */

import API_CONFIG from "./config"
import { useAuthStore } from "@/store/auth.store"
import type { ApiResponse, ApiError } from "./types"

/**
 * Custom error class for API errors
 */
export class ApiClientError extends Error {
  status?: number
  statusText?: string
  data?: unknown

  constructor(message: string, status?: number, statusText?: string, data?: unknown) {
    super(message)
    this.name = "ApiClientError"
    this.status = status
    this.statusText = statusText
    this.data = data
  }
}

/**
 * Build request headers with authentication
 */
const buildHeaders = (customHeaders?: Record<string, string>): HeadersInit => {
  const token = useAuthStore.getState().token
  const headers: HeadersInit = {
    ...API_CONFIG.HEADERS,
    ...customHeaders,
  }

  if (token) {
    headers["Authorization"] = `Bearer ${token}`
  }

  return headers
}

/**
 * Handle API response
 */
const handleResponse = async <T>(response: Response): Promise<ApiResponse<T>> => {
  const contentType = response.headers.get("content-type")
  const isJson = contentType?.includes("application/json")

  let data: T | unknown
  try {
    data = isJson ? await response.json() : await response.text()
  } catch (error) {
    data = null
  }

  if (!response.ok) {
    // Try to extract error message from response body
    let errorMessage = `API Error: ${response.statusText}`
    if (data && typeof data === "object") {
      const errorData = data as any
      if (errorData.message) {
        errorMessage = String(errorData.message)
      } else if (errorData.error) {
        if (typeof errorData.error === 'string') {
          errorMessage = errorData.error
        } else if (errorData.error?.message) {
          errorMessage = String(errorData.error.message)
        }
      } else if (errorData.errors) {
        if (typeof errorData.errors === 'string') {
          errorMessage = errorData.errors
        } else if (Array.isArray(errorData.errors) && errorData.errors.length > 0) {
          errorMessage = String(errorData.errors[0])
        }
      }
    }
    
    const error: ApiError = {
      message: errorMessage,
      status: response.status,
      statusText: response.statusText,
      data,
    }

    throw new ApiClientError(
      error.message,
      error.status,
      error.statusText,
      error.data
    )
  }

  // Handle API responses that already have success/status fields
  // The API response structure: { success: true, data: {...}, message: "...", ... }
  // We need to extract the inner data field and wrap it properly
  if (data && typeof data === "object" && "success" in data) {
    const apiResponse = data as { 
      success: boolean
      data?: unknown
      error?: unknown
      errors?: unknown
      message?: string
      status?: string
      [key: string]: unknown 
    }
    
    // Extract error message from various possible locations
    let errorMessage: string | undefined
    if (!apiResponse.success) {
      // Try to extract error message from different possible structures
      if (apiResponse.message) {
        errorMessage = String(apiResponse.message)
      } else if (apiResponse.error) {
        if (typeof apiResponse.error === 'string') {
          errorMessage = apiResponse.error
        } else if (typeof apiResponse.error === 'object' && apiResponse.error !== null) {
          const errorObj = apiResponse.error as any
          errorMessage = errorObj.message || errorObj.error || JSON.stringify(errorObj)
        }
      } else if (apiResponse.errors) {
        if (typeof apiResponse.errors === 'string') {
          errorMessage = apiResponse.errors
        } else if (Array.isArray(apiResponse.errors) && apiResponse.errors.length > 0) {
          errorMessage = String(apiResponse.errors[0])
        } else if (typeof apiResponse.errors === 'object') {
          errorMessage = JSON.stringify(apiResponse.errors)
        }
      }
    }
    
    // If the API response has a data field, use it as T
    // Otherwise, use the entire response as T (for responses that are already the expected type)
    return {
      success: apiResponse.success,
      data: (apiResponse.data ?? apiResponse) as T,
      error: errorMessage ? {
        message: errorMessage,
        status: response.status,
        statusText: response.statusText,
        data: apiResponse,
      } : undefined,
      message: apiResponse.message as string | undefined,
    }
  }

  return {
    success: true,
    data: data as T,
  }
}

/**
 * GET request
 */
export const get = async <T = unknown>(
  endpoint: string,
  params?: Record<string, string | number>,
  customHeaders?: Record<string, string>
): Promise<ApiResponse<T>> => {
  try {
    const url = new URL(`${API_CONFIG.BASE_URL}${endpoint}`)
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        url.searchParams.append(key, String(value))
      })
    }

    const response = await fetch(url.toString(), {
      method: "GET",
      headers: buildHeaders(customHeaders),
    })

    return handleResponse<T>(response)
  } catch (error) {
    if (error instanceof ApiClientError) {
      throw error
    }

    throw new ApiClientError(
      error instanceof Error ? error.message : "Network error occurred",
      0,
      "Network Error"
    )
  }
}

/**
 * POST request
 */
export const post = async <T = unknown>(
  endpoint: string,
  body?: unknown,
  params?: Record<string, string | number>,
  customHeaders?: Record<string, string>
): Promise<ApiResponse<T>> => {
  try {
    let url = `${API_CONFIG.BASE_URL}${endpoint}`
    
    // Add query parameters if provided
    if (params) {
      const urlObj = new URL(url)
      Object.entries(params).forEach(([key, value]) => {
        urlObj.searchParams.append(key, String(value))
      })
      url = urlObj.toString()
    }

    const response = await fetch(url, {
      method: "POST",
      headers: buildHeaders(customHeaders),
      body: body ? JSON.stringify(body) : undefined,
    })

    return handleResponse<T>(response)
  } catch (error) {
    if (error instanceof ApiClientError) {
      throw error
    }

    throw new ApiClientError(
      error instanceof Error ? error.message : "Network error occurred",
      0,
      "Network Error"
    )
  }
}

/**
 * PUT request
 */
export const put = async <T = unknown>(
  endpoint: string,
  body?: unknown,
  customHeaders?: Record<string, string>
): Promise<ApiResponse<T>> => {
  try {
    const response = await fetch(`${API_CONFIG.BASE_URL}${endpoint}`, {
      method: "PUT",
      headers: buildHeaders(customHeaders),
      body: body ? JSON.stringify(body) : undefined,
    })

    return handleResponse<T>(response)
  } catch (error) {
    if (error instanceof ApiClientError) {
      throw error
    }

    throw new ApiClientError(
      error instanceof Error ? error.message : "Network error occurred",
      0,
      "Network Error"
    )
  }
}

/**
 * DELETE request
 */
export const del = async <T = unknown>(
  endpoint: string,
  customHeaders?: Record<string, string>
): Promise<ApiResponse<T>> => {
  try {
    const response = await fetch(`${API_CONFIG.BASE_URL}${endpoint}`, {
      method: "DELETE",
      headers: buildHeaders(customHeaders),
    })

    return handleResponse<T>(response)
  } catch (error) {
    if (error instanceof ApiClientError) {
      throw error
    }

    throw new ApiClientError(
      error instanceof Error ? error.message : "Network error occurred",
      0,
      "Network Error"
    )
  }
}
