/**
 * API Types and Interfaces
 * TypeScript definitions for API requests and responses
 */

/**
 * JWT Token Payload Structure
 */
export interface JWTPayload {
  unique_name?: string
  LoginId?: string
  userId?: string | number
  userID?: string | number
  MiddleWare_Mapping?: string
  MiddleWare_JsonData?: string
  DeviceId?: string
  DeviceType?: string
  nbf?: number
  exp?: number
  iat?: number
  [key: string]: unknown
}

// Check API Types
export interface CheckTokenRequest {
  token: string
  xtsToken: string
}

export interface CheckTokenResponse {
  status?: string
  success: boolean
  message?: string
  data?: {
    userId?: number
    clientId?: string
    newUser?: boolean
    loggedInToday?: boolean
    isLive?: boolean
    bannerContent?: string | null
    [key: string]: unknown
  }
  errors?: unknown
  [key: string]: unknown
}

// User Details API Types
export interface UserDetailsParams {
  clientId: string
}

export interface UserDetailsResponse {
  success: boolean
  data?: {
    clientId?: string
    name?: string
    email?: string
    userId?: string | number
    [key: string]: unknown
  }
  message?: string
  [key: string]: unknown
}

// Welcome API Types
export interface WelcomeRequest {
  clientId: string
  termsConditions: boolean
}

export interface WelcomeResponse {
  success: boolean
  data?: unknown
  message?: string
  [key: string]: unknown
}

// Active Strategy API Types
export interface ActiveStrategyParams {
  UserId: string | number
}

export interface StrategyLegTableDTO {
  strategyId: string | null
  strategyStatus: string | null
  strategyMTM: number
  indexBasePrice: number | null
  indexCurrentPrice: number | null
  totalOrders: number
  openOrders: number
  closedOrders: number
  executionType: string | null
  positionType: string | null
  data: unknown | null
}

export interface ActiveStrategy {
  name: string
  deployedOn: string
  execution: string
  status: string
  capital: number
  multiplier: string
  counter: number
  signalId: string | null
  category: string
  requiredCapital: number
  positionType: string
  strategyMtm: number
  strategyLegTableDTO: StrategyLegTableDTO
  sid: number
}

export interface ExecutionTypeOption {
  key: string
  val: string
}

export interface MultiplierOption {
  key: number
  val: string
}

export interface ActiveStrategiesDropdown {
  executionType: ExecutionTypeOption[]
  multiplier: MultiplierOption[]
}

export interface ActiveStrategyData {
  activeStrategiesResponse: ActiveStrategy[]
  activeStrategiesDropdown: ActiveStrategiesDropdown
}

export interface ActiveStrategyResponse {
  status: string
  success: boolean
  message: string
  data: ActiveStrategyData
  errors: unknown | null
}

// Strategy Action API Types
export interface StrategyActionParams {
  strategyId: string | number
}

export interface StrategyActionResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

// Exit All API Types
export interface ExitAllParams {
  userId: string | number
}

export interface ExitAllResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

// Ready to Deploy API Types
export interface ReadyToDeployParams {
  category: string
}

export interface EntryDetails {
  entryTime?: number
  expiry?: string
  entryDaysList?: number[]
  entryHourTime?: number
  entryMinsTime?: number
  [key: string]: unknown
}

export interface ExitDetails {
  exitHourTime?: number
  exitMinsTime?: number
  targetUnitToggle?: string
  targetUnitType?: string
  targetUnitValue?: number
  stopLossUnitToggle?: string
  stopLossUnitType?: string
  stopLossUnitValue?: number
  exitOnExpiryFlag?: string
  exitAfterEntryDays?: number
  [key: string]: unknown
}

export interface ReadyToDeployStrategy {
  id: number
  name: string
  description: string
  entryDetails?: EntryDetails
  exitDetails?: ExitDetails
  atmType?: string
  multiplier?: number
  minCapital: number
  underlying?: string | number
  typeOfStrategy?: string | null
  positionType?: string
  executionType?: string
  createdAt?: number
  strategyTag?: string
  status?: string
  category?: string
  drawDown?: number | null
  subscription?: string
  strategyLegs?: unknown | null
  [key: string]: unknown
}

export interface ReadyToDeployStrategies {
  diy?: ReadyToDeployStrategy[]
  preBuilt?: ReadyToDeployStrategy[]
  popular?: ReadyToDeployStrategy[]
  inHouse?: ReadyToDeployStrategy[]
  [key: string]: ReadyToDeployStrategy[] | undefined
}

export interface ReadyToDeployData {
  strategies: ReadyToDeployStrategies
  dropdownList?: {
    atmType?: Array<{ key: string; val: string }>
    underlying?: Array<{ key: number; val: string }>
    order?: Array<{ key: string; val: string }>
    executionType?: Array<{ key: string; val: string }>
    expiry?: Array<{ key: string; val: string }>
    entryDays?: Array<{ key: number; val: string }>
    mtmType?: Array<{ key: string; val: string }>
    multiplier?: Array<{ key: number; val: string }>
    [key: string]: unknown
  }
  [key: string]: unknown
}

export interface ReadyToDeployResponse {
  status?: string
  success: boolean
  message?: string
  data?: ReadyToDeployData
  errors?: unknown | null
}

// One Click Deploy API Types
export interface OneClickDeployRequest {
  strategyId: number
  multiplier: number | string
  executionTypeId: string
  // Additional fields for customize deploy
  strategyType?: string
  underlying?: number
  expiryType?: string
  strikeSelection?: string
  positionType?: string
  entryDays?: number[]
  exitAfterEntry?: number
  exitOnExpiry?: string
  segmentType?: string
  order?: string
  profitMtm?: string
  tgt?: string
  trl?: string
  [key: string]: unknown
}

export interface OneClickDeployResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

// Undeploy API Types
export interface UndeployRequest {
  strategyId: number
}

export interface UndeployResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

// Change Multiplier API Types
export interface ChangeMultiplierRequest {
  strategyId: number
  multiplier: number
  executionTypeId: string
}

export interface ChangeMultiplierResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

// Custom Orders API Types
export interface CustomOrdersRequest {
  customDate: string // ISO date string like "2025-12-04T00:00:00.000Z"
}

export interface CustomOrder {
  dateTime: string | null
  symbol: string
  quantity: number
  price: number
  status: string
  orderId: number
  sno: string
  sname: string
}

export interface CustomOrdersResponse {
  status?: string
  success: boolean
  message?: string
  data?: CustomOrder[]
  errors?: unknown | null
}

// Reports API Types
export interface AllReportsRequest {
  // No parameters needed
}

export interface StrategyReportsRequest {
  fromDate?: string
  toDate?: string
  strategyId: number
}

export interface StrategyDetailsParams {
  strategyId: number
}

export interface ReportData {
  id: number
  strategyName: string
  pnl: number
}

export interface AllReportsResponse {
  status?: string
  success: boolean
  message?: string
  data?: {
    reports: ReportData[]
    totalPnl: number
  }
  errors?: unknown | null
}

export interface ReportsLegDto {
  legId: number
  signalId: number
  date: number
  exchange: string
  underlying: string | null
  quantity: number
  price: number
  sequentialPNL: number | null
  instrument: number
}

export interface ReportsSignalDto {
  signalId: number | null
  pnl: number
  pnlChange: number
  sequentialPNL: number
  orderCount: number | null
  date: string
  reportsLegDtoList: ReportsLegDto[]
}

export interface StrategyReportsResponse {
  status?: string
  success: boolean
  message?: string
  data?: {
    strategyName: string
    strategyID: number
    reportsSignalDTOs: ReportsSignalDto[]
    totalOrders: number | null
    totalPNL: number
  }
  errors?: unknown | null
}

export interface StrategyDetailsResponse {
  status?: string
  success: boolean
  message?: string
  data?: ReportData
  errors?: unknown | null
}

// Statistics API Types
export interface PerformanceOverview {
  winRatio: number
  winDays: number
  lossDays: number
}

export interface Statistic {
  name: string
  value: number | string
}

export interface WeekStatsSummary {
  day: string
  returns: number
  maxProfit: number
  maxLoss: number
}

export interface StatisticsIndexes {
  totalProfit: number
  maxDrawDown: number
  maxDrawDownPercent: number
  winRate: number
  lossRate: number
  capitalRequired: number
  totalTradingDays: number
  totalTrades: number | null
  avgTradesPerDay: number
  avgDailyProfit: number
  avgProfitOnWinDays: number
  avgLossOnLossDays: number
}

export interface ProfitStatistics {
  totalProfit: number
  monthlyAvg: number
  totalROI: number
}

export interface RiskMetrics {
  maxDrawDown: number
  sharpeRatio: number
  sortinoRatio: number
}

export interface StatisticsResponse {
  status?: string
  success: boolean
  message?: string
  data?: {
    performanceOverview: PerformanceOverview
    statistics: Statistic[]
    monthlyStatistics: any[]
    weekStatsSummary: WeekStatsSummary[]
    statisticsIndexes: StatisticsIndexes
    profitStatistics: ProfitStatistics
    riskMetrics: RiskMetrics
  }
  errors?: unknown | null
}

// Error Management API Types
export interface RetryRequest {
  strategyId: number
}

export interface RetryResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

export interface CancelledRequest {
  strategyId: number
}

export interface CancelledResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

// Strategy Management API Types
export interface StandbyRequest {
  strategyId: number
}

export interface StandbyResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

export interface ExitStrategyRequest {
  strategyId: number
  signalId?: number | null
}

export interface ExitStrategyResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

export interface EditStrategyParams {
  strategyId: number
}

export interface EditStrategyResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

export interface LogsParams {
  strategyId: number
}

export interface LogsResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

// DIY API Types
export interface DropdownsResponse {
  status?: string
  success: boolean
  message?: string
  data?: {
    atmType?: Array<{ key: string; val: string }>
    underlying?: Array<{ key: number; val: string }>
    order?: Array<{ key: string; val: string }>
    executionType?: Array<{ key: string; val: string }>
    expiry?: Array<{ key: string; val: string }>
    entryDays?: Array<{ key: number; val: string }>
    mtmType?: Array<{ key: string; val: string }>
    multiplier?: Array<{ key: number; val: string }>
    // Actual API response fields
    lot?: Array<{ key: number; val: string }>
    strategyType?: Array<{ key: string; val: string }>
    daysMenu?: Array<{ key: number; val: string }>
    segmentType?: Array<{ key: string; val: string }>
    profitMtm?: Array<{ key: string; val: string }>
    expiryType?: Array<{ key: string; val: string }>
    underlyingMenu?: Array<{ key: number; val: string }>
    strikeSelection?: Array<{ key: string; val: string }>
    strikeType?: Array<{ key: string; val: string }>
    exitAfterEntry?: Array<{ key: number; val: string }>
    positionType?: Array<{ key: string; val: string }>
    exitOnExpiry?: Array<{ key: string; val: string }>
    tgt?: Array<{ key: string; val: string }>
    trl?: Array<{ key: string; val: string }>
    descriptions?: Record<string, string>
    [key: string]: unknown
  }
  errors?: unknown | null
}

// DIY Save Strategy API Types
export interface StrategyLegState {
  position: string // "Buy" | "Sell"
  optionType: string | null // "Ce" | "Pe" | null
  expiry: string // "CurrentWeek" | "NextWeek" | "CurrentMonth" | "NextMonth"
  lots: string // "1", "2", etc.
  strikeSelection: string // "SpotAtm" | "FutureAtm" | "SyntheticAtm" | ""
  strikeType: string | null // "ATM" | "ITM" | "OTM" | null
  strikeSelectionValue: string // Usually "null" or actual value
  tgtToogle: string // "true" | "false"
  tgtType: string // "Amount" | "Percent"
  tgtValue: number
  stopLossToggle: string // "true" | "false"
  stopLossType: string // "Percent" | "Amount"
  stopLossValue: number
  tslType: string // "" or type
  tslValue: number
  tslToggle: boolean
  tdValue: number
  derivativeType: string // "FUTURE" | "OPTION"
}

export interface StrategyLegRequest {
  position: string // "Buy" | "Sell"
  optionType: string | null // "Ce" | "Pe" | null
  expiry: string // "CurrentWeek" | "NextWeek" | "CurrentMonth" | "NextMonth"
  lots: string // "1", "2", etc.
  strikeSelection: string // "SpotAtm" | "FutureAtm" | "SyntheticAtm" | ""
  strikeType: string | null // "ATM" | "ITM" | "OTM" | null
  strikeSelectionValue: string // Usually "null" or actual value
  tgtToogle: string // "true" | "false"
  tgtType: string // "Amount" | "Percent"
  tgtValue: number
  stopLossToggle: string // "true" | "false"
  stopLossType: string // "Percent" | "Amount"
  stopLossValue: number
  tslType: string // "" or type
  tslValue: number
  tslToggle: boolean
  tdValue: number
  derivativeType: string // "FUTURE" | "OPTION"
}

export interface SaveDIYStrategyRequest {
  strategyId: number | null
  strategyName: string
  index: string // "1" | "2" | "3" | "4" | "5"
  executionTypeId: string // "LiveTrading" | "PaperTrading"
  capital: number
  strategyType: string // "Intraday" | "Positional"
  entryHours: number // 0-23
  entryMinutes: number // 0-59
  entryOnDays: number[] // [1,2,3,4,5] where 1=Monday, 5=Friday
  exitHours: number // 0-23
  exitMinutes: number // 0-59
  exitOnExpiry: string // "Yes" | "No"
  exitAfterEntryDays: number
  targetMtmToggle: string // "true" | "false"
  targetMtmType: string // "PercentOfCapital" | "Amount"
  targetMtmValue: number
  stopLossMtmToggle: string // "true" | "false"
  stopLossMtmType: string // "PercentOfCapital" | "Amount"
  stopLossMtmValue: number
  legs: StrategyLegRequest[]
}

export interface SaveDIYStrategyResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

// Save Profile API Types
export interface SaveProfileRequest {
  clientId: string
  maxLoss: number
  minProfit: number
}

export interface SaveProfileResponse {
  status?: string
  success: boolean
  message?: string
  data?: unknown
  errors?: unknown | null
}

// Generic API Error
export interface ApiError {
  message: string
  status?: number
  statusText?: string
  data?: unknown
}

// API Response Wrapper
export interface ApiResponse<T = unknown> {
  success: boolean
  data?: T
  error?: ApiError
  message?: string
}
