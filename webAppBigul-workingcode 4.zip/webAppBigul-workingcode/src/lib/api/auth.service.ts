/**
 * Authentication API Service
 * Handles all authentication-related API calls
 * Implements exact curl command specifications
 */

import { post, get } from "./client"
import { API_CONFIG } from "./config"
import { useAuthStore } from "@/store/auth.store"
import { ERROR_MESSAGES } from "@/lib/constants"
import { logger } from "@/lib/utils/logger"
import type {
  CheckTokenRequest,
  CheckTokenResponse,
  UserDetailsParams,
  UserDetailsResponse,
  WelcomeRequest,
  WelcomeResponse,
  SaveProfileRequest,
  SaveProfileResponse,
  ApiResponse,
} from "./types"

/**
 * Check token validity
 * POST /ql/auth/check
 * 
 * Matches curl: POST with token and xtsToken in request body
 * 
 * @param token - Authentication token (JWT)
 * @param xtsToken - XTS token
 * @returns Promise with check token response
 */
export const checkToken = async (
  token: string,
  xtsToken: string
): Promise<ApiResponse<CheckTokenResponse>> => {
  const requestBody: CheckTokenRequest = {
    token,
    xtsToken,
  }

  try {
    // Store tokens in Zustand store - this clears any old userId
    // userId will be set ONLY from the API response below
    useAuthStore.getState().setAuth(token, xtsToken)

    const response = await post<CheckTokenResponse>(
      API_CONFIG.ENDPOINTS.AUTH.CHECK,
      requestBody
    )

    // CRITICAL: Do NOT set userId here - it must be set in AuthProvider from the response
    // This ensures userId ONLY comes from the API response, not from any other source
    return response
  } catch (error) {
    logger.error("Failed to check token", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to check token",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Get user details
 * GET /ql/auth/userDetails?clientId={clientId}
 * 
 * IMPORTANT: This API ONLY uses clientId, NEVER userId
 * Matches curl: GET with clientId as query parameter
 * 
 * @param clientId - Client ID (must be provided, not hardcoded)
 * @returns Promise with user details response
 */
export const getUserDetails = async (
  clientId: string
): Promise<ApiResponse<UserDetailsResponse>> => {
  // ONLY pass clientId - never use userId for this API
  const params: UserDetailsParams = {
    clientId,
  }

  try {
    // Verify token exists before making request
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN_CHECK)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN_CHECK,
        },
      }
    }

    const response = await get<UserDetailsResponse>(
      API_CONFIG.ENDPOINTS.AUTH.USER_DETAILS,
      params as unknown as Record<string, string | number>
    )

    // If response is successful and contains a clientId, use it for subsequent call
    // This ensures we're using the clientId from the API response
    if (response.success && response.data?.clientId) {
      logger.info("UserDetails response contains clientId:", response.data.clientId)
      
      // If the clientId from response is different, call again with the response clientId
      if (response.data.clientId && response.data.clientId !== clientId) {
        logger.info("Calling userDetails again with clientId from response:", response.data.clientId)
        const paramsFromResponse: UserDetailsParams = {
          clientId: typeof response.data.clientId === 'string' ? response.data.clientId : String(response.data.clientId || ""),
        }
        const responseWithClientId = await get<UserDetailsResponse>(
          API_CONFIG.ENDPOINTS.AUTH.USER_DETAILS,
          paramsFromResponse as unknown as Record<string, string | number>
        )
        return responseWithClientId
      }
    }

    return response
  } catch (error) {
    logger.error("Failed to get user details", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to get user details",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Welcome API
 * POST /ql/auth/welcome
 * 
 * Matches curl: POST with clientId and termsConditions in request body
 * 
 * @param clientId - Client ID
 * @param termsConditions - Terms and conditions acceptance flag
 * @returns Promise with welcome response
 */
export const welcome = async (
  clientId: string,
  termsConditions: boolean = true
): Promise<ApiResponse<WelcomeResponse>> => {
  const requestBody: WelcomeRequest = {
    clientId,
    termsConditions,
  }

  try {
    // Verify token exists before making request
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN_CHECK)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN_CHECK,
        },
      }
    }

    const response = await post<WelcomeResponse>(
      API_CONFIG.ENDPOINTS.AUTH.WELCOME,
      requestBody
    )

    return response
  } catch (error) {
    logger.error("Failed to call welcome API", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to call welcome API",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Save user profile
 * POST /ql/auth/saveProfile
 * Body: { clientId, maxLoss, minProfit }
 * 
 * @param request - Save profile request parameters
 * @returns Promise with save profile response
 */
export const saveProfile = async (
  request: SaveProfileRequest
): Promise<ApiResponse<SaveProfileResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 AuthService: Saving profile:", request)
    
    const response = await post<SaveProfileResponse>(
      API_CONFIG.ENDPOINTS.AUTH.SAVE_PROFILE,
      request
    )

    console.log("📡 AuthService: Save profile response:", response)
    return response
  } catch (error) {
    logger.error("Failed to save profile", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to save profile",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

// Export all auth service functions
export const authService = {
  checkToken,
  getUserDetails,
  welcome,
  saveProfile,
}

export default authService
