/**
 * Reports API Service
 * Handles all reports-related API calls
 */

import { get, post } from "./client"
import { API_CONFIG } from "./config"
import { useAuthStore } from "@/store/auth.store"
import { ERROR_MESSAGES } from "@/lib/constants"
import { logger } from "@/lib/utils/logger"
import type {
  AllReportsResponse,
  StrategyReportsRequest,
  StrategyReportsResponse,
  StrategyDetailsParams,
  StrategyDetailsResponse,
  StatisticsResponse,
  ApiResponse,
} from "./types"

/**
 * Get all reports
 * POST /ql/reports/all
 * Body: {} (no date parameters)
 * 
 * @returns Promise with all reports response
 */
export const getAllReports = async (): Promise<ApiResponse<AllReportsResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 ReportsService: Making all reports API call")
    console.log("📡 ReportsService: Endpoint:", API_CONFIG.ENDPOINTS.REPORTS.ALL)
    
    const response = await post<AllReportsResponse>(
      API_CONFIG.ENDPOINTS.REPORTS.ALL,
      {}
    )
    
    console.log("📡 ReportsService: Response success:", response.success)
    console.log("📡 ReportsService: Response data:", response.data)
    console.log("📡 ReportsService: Response error:", response.error)

    console.log("📡 ReportsService: All reports response:", response)
    return response
  } catch (error) {
    logger.error("Failed to get all reports", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to get all reports",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Get strategy reports
 * POST /ql/reports/strategyreports
 * Body: { fromDate: "", toDate: "", strategyId: number }
 * 
 * Always passes empty date strings as per API specification
 * 
 * @param request - Strategy reports request with strategy ID
 * @returns Promise with strategy reports response
 */
export const getStrategyReports = async (
  request: StrategyReportsRequest
): Promise<ApiResponse<StrategyReportsResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    // Always pass empty date strings as per API specification
    const body: StrategyReportsRequest = {
      fromDate: "",
      toDate: "",
      strategyId: request.strategyId,
    }

    console.log("📡 ReportsService: Making strategy reports API call")
    console.log("📡 ReportsService: Request body:", JSON.stringify(body))
    console.log("📡 ReportsService: Endpoint:", API_CONFIG.ENDPOINTS.REPORTS.STRATEGY_REPORTS)
    
    const response = await post<StrategyReportsResponse>(
      API_CONFIG.ENDPOINTS.REPORTS.STRATEGY_REPORTS,
      body
    )
    
    console.log("📡 ReportsService: Response success:", response.success)
    console.log("📡 ReportsService: Response data:", response.data)
    console.log("📡 ReportsService: Response error:", response.error)

    console.log("📡 ReportsService: Strategy reports response:", response)
    return response
  } catch (error) {
    logger.error("Failed to get strategy reports", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to get strategy reports",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Get strategy details
 * GET /ql/strategy/v2/details?strategyId={strategyId}
 * 
 * @param params - Strategy details params with strategy ID
 * @returns Promise with strategy details response
 */
export const getStrategyDetails = async (
  params: StrategyDetailsParams
): Promise<ApiResponse<StrategyDetailsResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 ReportsService: Making strategy details API call for strategyId:", params.strategyId)
    const response = await get<StrategyDetailsResponse>(
      API_CONFIG.ENDPOINTS.STRATEGY.DETAILS,
      params as unknown as Record<string, string | number>
    )

    console.log("📡 ReportsService: Strategy details response:", response)
    return response
  } catch (error) {
    logger.error("Failed to get strategy details", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to get strategy details",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Get statistics for a strategy
 * GET /ql/statistics/{strategyId}
 * 
 * @param strategyId - Strategy ID
 * @returns Promise with statistics response
 */
export const getStatistics = async (
  strategyId: number
): Promise<ApiResponse<StatisticsResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 ReportsService: Making statistics API call for strategyId:", strategyId)
    const response = await get<StatisticsResponse>(
      `${API_CONFIG.ENDPOINTS.STATISTICS.GET}/${strategyId}`,
      {}
    )

    console.log("📡 ReportsService: Statistics response:", response)
    return response
  } catch (error) {
    logger.error("Failed to get statistics", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to get statistics",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Get default strategy report
 * GET /ql/reports/default/strategy?strategyName={strategyName}
 * 
 * Matches curl: GET with Authorization Bearer token header
 * The strategyName will be automatically URL encoded by the get() function
 * 
 * @param strategyName - Strategy name (raw, e.g., "NF-Delta Neutral")
 * @returns Promise with default strategy report response
 */
export const getDefaultStrategyReport = async (
  strategyName: string
): Promise<ApiResponse<unknown>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 ReportsService: Making default strategy report API call")
    console.log("📡 ReportsService: Strategy name (raw):", strategyName)
    console.log("📡 ReportsService: Endpoint:", API_CONFIG.ENDPOINTS.REPORTS.DEFAULT_STRATEGY)
    
    // Pass raw strategy name - get() function will automatically URL encode via searchParams
    // This matches the curl: strategyName=NF-Delta%20Neutral (where %20 is the encoded space)
    const response = await get<unknown>(
      API_CONFIG.ENDPOINTS.REPORTS.DEFAULT_STRATEGY,
      { strategyName: strategyName }
    )

    console.log("📡 ReportsService: Default strategy report response:", response)
    return response
  } catch (error) {
    logger.error("Failed to get default strategy report", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to get default strategy report",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

// Export all reports service functions
export const reportsService = {
  getAllReports,
  getStrategyReports,
  getStrategyDetails,
  getStatistics,
  getDefaultStrategyReport,
}

export default reportsService

