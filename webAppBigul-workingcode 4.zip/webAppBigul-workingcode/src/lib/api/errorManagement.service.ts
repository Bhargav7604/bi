/**
 * Error Management API Service
 * Handles error management and manual trading related API calls
 */

import { post } from "./client"
import { API_CONFIG } from "./config"
import { useAuthStore } from "@/store/auth.store"
import { ERROR_MESSAGES } from "@/lib/constants"
import { logger } from "@/lib/utils/logger"
import type {
  StrategyActionResponse,
  RetryResponse,
  CancelledResponse,
  ApiResponse,
} from "./types"

/**
 * Mark strategy as manually traded
 * POST /ql/errormanagement/v2/manuallytraded?strategyId={strategyId}
 * 
 * @param strategyId - Strategy ID to mark as manually traded
 * @returns Promise with action response
 */
export const markAsManuallyTraded = async (
  strategyId: string | number
): Promise<ApiResponse<StrategyActionResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 ErrorManagementService: Marking as manually traded, strategyId:", strategyId)
    
    const response = await post<StrategyActionResponse>(
      API_CONFIG.ENDPOINTS.ERROR_MANAGEMENT.MANUALLY_TRADED,
      {}, // Empty body as per curl
      { strategyId } // Query parameter
    )

    console.log("📡 ErrorManagementService: Mark as manually traded response:", response)

    return response
  } catch (error) {
    logger.error("Failed to mark strategy as manually traded", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to mark strategy as manually traded",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Retry strategy
 * POST /ql/errormanagement/v2/retry?strategyId={strategyId}
 * 
 * @param strategyId - Strategy ID to retry
 * @returns Promise with retry response
 */
export const retryStrategy = async (
  strategyId: number
): Promise<ApiResponse<RetryResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 ErrorManagementService: Retrying strategy, strategyId:", strategyId)
    
    const response = await post<RetryResponse>(
      API_CONFIG.ENDPOINTS.ERROR_MANAGEMENT.RETRY,
      {}, // Empty body as per curl
      { strategyId } // Query parameter
    )

    console.log("📡 ErrorManagementService: Retry response:", response)
    return response
  } catch (error) {
    logger.error("Failed to retry strategy", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to retry strategy",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

/**
 * Mark strategy as cancelled
 * POST /ql/errormanagement/v2/cancelled?strategyId={strategyId}
 * 
 * @param strategyId - Strategy ID to mark as cancelled
 * @returns Promise with cancelled response
 */
export const markAsCancelled = async (
  strategyId: number
): Promise<ApiResponse<CancelledResponse>> => {
  try {
    const token = useAuthStore.getState().token
    if (!token) {
      logger.warn(ERROR_MESSAGES.NO_TOKEN)
      return {
        success: false,
        error: {
          message: ERROR_MESSAGES.NO_TOKEN,
        },
      }
    }

    console.log("📡 ErrorManagementService: Marking as cancelled, strategyId:", strategyId)
    
    const response = await post<CancelledResponse>(
      API_CONFIG.ENDPOINTS.ERROR_MANAGEMENT.CANCELLED,
      {}, // Empty body as per curl
      { strategyId } // Query parameter
    )

    console.log("📡 ErrorManagementService: Cancelled response:", response)
    return response
  } catch (error) {
    logger.error("Failed to mark strategy as cancelled", error)
    return {
      success: false,
      error: {
        message: error instanceof Error ? error.message : "Failed to mark strategy as cancelled",
        status: error instanceof Error && "status" in error ? (error.status as number) : undefined,
      },
    }
  }
}

// Export all error management service functions
export const errorManagementService = {
  markAsManuallyTraded,
  retryStrategy,
  markAsCancelled,
}

export default errorManagementService

