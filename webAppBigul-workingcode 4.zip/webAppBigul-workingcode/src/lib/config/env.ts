/**
 * Environment Configuration
 * Centralized environment variable management
 */

/**
 * Get environment variable with fallback
 */
const getEnvVar = (key: string, fallback: string): string => {
  if (typeof window !== "undefined") {
    // Client-side: use import.meta.env (Vite)
    return import.meta.env[key] || fallback
  }
  // Server-side fallback
  return process.env[key] || fallback
}

/**
 * Environment configuration
 */
export const ENV = {
  // API Configuration
  API_BASE_URL: getEnvVar("VITE_API_BASE_URL", "http://13.232.30.243:8081"),
  
  // Origin configuration (for CORS headers)
  ORIGIN_URL: getEnvVar("VITE_ORIGIN_URL", "https://algos.bigulapp.in"),
  
  // Environment
  NODE_ENV: getEnvVar("NODE_ENV", "development"),
  IS_PRODUCTION: getEnvVar("NODE_ENV", "development") === "production",
  IS_DEVELOPMENT: getEnvVar("NODE_ENV", "development") === "development",
} as const

