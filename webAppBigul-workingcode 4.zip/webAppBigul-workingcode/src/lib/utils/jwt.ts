/**
 * JWT Utility Functions
 * Helper functions to decode and extract data from JWT tokens
 */

import type { JWTPayload } from "@/lib/api/types"
import { JWT_FIELDS, ERROR_MESSAGES } from "@/lib/constants"
import { logger } from "./logger"

/**
 * Decode JWT token without verification
 * @param token - JWT token string
 * @returns Decoded payload or null if invalid
 */
export const decodeJWT = (token: string): JWTPayload | null => {
  try {
    if (!token || typeof token !== "string") {
      logger.warn(ERROR_MESSAGES.INVALID_TOKEN)
      return null
    }

    const parts = token.split(".")
    if (parts.length !== 3) {
      logger.warn(ERROR_MESSAGES.INVALID_TOKEN, "Invalid token format")
      return null
    }

    const payload = parts[1]
    
    // Handle URL-safe base64 encoding
    // Replace URL-safe characters and add padding if needed
    let base64 = payload.replace(/-/g, "+").replace(/_/g, "/")
    
    // Add padding if needed (base64 strings must be multiple of 4)
    const padLength = (4 - (base64.length % 4)) % 4
    base64 += "=".repeat(padLength)

    // Decode base64
    let decoded: string
    try {
      decoded = atob(base64)
    } catch (base64Error) {
      logger.error("Base64 decoding failed", base64Error)
      return null
    }
    
    // Remove control characters that cause JSON.parse to fail
    // Keep only printable characters and common whitespace (space, tab, newline, carriage return)
    // This regex removes: \x00-\x08 (null to backspace), \x0B-\x0C (vertical tab, form feed), 
    // \x0E-\x1F (shift out to unit separator), \x7F (delete)
    let cleaned = decoded.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, "")
    
    // Try to fix common JSON issues: unescaped quotes, trailing commas, etc.
    // Remove trailing commas before closing braces/brackets
    cleaned = cleaned.replace(/,(\s*[}\]])/g, '$1')
    
    // Try to parse JSON
    try {
      return JSON.parse(cleaned) as JWTPayload
    } catch (parseError) {
      // If JSON.parse still fails, try to fix more issues
      // Only log warning in development, not as error
      if (process.env.NODE_ENV === 'development') {
        logger.warn("Initial JSON parse failed, attempting to fix JSON structure", parseError)
      }
      
      try {
        // More aggressive cleaning - remove all non-printable characters except newlines, tabs, carriage returns
        let moreCleaned = cleaned.replace(/[^\x20-\x7E\n\r\t]/g, "")
        
        // Remove trailing commas more aggressively
        moreCleaned = moreCleaned.replace(/,(\s*[}\]])/g, '$1')
        
        // Try to fix unescaped control characters in string values
        // Replace any remaining problematic characters with spaces
        moreCleaned = moreCleaned.replace(/[\x00-\x1F\x7F]/g, ' ')
        
        // Try to extract valid JSON by finding the largest valid JSON object
        const firstBrace = moreCleaned.indexOf('{')
        const lastBrace = moreCleaned.lastIndexOf('}')
        
        if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
          let jsonCandidate = moreCleaned.substring(firstBrace, lastBrace + 1)
          
          // Try to fix common JSON syntax errors
          // Remove trailing commas
          jsonCandidate = jsonCandidate.replace(/,(\s*[}\]])/g, '$1')
          
          // Try to fix unclosed strings (basic attempt)
          // This is a simple heuristic - may not work for all cases
          try {
            return JSON.parse(jsonCandidate) as JWTPayload
          } catch (innerError) {
            // If parsing still fails, try to fix more issues
            // Remove any characters that might be causing issues after property values
            jsonCandidate = jsonCandidate.replace(/([^\\]":\s*"[^"]*?)([^",}\]]+?)([",}\]])/g, '$1$3')
            
            try {
              return JSON.parse(jsonCandidate) as JWTPayload
            } catch {
              // Try the moreCleaned version as fallback
            }
          }
        }
        
        // Final attempt with the cleaned string
        try {
          return JSON.parse(moreCleaned) as JWTPayload
        } catch {
          // If all attempts fail, return null silently
          // Only log in development mode to avoid console noise in production
          if (process.env.NODE_ENV === 'development') {
            logger.warn("JWT decoding failed after all attempts - token may be malformed")
          }
          return null
        }
      } catch (finalError) {
        // Only log error in development, return null gracefully
        // Suppress error logging in production to avoid console noise
        if (process.env.NODE_ENV === 'development') {
          logger.warn("JWT decoding failed after all attempts", finalError)
        }
        // Return null instead of throwing to prevent app crash
        return null
      }
    }
  } catch (error) {
    logger.error(ERROR_MESSAGES.FAILED_TO_DECODE_JWT, error)
    return null
  }
}

/**
 * Extract clientId from JWT token
 * @param token - JWT token string
 * @returns Client ID (unique_name or LoginId) or null
 */
export const getClientIdFromToken = (token: string): string | null => {
  const decoded = decodeJWT(token)
  if (!decoded) return null

  // Try unique_name first (as seen in the curl example)
  const uniqueName = decoded[JWT_FIELDS.UNIQUE_NAME]
  if (uniqueName && typeof uniqueName === "string") {
    return uniqueName
  }

  // Fallback to LoginId
  const loginId = decoded[JWT_FIELDS.LOGIN_ID]
  if (loginId && typeof loginId === "string") {
    return loginId
  }

  return null
}

/**
 * Extract UserId from JWT token or user details
 * This might be in the token or need to be fetched from userDetails
 * @param token - JWT token string
 * @returns User ID or null
 */
export const getUserIdFromToken = (token: string): string | number | null => {
  const decoded = decodeJWT(token)
  if (!decoded) return null

  // Check for userId field
  if (decoded[JWT_FIELDS.USER_ID]) {
    return decoded[JWT_FIELDS.USER_ID] as string | number
  }

  // Check for userID (camelCase variant)
  if (decoded[JWT_FIELDS.USER_ID_ALT]) {
    return decoded[JWT_FIELDS.USER_ID_ALT] as string | number
  }

  return null
}

