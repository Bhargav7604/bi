/**
 * Auth Provider Component
 * Handles URL token extraction and auto-authentication flow
 */

import { useEffect, useState, useRef } from "react"
import { useSearchParams } from "react-router-dom"
import { authService } from "@/lib/api/auth.service"
import { useAuthStore } from "@/store/auth.store"
import { getClientIdFromToken } from "@/lib/utils/jwt"
import { QUERY_PARAMS, ERROR_MESSAGES, LOADING_MESSAGES } from "@/lib/constants"
import { logger } from "@/lib/utils/logger"
import type { CheckTokenResponse } from "@/lib/api/types"

interface AuthProviderProps {
  children: React.ReactNode
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [searchParams, setSearchParams] = useSearchParams()
  const { token, xtsToken, isAuthenticated } = useAuthStore()
  const [isInitializing, setIsInitializing] = useState(true)
  const hasInitialized = useRef(false)

  useEffect(() => {
    // Prevent duplicate calls (React StrictMode in dev causes double renders)
    if (hasInitialized.current) {
      return
    }

    const initializeAuth = async () => {
      // Check if tokens are in URL
      const urlToken = searchParams.get(QUERY_PARAMS.TOKEN)
      const urlXtsToken = searchParams.get(QUERY_PARAMS.XTS_TOKEN)

      // If tokens are in URL, use them
      if (urlToken && urlXtsToken) {
        try {
          hasInitialized.current = true
          
          // Store tokens first - this clears any old userId
          useAuthStore.getState().setAuth(urlToken, urlXtsToken)

          // Step 1: Check token
          logger.info("Step 1: Checking token...")
          const checkResponse = await authService.checkToken(urlToken, urlXtsToken)
          
          if (!checkResponse.success || !checkResponse.data) {
            logger.error(ERROR_MESSAGES.TOKEN_CHECK_FAILED, checkResponse.error?.message)
            // Ensure userId is cleared on failure - use clearAuth to reset everything
            useAuthStore.getState().clearAuth()
            setIsInitializing(false)
            return
          }

          // Extract userId and clientId from check response
          // The API returns: { success: true, data: { userId, clientId, ... } }
          // handleResponse extracts the inner data field, so checkResponse.data is { userId, clientId, ... }
          const checkData = checkResponse.data as CheckTokenResponse["data"]
          const userId = checkData?.userId
          
          // CRITICAL: userId MUST come from API response - NO FALLBACKS, NO HARDCODED VALUES
          if (!userId) {
            logger.error("❌ AuthProvider: userId is missing from /ql/auth/check API response. Cannot proceed.")
            console.error("❌ AuthProvider: Full API response was:", JSON.stringify(checkResponse, null, 2))
            // Clear auth if userId is missing from API response
            useAuthStore.getState().clearAuth()
            setIsInitializing(false)
            return
          }
          
          // Store userId ONLY from API response
          useAuthStore.getState().setUserId(userId)
          logger.info("✅ AuthProvider: UserId stored in auth store from API response:", userId)
          
          // Prefer clientId from check response, fallback to JWT decoding only if needed
          let clientId: string | undefined = checkData?.clientId
          if (!clientId) {
            logger.warn("clientId not found in check response, attempting JWT decode")
            const tokenClientId = getClientIdFromToken(urlToken)
            clientId = tokenClientId || undefined
          }

          logger.info("Check response received:", { userId, clientId })

          // Step 2: Get user details using clientId from check response
          // The getUserDetails function will automatically use clientId from response if available
          if (clientId) {
            logger.info("Step 2: Getting user details for clientId:", clientId)
            const userDetailsResponse = await authService.getUserDetails(clientId)
            
            if (!userDetailsResponse.success) {
              logger.error("Failed to get user details:", userDetailsResponse.error?.message)
            } else {
              logger.info("User details received successfully")
            }
          } else {
            logger.warn("No clientId found, skipping user details")
          }

          // Note: Active strategies are fetched by individual components as needed
          // This prevents duplicate API calls

          // Clean up URL parameters after successful authentication
          setSearchParams({}, { replace: true })
        } catch (err) {
          logger.error(ERROR_MESSAGES.AUTH_INIT_ERROR, err)
          hasInitialized.current = false // Reset on error to allow retry
        } finally {
          setIsInitializing(false)
        }
      } else if (token && xtsToken && isAuthenticated && !hasInitialized.current) {
        // If already authenticated, ALWAYS fetch userId from API (never use cached value)
        // userId is NOT persisted, so it will always be null on page load
        try {
          hasInitialized.current = true
          
          // CRITICAL: Always fetch userId from API - it's never persisted in localStorage
          // This ensures userId always comes from the current API response, not from cache
          logger.info("Tokens found in store, fetching userId from /ql/auth/check API")
          const checkResponse = await authService.checkToken(token, xtsToken)
          if (checkResponse.success && checkResponse.data) {
            const checkData = checkResponse.data as CheckTokenResponse["data"]
            const userId = checkData?.userId
            
            // CRITICAL: userId MUST come from API response - NO FALLBACKS, NO HARDCODED VALUES
            if (!userId) {
              logger.error("❌ AuthProvider: userId is missing from /ql/auth/check API response")
              useAuthStore.getState().clearAuth()
              setIsInitializing(false)
              return
            }
            
            // Store userId ONLY from API response
            useAuthStore.getState().setUserId(userId)
            logger.info("✅ AuthProvider: UserId retrieved and stored from API:", userId)
          } else {
            logger.error("❌ AuthProvider: Failed to get userId from API")
            useAuthStore.getState().clearAuth()
          }
          
          const clientId = getClientIdFromToken(token)
          if (clientId) {
            logger.info("Already authenticated, fetching user details for:", clientId)
            // The getUserDetails function will automatically use clientId from response if available
            await authService.getUserDetails(clientId)
          }
        } catch (err) {
          logger.error(ERROR_MESSAGES.AUTH_VERIFICATION_ERROR, err)
          useAuthStore.getState().clearAuth()
          hasInitialized.current = false
        } finally {
          setIsInitializing(false)
        }
      } else {
        // No tokens available
        setIsInitializing(false)
      }
    }

    initializeAuth()
  }, [searchParams, token, xtsToken, isAuthenticated])

  // Show loading state during initialization
  if (isInitializing) {
    return (
      <div style={{ 
        display: "flex", 
        justifyContent: "center", 
        alignItems: "center", 
        height: "100vh" 
      }}>
        <div>{LOADING_MESSAGES.INITIALIZING_AUTH}</div>
      </div>
    )
  }

  return <>{children}</>
}

