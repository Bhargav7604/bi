import { Search, User } from "lucide-react"
import { Link, useLocation } from "react-router-dom"

export default function Header() {
  const location = useLocation()
  
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3">
          <img src="/images/bigullogo.png" alt="Bigul Logo" className="h-10 w-auto" />
          <span className="text-xl font-bold text-gray-900 hidden sm:inline">Bigul</span>
        </Link>

        {/* Navigation */}
        <nav className="hidden md:flex items-center gap-8 flex-1 ml-12">
          <Link to="/" className={`transition font-medium ${
            location.pathname === "/" ? "text-indigo-600 border-b-2 border-indigo-600 pb-1" : "text-gray-600 hover:text-gray-900"
          }`}>
            Home
          </Link>
          <Link to="/discover" className={`transition font-medium ${
            location.pathname === "/discover" ? "text-indigo-600 border-b-2 border-indigo-600 pb-1" : "text-gray-600 hover:text-gray-900"
          }`}>
            Discover Strategy
          </Link>
          <Link to="/create-strategy" className={`transition font-medium ${
            location.pathname === "/create-strategy" ? "text-indigo-600 border-b-2 border-indigo-600 pb-1" : "text-gray-600 hover:text-gray-900"
          }`}>
            Create Strategy
          </Link>
          <Link to="/my-strategy" className={`transition font-medium ${
            location.pathname === "/my-strategy" ? "text-indigo-600 border-b-2 border-indigo-600 pb-1" : "text-gray-600 hover:text-gray-900"
          }`}>
            My Strategy
          </Link>
        </nav>

        {/* Right Icons */}
        <div className="flex items-center gap-4">
          <button className="p-2 hover:bg-gray-100 rounded-full transition" aria-label="Search">
            <Search size={20} className="text-gray-600" />
          </button>
          <Link to="/profile" className="p-2 hover:bg-gray-100 rounded-full transition" aria-label="User account">
            <User size={20} className="text-gray-600" />
          </Link>
        </div>
      </div>
    </header>
  )
}
