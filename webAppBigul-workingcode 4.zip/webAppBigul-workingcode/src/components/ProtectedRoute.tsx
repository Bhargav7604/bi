/**
 * Protected Route Component
 * Ensures users are authenticated before accessing protected pages
 * Redirects to home or shows error if not authenticated
 */

import { Navigate, useLocation } from "react-router-dom"
import { useAuthStore } from "@/store/auth.store"
import { Loader2 } from "lucide-react"

interface ProtectedRouteProps {
  children: React.ReactNode
  requireAuth?: boolean // Default true, set to false for public routes
}

export default function ProtectedRoute({ 
  children, 
  requireAuth = true 
}: ProtectedRouteProps) {
  const { token, xtsToken, isAuthenticated } = useAuthStore()
  const location = useLocation()

  // If route doesn't require auth, allow access
  if (!requireAuth) {
    return <>{children}</>
  }

  // Check if user has tokens
  const hasTokens = !!(token && xtsToken)

  // If no tokens at all, redirect to home with message
  if (!hasTokens) {
    console.warn("🔒 ProtectedRoute: No tokens found, redirecting to home")
    return <Navigate to="/" replace state={{ from: location, message: "Please login to access this page" }} />
  }

  // If tokens exist but not authenticated yet (still checking), show loading
  if (hasTokens && !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: "#F5F5F5" }}>
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-indigo-600" />
          <p className="text-gray-600">Verifying authentication...</p>
        </div>
      </div>
    )
  }

  // If authenticated, allow access
  if (isAuthenticated) {
    return <>{children}</>
  }

  // Fallback: redirect to home
  return <Navigate to="/" replace state={{ from: location, message: "Authentication required" }} />
}

