/**
 * Authentication Store
 * Zustand store for managing authentication state
 * 
 * IMPORTANT: userId is NOT persisted to localStorage
 * userId MUST always come from /ql/auth/check API response
 * This prevents any cached/hardcoded userId values from being used
 */

import { create } from "zustand"
import { persist } from "zustand/middleware"
import { STORAGE_KEYS } from "@/lib/constants"

// AGGRESSIVE CLEANUP: Remove userId from localStorage if it exists (migration from old version)
// This runs on every module load to ensure userId is never persisted
if (typeof window !== "undefined") {
  try {
    const storageKey = STORAGE_KEYS.AUTH
    const stored = localStorage.getItem(storageKey)
    if (stored) {
      const parsed = JSON.parse(stored)
      if (parsed?.state?.userId !== undefined) {
        console.warn("🧹 CLEANUP: Found userId in localStorage, removing it:", parsed.state.userId)
        // Remove userId from stored state
        delete parsed.state.userId
        localStorage.setItem(storageKey, JSON.stringify(parsed))
        console.log("✅ CLEANUP: userId removed from localStorage")
      }
    }
    // Double-check: ensure userId is not in localStorage after cleanup
    const afterCleanup = localStorage.getItem(storageKey)
    if (afterCleanup) {
      const parsedAfter = JSON.parse(afterCleanup)
      if (parsedAfter?.state?.userId !== undefined) {
        console.error("❌ CLEANUP FAILED: userId still exists in localStorage:", parsedAfter.state.userId)
        // Force remove it
        parsedAfter.state.userId = undefined
        delete parsedAfter.state.userId
        localStorage.setItem(storageKey, JSON.stringify(parsedAfter))
      }
    }
  } catch (error) {
    console.error("❌ CLEANUP ERROR:", error)
  }
}

interface AuthState {
  token: string | null
  xtsToken: string | null
  userId: string | number | null
  isAuthenticated: boolean
  setToken: (token: string) => void
  setXtsToken: (xtsToken: string) => void
  setAuth: (token: string, xtsToken: string) => void
  setUserId: (userId: string | number) => void
  clearAuth: () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      token: null,
      xtsToken: null,
      userId: null,
      isAuthenticated: false,

      setToken: (token: string) =>
        set({ token, isAuthenticated: !!token }),

      setXtsToken: (xtsToken: string) =>
        set((state) => ({
          xtsToken,
          isAuthenticated: !!(state.token && xtsToken),
        })),

      setAuth: (token: string, xtsToken: string) =>
        set({
          token,
          xtsToken,
          userId: null, // Clear userId when tokens change - it must come from API response
          isAuthenticated: !!(token && xtsToken),
        }),

      setUserId: (userId: string | number) => {
        console.log("🔐 AUTH STORE: setUserId called with:", userId)
        console.trace("🔐 AUTH STORE: setUserId call stack")
        set({ userId })
        // Verify userId is NOT in localStorage after setting
        if (typeof window !== "undefined") {
          try {
            const stored = localStorage.getItem(STORAGE_KEYS.AUTH)
            if (stored) {
              const parsed = JSON.parse(stored)
              if (parsed?.state?.userId !== undefined) {
                console.error("❌ CRITICAL: userId was persisted to localStorage! Value:", parsed.state.userId)
                // Force remove it
                delete parsed.state.userId
                localStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(parsed))
              } else {
                console.log("✅ VERIFIED: userId is NOT in localStorage (correct)")
              }
            }
          } catch (error) {
            console.error("❌ Error checking localStorage:", error)
          }
        }
      },

      clearAuth: () =>
        set({
          token: null,
          xtsToken: null,
          userId: null,
          isAuthenticated: false,
        }),
    }),
    {
      name: STORAGE_KEYS.AUTH,
      // CRITICAL: Exclude userId from persistence
      // userId MUST always come from /ql/auth/check API response, never from localStorage
      // This prevents any cached/hardcoded userId values (like 1000) from being used
      partialize: (state) => ({
        token: state.token,
        xtsToken: state.xtsToken,
        isAuthenticated: state.isAuthenticated,
        // userId is explicitly excluded - it will always be null on page load
        // and must be fetched fresh from the API
      }),
    }
  )
)

