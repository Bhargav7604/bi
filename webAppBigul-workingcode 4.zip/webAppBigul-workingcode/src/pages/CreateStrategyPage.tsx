import Header from "@components/Header"
import CreateStrategy from "@components/CreateStrategy"

export default function CreateStrategyPage() {
  return (
    <div className="min-h-screen bg-[#F5F5F5] dark:bg-gray-950">
      <Header />
      <CreateStrategy />
    </div>
  )
}

