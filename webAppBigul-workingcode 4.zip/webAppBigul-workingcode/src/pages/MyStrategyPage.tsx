import Header from "@components/Header"
import TradeDetailsModal from "@components/TradeDetailsModal"
import { Calendar, ChevronDown, ChevronUp, ChevronLeft, ChevronRight, Download, Search, Loader2, MoreVertical, LogOut, Power, FileText, Play, TrendingUp, ClipboardList, RotateCw, X } from "lucide-react"
import React, { useState, useEffect, useCallback, useMemo, useRef } from "react"
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart } from "recharts"
import { useNavigate, useSearchParams } from "react-router-dom"
import { strategyService } from "@/lib/api/strategy.service"
import { errorManagementService } from "@/lib/api/errorManagement.service"
import { reportsService } from "@/lib/api/reports.service"
import { authService } from "@/lib/api/auth.service"
import { useAuthStore } from "@/store/auth.store"
// import { STORAGE_KEYS } from "@/lib/constants"
import type { ActiveStrategy, AllReportsResponse, ReportData } from "@/lib/api/types"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@components/ui/select"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@components/ui/dropdown-menu"
import { Switch } from "@components/ui/switch"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@components/ui/dialog"
import { Button } from "@components/ui/button"
import toastr from "@/lib/utils/toastr"

export default function MyStrategyPage() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  
  // Set initial tab from URL parameter, default to "Deployed Algos"
  const getInitialTab = () => {
    const tabParam = searchParams.get("tab")
    if (tabParam === "Deployed Algos" || tabParam === "deployed-algos" || tabParam === "Performance" || tabParam === "performance") return "Deployed Algos"
    if (tabParam === "Positions" || tabParam === "positions") return "Positions"
    if (tabParam === "OrderBook" || tabParam === "orderbook") return "OrderBook"
    if (tabParam === "Performance Report" || tabParam === "performance-report" || tabParam === "Reports" || tabParam === "reports") return "Performance Report"
    // Default to Deployed Algos tab
    return "Deployed Algos"
  }
  
  const [activeTab, setActiveTab] = useState(getInitialTab)
  const [activeToggle, setActiveToggle] = useState("LIVE")
  const [currentPage, setCurrentPage] = useState(1)
  
  // Sorting state for each table
  const [sortConfig, setSortConfig] = useState<{
    key: string | null
    direction: 'asc' | 'desc' | null
  }>({
    key: null,
    direction: null
  })
  const [activeStrategies, setActiveStrategies] = useState<ActiveStrategy[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [customOrders, setCustomOrders] = useState<any[]>([])
  const [customOrdersLoading, setCustomOrdersLoading] = useState(false)
  const [reports, setReports] = useState<any[]>([])
  const [reportsLoading, setReportsLoading] = useState(false)
  // Calendar view state
  const [calendarViewMode, setCalendarViewMode] = useState<"table" | "calendar">("table")
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<Date | null>(null)
  const [calendarMonth, setCalendarMonth] = useState<Date>(new Date())
  // Day details filters state
  const [dayDetailsFilters, setDayDetailsFilters] = useState({
    strategyName: "",
    pnlRange: "All",
    status: "All",
    sortBy: "P&L (High to Low)"
  })
  const [dayDetailsPanelOpen, setDayDetailsPanelOpen] = useState(false)
  const [dayDetailsData, setDayDetailsData] = useState<any[]>([])
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    // Default to today's date in local timezone, then convert to UTC for API
    const today = new Date()
    const year = today.getFullYear()
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const _month = String(today.getMonth() + 1).padStart(2, '0')
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const _day = String(today.getDate()).padStart(2, '0')
    // Create UTC date at midnight for the selected local date
    const utcDate = new Date(Date.UTC(year, today.getMonth(), today.getDate(), 0, 0, 0, 0))
    return utcDate.toISOString()
  })
  const [actionLoading, setActionLoading] = useState<Record<number, boolean>>({})
  const [errorActionLoading, setErrorActionLoading] = useState<Record<number, boolean>>({})
  const [multiplierLoading, setMultiplierLoading] = useState<Record<number, boolean>>({})
  const [exitAllLoading, setExitAllLoading] = useState(false)
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false)
  const [pendingStrategyId, setPendingStrategyId] = useState<number | null>(null)
  const [pendingExecutionType, setPendingExecutionType] = useState<string | null>(null)
  const [multiplierDialogOpen, setMultiplierDialogOpen] = useState(false)
  const [pendingMultiplier, setPendingMultiplier] = useState<{ strategyId: number; multiplier: number; executionType: string; strategyName: string } | null>(null)
  const [exitAllDialogOpen, setExitAllDialogOpen] = useState(false)
  const [actionDialogOpen, setActionDialogOpen] = useState(false)
  const [pendingAction, setPendingAction] = useState<{ type: string; strategyId: number; strategyName: string } | null>(null)
  const [logsDialogOpen, setLogsDialogOpen] = useState(false)
  const [logsData, setLogsData] = useState<{ strategyId?: number; userId?: string; deployedOn?: string | null; statusList?: Array<{ timeStamp: string; status: string; description: string[] }> } | null>(null)
  const [logsLoading, setLogsLoading] = useState(false)
  const [detailedReportDialogOpen, setDetailedReportDialogOpen] = useState(false)
  const [detailedReportData, setDetailedReportData] = useState<any>(null)
  const [tradeDetailsModalOpen, setTradeDetailsModalOpen] = useState(false)
  const [selectedTradeDetailsStrategy, setSelectedTradeDetailsStrategy] = useState<{ id: number; name: string; data: any } | null>(null)
  const [detailedReportLoading, setDetailedReportLoading] = useState(false)
  const { token, isAuthenticated, userId, xtsToken } = useAuthStore()
  const [isCheckingAuth, setIsCheckingAuth] = useState(false)

  // Function to ensure userId is available by calling check API if needed
  const ensureUserId = useCallback(async (): Promise<boolean> => {
    // If userId is already available, return true
    if (userId) {
      return true
    }

    // If tokens are not available, cannot proceed
    if (!token || !xtsToken) {
      console.warn("MyStrategyPage: Cannot ensure userId - tokens missing")
      return false
    }

    // If already checking, wait
    if (isCheckingAuth) {
      console.log("MyStrategyPage: Already checking auth, waiting...")
      return false
    }

    setIsCheckingAuth(true)
    try {
      console.log("📡 MyStrategyPage: userId not available, calling check API to get it...")
      const checkResponse = await authService.checkToken(token, xtsToken)
      console.log("📡 MyStrategyPage: Check API response:", checkResponse)

      if (checkResponse.success && checkResponse.data) {
        const checkData = checkResponse.data as any
        const responseUserId = checkData?.data?.userId || checkData?.userId

        if (responseUserId) {
          console.log("✅ MyStrategyPage: userId received from check API:", responseUserId)
          useAuthStore.getState().setUserId(responseUserId)
          return true
        } else {
          console.error("❌ MyStrategyPage: Check API did not return userId")
          setError("Failed to retrieve user information. Please login again.")
          return false
        }
      } else {
        console.error("❌ MyStrategyPage: Check API failed:", checkResponse.error)
        setError(checkResponse.error?.message || "Authentication failed. Please login again.")
        return false
      }
    } catch (err) {
      console.error("❌ MyStrategyPage: Exception during check API call:", err)
      setError(err instanceof Error ? err.message : "An error occurred during authentication")
      return false
    } finally {
      setIsCheckingAuth(false)
    }
  }, [token, xtsToken, userId, isCheckingAuth])

  // Function to fetch active strategies
  const fetchActiveStrategies = useCallback(async () => {
    console.log("🔍 MyStrategyPage: Starting to fetch active strategies")
    console.log("🔍 Token available:", !!token)
    console.log("🔍 Is authenticated:", isAuthenticated)
    console.log("🔍 UserId from store:", userId)
    
    setLoading(true)
    setError(null)
    
    if (!token || !isAuthenticated) {
      console.warn("⚠️ MyStrategyPage: No token or not authenticated")
      setError("No authentication token found. Please login again.")
      setLoading(false)
      return
    }

    // Ensure userId is available - call check API if needed
    const currentUserId = useAuthStore.getState().userId
    if (!currentUserId) {
      console.log("⚠️ MyStrategyPage: userId not in store, calling check API...")
      const hasUserId = await ensureUserId()
      if (!hasUserId) {
        setLoading(false)
        return
      }
    }

    // Get userId again after ensureUserId (it might have been set)
    const finalUserId = useAuthStore.getState().userId
    if (!finalUserId) {
      console.error("❌ MyStrategyPage: UserId still not available after check API")
      setError("User ID not found. Please refresh the page or login again.")
      setLoading(false)
      return
    }

    // Validate userId is a valid value (not undefined, null, or empty)
    if (finalUserId === undefined || finalUserId === null || finalUserId === "" || finalUserId === 0) {
      console.error("❌ MyStrategyPage: Invalid userId value:", finalUserId)
      setError("Invalid User ID. Please refresh the page or login again.")
      setLoading(false)
      return
    }

    try {
      console.log("✅ MyStrategyPage: Using userId from auth store (from /ql/auth/check API):", finalUserId)
      console.log("✅ MyStrategyPage: userId type:", typeof finalUserId, "value:", finalUserId)
      
      console.log("📡 MyStrategyPage: Calling API with userId:", finalUserId)
      console.log("📡 MyStrategyPage: API endpoint: GET /ql/strategy/v2/active?UserId=" + finalUserId)
      const response = await strategyService.getActiveStrategies(finalUserId)
      console.log("📡 MyStrategyPage: API Response:", response)
      
      if (response.success) {
        // The response structure: response.data is ActiveStrategyResponse
        // ActiveStrategyResponse has: { status, success, message, data: { activeStrategiesResponse, activeStrategiesDropdown }, errors }
        const responseData = response.data as any
        
        if (responseData?.data?.activeStrategiesResponse) {
          console.log("✅ MyStrategyPage: Strategies received:", responseData.data.activeStrategiesResponse.length)
          setActiveStrategies(responseData.data.activeStrategiesResponse)
        } else if (responseData?.activeStrategiesResponse) {
          // Fallback: check if data is directly on responseData
          console.log("✅ MyStrategyPage: Strategies received (fallback):", responseData.activeStrategiesResponse.length)
          setActiveStrategies(responseData.activeStrategiesResponse)
        } else {
          console.warn("⚠️ MyStrategyPage: No strategies in response:", responseData)
          setError("No strategies found in response")
        }
      } else {
        console.error("❌ MyStrategyPage: API call failed:", response.error)
        setError(response.error?.message || "Failed to fetch strategies")
      }
    } catch (error) {
      console.error("❌ MyStrategyPage: Exception during API call:", error)
      setError(error instanceof Error ? error.message : "An unexpected error occurred")
    } finally {
      setLoading(false)
    }
  }, [token, isAuthenticated, ensureUserId])

  const tabs = ["Deployed Algos", "Positions", "OrderBook", "Performance Report"]

  // Fetch custom orders from API - same pattern as fetchActiveStrategies
  const fetchCustomOrders = useCallback(async (date: string) => {
    if (!token || !isAuthenticated) {
      console.warn("MyStrategyPage: Skipping fetchCustomOrders - user not authenticated")
      setCustomOrdersLoading(false)
      return
    }

    // Ensure userId is available - call check API if needed
    const currentUserId = useAuthStore.getState().userId
    if (!currentUserId) {
      const hasUserId = await ensureUserId()
      if (!hasUserId) {
        setCustomOrdersLoading(false)
        return
      }
    }

    const finalUserId = useAuthStore.getState().userId
    if (!finalUserId) {
      console.warn("MyStrategyPage: userId still not available after check API")
      setCustomOrdersLoading(false)
      return
    }

    setCustomOrdersLoading(true)
    setError(null)
    
    try {
      console.log("📡 MyStrategyPage: Calling getCustomOrders API with date:", date)
      const response = await strategyService.getCustomOrders({ customDate: date })
      console.log("📡 MyStrategyPage: getCustomOrders API Response:", response)
      
      if (response.success && response.data) {
        // API returns data as an array directly
        const ordersData = Array.isArray(response.data) ? response.data : []
        
        // Transform to match table structure
        const transformedOrders = ordersData.map((order: any, index: number) => ({
          srNo: index + 1,
          strategyName: order.sname || order.strategyName || "",
          dateTime: order.dateTime || "",
          symbol: order.symbol || "",
          quantity: order.quantity || 0,
          price: order.price || 0,
          status: order.status || "",
          id: order.orderId || order.id || index,
          sno: order.sno || "",
        }))
        
        console.log("✅ MyStrategyPage: Orders received:", transformedOrders.length)
        setCustomOrders(transformedOrders)
      } else {
        console.warn("⚠️ MyStrategyPage: No orders in response or API failed")
        setCustomOrders([])
        if (response.error) {
          const errorMsg = response.error.message || "Failed to fetch orders"
          setError(errorMsg)
          console.error("Failed to fetch custom orders:", errorMsg)
        }
      }
    } catch (err) {
      console.error("❌ MyStrategyPage: Exception during getCustomOrders API call:", err)
      const errorMsg = err instanceof Error ? err.message : "An unexpected error occurred"
      setError(errorMsg)
      setCustomOrders([])
    } finally {
      setCustomOrdersLoading(false)
    }
  }, [token, isAuthenticated, ensureUserId])

  // Refs to prevent duplicate API calls
  const strategiesFetchedRef = useRef<string | null>(null)
  const isFetchingStrategiesRef = useRef(false)

  // Fetch active strategies only once when token/userId is ready
  useEffect(() => {
    const fetchKey = `${token ? 'authenticated' : 'unauthenticated'}-${userId || 'no-user'}`
    
    // Skip if already fetched or currently fetching
    if (strategiesFetchedRef.current === fetchKey || isFetchingStrategiesRef.current) {
      return
    }

    if (token && isAuthenticated) {
      isFetchingStrategiesRef.current = true
      const initializeAndFetch = async () => {
        try {
          const currentUserId = useAuthStore.getState().userId
          if (!currentUserId) {
            await ensureUserId()
          }
          await fetchActiveStrategies()
          strategiesFetchedRef.current = fetchKey
        } catch (error) {
          console.error("Error fetching strategies:", error)
          strategiesFetchedRef.current = null
        } finally {
          isFetchingStrategiesRef.current = false
        }
      }
      initializeAndFetch()
    } else {
      setLoading(false)
    }
  }, [token, isAuthenticated, userId]) // Removed callback dependencies

  // Fetch reports when Reports tab is active - same pattern as fetchActiveStrategies
  const fetchReports = useCallback(async () => {
    if (!token || !isAuthenticated) {
      console.warn("MyStrategyPage: Skipping fetchReports - user not authenticated")
      setReportsLoading(false)
      return
    }

    // Ensure userId is available - call check API if needed
    const currentUserId = useAuthStore.getState().userId
    if (!currentUserId) {
      const hasUserId = await ensureUserId()
      if (!hasUserId) {
        setReportsLoading(false)
        return
      }
    }

    const finalUserId = useAuthStore.getState().userId
    if (!finalUserId) {
      console.warn("MyStrategyPage: userId still not available after check API")
      setReportsLoading(false)
      return
    }

    setReportsLoading(true)
    setError(null)
    
    try {
      console.log("📡 MyStrategyPage: Calling getAllReports API")
      const response = await reportsService.getAllReports()
      console.log("📡 MyStrategyPage: getAllReports API Response:", response)
      
      if (response.success && response.data) {
        // Handle different possible response structures
        let reportsData: ReportData[] = []
        
        // Check if response.data has reports directly (client extracts inner data)
        if (response.data && typeof response.data === 'object' && 'reports' in response.data) {
          const directData = response.data as { reports?: ReportData[], totalPnl?: number }
          reportsData = directData.reports || []
          console.log("✅ MyStrategyPage: Using direct reports structure")
        } 
        // Check if response.data is AllReportsResponse with nested data
        else if (response.data && typeof response.data === 'object' && 'data' in response.data) {
          const nestedData = response.data as AllReportsResponse
          reportsData = nestedData.data?.reports || []
          console.log("✅ MyStrategyPage: Using nested reports structure")
        }
        
        console.log("✅ MyStrategyPage: Reports received:", reportsData.length, "items")
        console.log("✅ MyStrategyPage: Reports data:", JSON.stringify(reportsData, null, 2))
        console.log("✅ MyStrategyPage: Full response:", JSON.stringify(response, null, 2))
        
        if (reportsData.length > 0) {
          setReports(reportsData)
          setError(null)
        } else {
          console.warn("⚠️ MyStrategyPage: No reports found in response")
          setReports([])
          setError("No reports data found in response")
        }
      } else {
        // API returned success: false - extract detailed error message
        let errorMsg = "Failed to fetch reports"
        
        if (response.error?.message) {
          errorMsg = response.error.message
        } else if (response.message) {
          errorMsg = response.message
        }
        
        console.warn("⚠️ MyStrategyPage: API returned error:", errorMsg, "Full response:", response)
        setError(errorMsg)
        setReports([])
      }
    } catch (err) {
      console.error("❌ MyStrategyPage: Exception during getAllReports API call:", err)
      let errorMsg = "An error occurred while fetching reports"
      
      if (err instanceof Error) {
        errorMsg = err.message
      } else if (typeof err === 'object' && err !== null && 'message' in err) {
        errorMsg = String((err as any).message)
      }
      
      setError(errorMsg)
      setReports([])
    } finally {
      setReportsLoading(false)
    }
  }, [token, isAuthenticated, ensureUserId])

  // Fetch detailed report for a specific strategy
  const fetchDetailedReport = useCallback(async (strategyId: number) => {
    if (!token || !isAuthenticated) {
      console.warn("MyStrategyPage: Skipping fetchDetailedReport - user not authenticated")
      return
    }

    setDetailedReportLoading(true)
    setDetailedReportDialogOpen(true)
    
    try {
      console.log("📡 MyStrategyPage: Calling getStrategyReports API for strategyId:", strategyId)
      const response = await reportsService.getStrategyReports({ strategyId })
      console.log("📡 MyStrategyPage: getStrategyReports API Response:", response)
      
      if (response.success && response.data) {
        setDetailedReportData(response.data)
      } else {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        let errorMsg = "Failed to fetch detailed report"
        if (response.error?.message) {
          errorMsg = response.error.message
        } else if (response.message) {
          errorMsg = response.message
        }
        setDetailedReportData(null)
      }
    } catch (err) {
      console.error("❌ MyStrategyPage: Exception during getStrategyReports API call:", err)
      setDetailedReportData(null)
    } finally {
      setDetailedReportLoading(false)
    }
  }, [token, isAuthenticated])

  // Refs to prevent duplicate report fetches
  const reportsFetchedRef = useRef<string | null>(null)
  const isFetchingReportsRef = useRef(false)

  // Fetch reports when Performance Report tab is active - only once per tab activation
  useEffect(() => {
    if (activeTab === "Performance Report" && token && isAuthenticated && userId) {
      const fetchKey = `reports-${userId}`
      
      // Skip if already fetched or currently fetching
      if (reportsFetchedRef.current === fetchKey || isFetchingReportsRef.current) {
        return
      }

      isFetchingReportsRef.current = true
      fetchReports().finally(() => {
        isFetchingReportsRef.current = false
        reportsFetchedRef.current = fetchKey
      })
    } else if (activeTab !== "Performance Report") {
      // Reset when switching away from Performance Report tab
      reportsFetchedRef.current = null
      setReportsLoading(false)
    }
  }, [activeTab, token, isAuthenticated, userId]) // Removed fetchReports dependency

  // Refs to prevent duplicate order fetches
  const ordersFetchedRef = useRef<string | null>(null)
  const isFetchingOrdersRef = useRef(false)

  // Fetch custom orders when OrderBook tab is active or date changes - only once per date
  useEffect(() => {
    if (activeTab === "OrderBook" && token && isAuthenticated && userId) {
      const fetchKey = `orders-${userId}-${selectedDate}`
      
      // Skip if already fetched for this date or currently fetching
      if (ordersFetchedRef.current === fetchKey || isFetchingOrdersRef.current) {
        return
      }

      isFetchingOrdersRef.current = true
      fetchCustomOrders(selectedDate).finally(() => {
        isFetchingOrdersRef.current = false
        ordersFetchedRef.current = fetchKey
      })
    } else if (activeTab !== "OrderBook") {
      // Reset when switching away from OrderBook tab
      ordersFetchedRef.current = null
      setCustomOrdersLoading(false)
    }
  }, [activeTab, selectedDate, token, isAuthenticated, userId]) // Removed fetchCustomOrders dependency

  // Listen for global search events from header
  useEffect(() => {
    const handleGlobalSearch = (event: CustomEvent) => {
      const { query, path } = event.detail
      // Only apply search if we're on the my-strategy page
      if (path === "/my-strategy") {
        setSearchQuery(query)
      }
    }

    // Check for search query from sessionStorage on mount
    const storedQuery = sessionStorage.getItem('globalSearchQuery')
    const storedPath = sessionStorage.getItem('globalSearchPath')
    if (storedQuery && storedPath === "/my-strategy") {
      setSearchQuery(storedQuery)
      // Clear after using
      sessionStorage.removeItem('globalSearchQuery')
      sessionStorage.removeItem('globalSearchPath')
    }

    window.addEventListener('globalSearch', handleGlobalSearch as EventListener)
    return () => window.removeEventListener('globalSearch', handleGlobalSearch as EventListener)
  }, [])

  // Filter strategies based on execution type and search query
  // Memoize filtered strategies to prevent recalculation on every render
  const filteredStrategies = useMemo(() => activeStrategies.filter((strategy: ActiveStrategy) => {
    const matchesExecution =
      activeToggle === "LIVE"
        ? strategy.execution === "LiveTrading"
        : strategy.execution === "PaperTrading"
    const matchesSearch = searchQuery
      ? strategy.name.toLowerCase().includes(searchQuery.toLowerCase())
      : true
    return matchesExecution && matchesSearch
  }), [activeStrategies, activeToggle, searchQuery])

  // Handle execution type change - show confirmation dialog first
  const handleExecutionTypeChange = useCallback((strategyId: number, newExecutionType: string) => {
    // Allow switching between LiveTrading and PaperTrading (Forward Test)
    if (newExecutionType === "PaperTrading" || newExecutionType === "LiveTrading") {
      // Store pending action and show confirmation dialog
      setPendingStrategyId(strategyId)
      setPendingExecutionType(newExecutionType)
      setConfirmDialogOpen(true)
    }
  }, [])

  // Confirm and execute the execution type change
  const confirmExecutionTypeChange = useCallback(async () => {
    if (!pendingStrategyId || !pendingExecutionType) return

    setConfirmDialogOpen(false)
    setActionLoading((prev: Record<number, boolean>) => ({ ...prev, [pendingStrategyId]: true }))
    
    try {
      let response
      if (pendingExecutionType === "PaperTrading") {
        // Switch to Forward Test
        response = await strategyService.switchToForwardTest(pendingStrategyId)
      if (response.success) {
        await fetchActiveStrategies()
      }
      } else if (pendingExecutionType === "LiveTrading") {
        // Switch to Live Trading
        response = await strategyService.switchToLiveTrading(pendingStrategyId)
        if (response.success) {
          await fetchActiveStrategies()
        }
      }
    } catch (error) {
      console.error("Switch failed:", error)
    } finally {
      setActionLoading((prev: Record<number, boolean>) => ({ ...prev, [pendingStrategyId]: false }))
      setPendingStrategyId(null)
      setPendingExecutionType(null)
    }
  }, [pendingStrategyId, pendingExecutionType, fetchActiveStrategies])

  // Cancel execution type change
  const cancelExecutionTypeChange = useCallback(() => {
    setConfirmDialogOpen(false)
    setPendingStrategyId(null)
    setPendingExecutionType(null)
  }, [])

  // Handle exit all strategies - show confirmation dialog first
  const handleExitAll = useCallback(() => {
    if (filteredStrategies.length === 0) {
      setError("No strategies to exit")
      return
    }
    setExitAllDialogOpen(true)
  }, [filteredStrategies.length])

  // Confirm and execute exit all
  const confirmExitAll = useCallback(async () => {
    setExitAllDialogOpen(false)
    
    // userId MUST come from auth store (populated by /ql/auth/check API response)
    // NO FALLBACKS - if userId is not in store, fail immediately
    if (!userId) {
      console.error("❌ MyStrategyPage: UserId not found in auth store. UserId must come from /ql/auth/check API response.")
      setError("User ID not found. Please refresh the page or login again.")
      return
    }

    setExitAllLoading(true)
    setError(null)
    
    try {
      const response = await strategyService.exitAllStrategies(userId)
      
      if (response.success) {
        // Refresh strategies after successful exit
        await fetchActiveStrategies()
      } else {
        setError(response.error?.message || "Failed to exit all strategies")
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : "An error occurred while exiting strategies")
    } finally {
      setExitAllLoading(false)
    }
  }, [userId, token, fetchActiveStrategies])

  // Cancel exit all
  const cancelExitAll = useCallback(() => {
    setExitAllDialogOpen(false)
  }, [])

  // Handle multiplier change - show confirmation dialog first
  const handleMultiplierChange = useCallback((strategyId: number, newMultiplier: number, executionType: string, strategyName: string) => {
    // Validate multiplier (should be between 1 and 100)
    if (newMultiplier < 1 || newMultiplier > 100) {
      return
    }

    // Store pending change and show confirmation dialog
    setPendingMultiplier({ strategyId, multiplier: newMultiplier, executionType, strategyName })
    setMultiplierDialogOpen(true)
  }, [])

  // Confirm and execute multiplier change
  const confirmMultiplierChange = useCallback(async () => {
    if (!pendingMultiplier) return

    const strategyIdToScroll = pendingMultiplier.strategyId
    setMultiplierDialogOpen(false)
    setMultiplierLoading((prev: Record<number, boolean>) => ({ ...prev, [strategyIdToScroll]: true }))
    
    try {
      const response = await strategyService.changeMultiplier({
        strategyId: pendingMultiplier.strategyId,
        multiplier: pendingMultiplier.multiplier,
        executionTypeId: pendingMultiplier.executionType,
      })
      
      if (response.success) {
        // Refresh strategies after successful change
        await fetchActiveStrategies()
        
        // Scroll back to the updated strategy row after a short delay to ensure DOM is updated
        setTimeout(() => {
          const rowElement = document.querySelector(`[data-strategy-id="${strategyIdToScroll}"]`)
          if (rowElement) {
            rowElement.scrollIntoView({ behavior: 'smooth', block: 'center' })
          }
        }, 100)
      }
    } catch (error) {
      console.error("Update error:", error)
    } finally {
      setMultiplierLoading((prev: Record<number, boolean>) => ({ ...prev, [strategyIdToScroll]: false }))
      setPendingMultiplier(null)
    }
  }, [pendingMultiplier, fetchActiveStrategies])

  // Cancel multiplier change
  const cancelMultiplierChange = useCallback(() => {
    setMultiplierDialogOpen(false)
    setPendingMultiplier(null)
  }, [])

  // Handle Actions: Undeploy, Exit, Standby, Edit, Logs
  const handleAction = useCallback(async (actionType: string, strategyId: number, strategyName: string) => {
    // Edit action should call API directly without confirmation (it's just fetching data)
    if (actionType === "edit") {
      setActionLoading((prev: Record<number, boolean>) => ({ ...prev, [strategyId]: true }))
      try {
        const response = await strategyService.getEditStrategy({ strategyId })
        if (response.success) {
          console.log("📡 Edit Strategy Response:", response)
          // Navigate to create-strategy page with strategyId for editing
          // The create-strategy page can use the strategyId to load and edit the strategy
          navigate(`/create-strategy?strategyId=${strategyId}&mode=edit`)
        }
      } catch (error) {
        console.error("Edit failed:", error)
      } finally {
        setActionLoading((prev: Record<number, boolean>) => ({ ...prev, [strategyId]: false }))
      }
      return
    }
    
    // For other actions, show confirmation dialog
    setPendingAction({ type: actionType, strategyId, strategyName })
    setActionDialogOpen(true)
  }, [])

  const confirmAction = useCallback(async () => {
    if (!pendingAction) return

    const { type, strategyId, strategyName: _strategyName } = pendingAction
    setActionDialogOpen(false)
    setActionLoading((prev: Record<number, boolean>) => ({ ...prev, [strategyId]: true }))

    try {
      let response
      switch (type) {
        case "undeploy":
          response = await strategyService.undeployStrategy(strategyId)
          if (response.success) {
            await fetchActiveStrategies()
          }
          break

        case "exit":
          response = await strategyService.exitStrategy({ strategyId, signalId: null })
          if (response.success) {
            await fetchActiveStrategies()
          }
          break

        case "standby":
          response = await strategyService.setStandby(strategyId)
          if (response.success) {
            await fetchActiveStrategies()
          }
          break

        case "resume":
          response = await strategyService.setStandby(strategyId)
          if (response.success) {
            await fetchActiveStrategies()
          }
          break

        case "restart":
          response = await errorManagementService.retryStrategy(strategyId)
          if (response.success) {
            await fetchActiveStrategies()
          }
          break

        case "edit":
          // This case should not be reached as edit is handled directly in handleAction
          // But keeping it as fallback
          response = await strategyService.getEditStrategy({ strategyId })
          if (response.success) {
            console.log("📡 Edit Strategy Response:", response)
            // TODO: Navigate to edit page or show edit dialog with the data
          }
          break

        default:
          console.error("Unknown action type:", type)
      }
    } catch (error) {
      console.error("Action failed:", error)
    } finally {
      setActionLoading((prev: Record<number, boolean>) => ({ ...prev, [strategyId]: false }))
      setPendingAction(null)
    }
  }, [pendingAction, fetchActiveStrategies])

  const cancelAction = useCallback(() => {
    setActionDialogOpen(false)
    setPendingAction(null)
  }, [])

  // Handle Error Management Actions
  const handleErrorAction = useCallback(async (actionType: 'manuallyTraded' | 'retry' | 'closePartialLegs', strategyId: number, strategyName: string) => {
    setErrorActionLoading((prev: Record<number, boolean>) => ({ ...prev, [strategyId]: true }))
    
    try {
      let response
      let successMessage = ''
      
      switch (actionType) {
        case 'manuallyTraded':
          response = await errorManagementService.markAsManuallyTraded(strategyId)
          successMessage = 'Strategy marked as manually traded successfully'
          break
        case 'retry':
          response = await errorManagementService.retryStrategy(strategyId)
          successMessage = 'Strategy retry initiated successfully'
          break
        case 'closePartialLegs':
          response = await errorManagementService.markAsCancelled(strategyId)
          successMessage = 'Partial legs closed successfully'
          break
        default:
          throw new Error('Unknown error action type')
      }
      
      if (response.success) {
        toastr.success(successMessage)
        await fetchActiveStrategies()
      } else {
        const errorMsg = response.error?.message || `Failed to ${actionType}`
        toastr.error(errorMsg)
      }
    } catch (error) {
      console.error(`Error action ${actionType} failed:`, error)
      toastr.error(`Failed to ${actionType}. Please try again.`)
    } finally {
      setErrorActionLoading((prev: Record<number, boolean>) => ({ ...prev, [strategyId]: false }))
    }
  }, [fetchActiveStrategies])

  // Handle Logs
  const handleLogs = useCallback(async (strategyId: number, _strategyName: string) => {
    setLogsDialogOpen(true)
    setLogsLoading(true)
    setLogsData(null)

    try {
      const response = await strategyService.getStrategyLogs({ strategyId })
      if (response.success && response.data) {
        // Handle nested response structure: response.data.data or response.data
        const logsResponse = response.data as any
        const actualData = logsResponse.data || logsResponse
        setLogsData(actualData)
        setLogsData(actualData)
      } else {
        setLogsData(null)
      }
    } catch (error) {
      console.error("Logs failed:", error)
      setLogsData(null)
    } finally {
      setLogsLoading(false)
    }
  }, [])

  // Memoize stats calculations to prevent recalculation
  const stats = useMemo(() => {
    const count = filteredStrategies.length
    const capital = filteredStrategies.reduce((sum: number, strategy: ActiveStrategy) => sum + (strategy.capital || 0), 0)
    const mtm = filteredStrategies.reduce((sum: number, strategy: ActiveStrategy) => sum + (strategy.strategyMtm || 0), 0)
    return { count, capital, mtm }
  }, [filteredStrategies])
  
  const activeStrategyCount = stats.count
  const deployedCapital = stats.capital
  const totalMtm = stats.mtm

  // Format deployed capital (in lakhs)
  const formatCapital = (amount: number) => {
    if (amount >= 100000) {
      return `${(amount / 100000).toFixed(2)}L`
    }
    return `${(amount / 1000).toFixed(2)}K`
  }

  // Format P&L
  const formatPnL = (amount: number) => {
    if (amount >= 100000) {
      return `${(amount / 100000).toFixed(2)}L`
    }
    if (amount >= 1000) {
      return `${(amount / 1000).toFixed(2)}K`
    }
    return amount.toFixed(2)
  }

  // Format status text - show "Deployed" when status is "Active"
  const formatStatus = (status: string | undefined | null): string => {
    if (!status) return ""
    const statusLower = status.toLowerCase()
    if (statusLower === "active") {
      return "Deployed"
    }
    return status.charAt(0).toUpperCase() + status.slice(1).toLowerCase()
  }

  // Get status color class
  const getStatusColor = (status: string | undefined | null): string => {
    if (!status) return "bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200"
    const statusLower = status.toLowerCase()
    if (statusLower === "active" || statusLower === "deployed") {
      return "bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400"
    }
    if (statusLower === "undeployed") {
      return "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400"
    }
    if (statusLower === "error" || statusLower === "failed") {
      return "bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400"
    }
    return "bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200"
  }

  // Extract order book data from strategyLegTableDTO if available (fallback)
  // Only use data from API - no fallback values
  const orderBookDataFromStrategies = filteredStrategies.flatMap((strategy: ActiveStrategy, strategyIndex: number) => {
    const legData = strategy.strategyLegTableDTO?.data
    if (legData && Array.isArray(legData) && legData.length > 0) {
      return legData
        .filter((order: any) => order && typeof order === 'object') // Only include valid order objects
        .map((order: any, index: number) => ({
          srNo: strategyIndex * 1000 + index + 1,
          strategyName: strategy.name,
          dateTime: order.dateTime || order.entryTime || strategy.deployedOn || "",
          symbol: order.symbol || order.tradedInstrument || "",
          quantity: order.quantity || order.tradedLots || 0,
          price: order.price || order.entryPrice || "",
          status: order.status || strategy.status || "",
          id: order.id || order.legId || strategy.sid,
        }))
    }
    return []
  })

  // Use custom orders from API if available, otherwise fallback to strategy data
  const orderBookData = customOrders.length > 0 ? customOrders : orderBookDataFromStrategies

  // Extract positions data from strategyLegTableDTO if available
  // Only use data from API - no fallback values
  const positionsData = filteredStrategies.flatMap((strategy: ActiveStrategy) => {
    const legData = strategy.strategyLegTableDTO?.data
    if (legData && Array.isArray(legData) && legData.length > 0) {
      return legData
        .filter((position: any) => position && typeof position === 'object') // Only include valid position objects
        .map((position: any) => ({
          symbol: position.symbol || "",
          strike: position.strike || position.tradedInstrument || "",
          quantity: position.quantity || position.tradedLots || "",
          mtm: position.mtm || (position.pnl !== undefined ? `₹${position.pnl}` : ""),
          expiry: position.expiry || "",
          dateTime: position.dateTime || position.entryTime || strategy.deployedOn || "",
        }))
    }
    return []
  })

  // Handle download for orders/positions
  const handleDownload = useCallback((type: 'orders' | 'positions') => {
    try {
      let data: any[] = []
      let filename = ''
      
      if (type === 'orders') {
        data = orderBookData
        filename = 'orders.csv'
      } else if (type === 'positions') {
        data = positionsData
        filename = 'positions.csv'
      }

      if (data.length === 0) {
        toastr.error("No Data", `No ${type} data available to download`)
        return
      }

      // Convert data to CSV
      const headers = Object.keys(data[0] || {})
      const csvContent = [
        headers.join(','),
        ...data.map((row: any) => headers.map((header: string) => {
          const value = row[header] || ''
          return typeof value === 'string' && value.includes(',') ? `"${value}"` : value
        }).join(','))
      ].join('\n')

      // Create blob and download
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
      const link = document.createElement('a')
      const url = URL.createObjectURL(blob)
      link.setAttribute('href', url)
      link.setAttribute('download', filename)
      link.style.visibility = 'hidden'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      toastr.success("Download Successful", `${type.charAt(0).toUpperCase() + type.slice(1)} downloaded successfully`)
    } catch (error) {
      toastr.error("Download Failed", error instanceof Error ? error.message : "Failed to download")
    }
  }, [orderBookData, positionsData])

  // Pagination constants
  const itemsPerPage = 10

  // Sorting function
  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc'
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc'
    } else if (sortConfig.key === key && sortConfig.direction === 'desc') {
      // Reset to no sort
      setSortConfig({ key: null, direction: null })
      return
    }
    setSortConfig({ key, direction })
    setCurrentPage(1) // Reset to first page when sorting
  }

  // Memoized sort data function
  const sortData = useCallback((data: any[]) => {
    if (!sortConfig.key || !sortConfig.direction) {
      return data
    }

    const sorted = [...data].sort((a, b) => {
      let aValue = a[sortConfig.key!]
      let bValue = b[sortConfig.key!]

      // Handle numeric values
      if (sortConfig.key === 'srNo' || sortConfig.key === 'quantity' || sortConfig.key === 'id') {
        aValue = Number(aValue) || 0
        bValue = Number(bValue) || 0
      }
      // Handle price values (remove currency symbols)
      else if (sortConfig.key === 'price' || sortConfig.key === 'pnl' || sortConfig.key === 'mtm' || sortConfig.key === 'strategyMtm') {
        aValue = typeof aValue === 'string' ? parseFloat(aValue.replace(/[₹,]/g, '')) || 0 : Number(aValue) || 0
        bValue = typeof bValue === 'string' ? parseFloat(bValue.replace(/[₹,]/g, '')) || 0 : Number(bValue) || 0
      }
      // Handle percentage values (remove % symbol)
      else if (sortConfig.key === 'roi') {
        aValue = typeof aValue === 'string' ? parseFloat(aValue.replace(/[%,]/g, '')) || 0 : Number(aValue) || 0
        bValue = typeof bValue === 'string' ? parseFloat(bValue.replace(/[%,]/g, '')) || 0 : Number(bValue) || 0
      }
      // Handle date values
      else if (sortConfig.key === 'dateTime' || sortConfig.key === 'deployedOn' || sortConfig.key === 'expiry') {
        aValue = aValue ? new Date(aValue).getTime() : 0
        bValue = bValue ? new Date(bValue).getTime() : 0
      }
      // Handle string values
      else {
        aValue = String(aValue || '').toLowerCase()
        bValue = String(bValue || '').toLowerCase()
      }

      if (aValue < bValue) {
        return sortConfig.direction === 'asc' ? -1 : 1
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'asc' ? 1 : -1
      }
      return 0
    })

    return sorted
  }, [sortConfig.key, sortConfig.direction])

  // Memoized paginated data function
  // Merge status from activeStrategies into reports
  const reportsWithStatus = useMemo(() => {
    return reports.map((report: any) => {
      // Find matching strategy in activeStrategies by id
      const matchingStrategy = activeStrategies.find((strategy: ActiveStrategy) => strategy.sid === report.id)
      
      if (matchingStrategy) {
        // If status is "available" but report has PNL data, mark as "Undeployed"
        if (matchingStrategy.status?.toLowerCase() === "available" && report.pnl !== undefined && report.pnl !== null) {
          return {
            ...report,
            status: "Undeployed"
          }
        }
        // Otherwise use the status from activeStrategies
        return {
          ...report,
          status: matchingStrategy.status || "Unknown"
        }
      }
      
      // If no match found but has PNL data, mark as "Undeployed"
      if (report.pnl !== undefined && report.pnl !== null) {
        return {
          ...report,
          status: "Undeployed"
        }
      }
      
      // Default status
      return {
        ...report,
        status: "Unknown"
      }
    })
  }, [reports, activeStrategies])

  const getPaginatedData = useCallback(() => {
    let data: any[] = []
    if (activeTab === "Performance Report") {
      data = reportsWithStatus.map((report: any, index: number) => ({
        ...report,
        srNo: index + 1 // Add srNo for sorting
      }))
    } else if (activeTab === "Deployed Algos") {
      data = filteredStrategies.map((strategy: ActiveStrategy, index: number) => ({
        ...strategy,
        srNo: index + 1 // Add srNo for sorting
      }))
    } else if (activeTab === "OrderBook") {
      data = orderBookData
    } else if (activeTab === "Positions") {
      data = positionsData.map((position: any, index: number) => ({
        ...position,
        srNo: index + 1 // Add srNo for sorting
      }))
    }
    
    // Apply sorting
    data = sortData(data)
    
    // For Performance Report tab, return all data without pagination
    if (activeTab === "Performance Report") {
      return data
    }
    
    // For other tabs, apply pagination
    const startIndex = (currentPage - 1) * itemsPerPage
    const endIndex = startIndex + itemsPerPage
    return data.slice(startIndex, endIndex)
  }, [activeTab, reportsWithStatus, filteredStrategies, orderBookData, positionsData, sortData, currentPage])

  // Memoized total pages calculation
  const totalPages = useMemo(() => {
    let totalItems = 0
    if (activeTab === "Performance Report") {
      totalItems = reportsWithStatus.length
    } else if (activeTab === "Deployed Algos") {
      totalItems = filteredStrategies.length
    } else if (activeTab === "OrderBook") {
      totalItems = orderBookData.length
    } else if (activeTab === "Positions") {
      totalItems = positionsData.length
    }
    return Math.ceil(totalItems / itemsPerPage)
  }, [activeTab, reportsWithStatus.length, filteredStrategies.length, orderBookData.length, positionsData.length])

  // Reset to page 1 when tab changes or search query changes
  useEffect(() => {
    setCurrentPage(1)
    setSortConfig({ key: null, direction: null }) // Reset sort when tab changes
  }, [activeTab, searchQuery, activeToggle])

  // Calendar helper functions
  const getDaysInMonth = useCallback((date: Date) => {
    const year = date.getFullYear()
    const month = date.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDayOfWeek = firstDay.getDay()
    
    const days: Array<{ date: Date; isCurrentMonth: boolean; hasData: boolean; pnl: number | null; isSelected: boolean }> = []
    
    // Add previous month's trailing days
    const prevMonth = new Date(year, month, 0)
    const prevMonthDays = prevMonth.getDate()
    for (let i = startingDayOfWeek - 1; i >= 0; i--) {
      const date = new Date(year, month - 1, prevMonthDays - i)
      days.push({ date, isCurrentMonth: false, hasData: false, pnl: null, isSelected: false })
    }
    
    // Add current month's days
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day)
      const dateStr = date.toISOString().split('T')[0]
      
      // Check if this date has any report data (we'll need to get this from detailed reports)
      // For now, we'll check if any report exists (simplified - in real implementation, we'd need date-based PNL data)
      const hasData = false // Will be calculated from actual data
      const pnl = null // Will be calculated from actual data
      const isSelected = selectedCalendarDate && 
        date.getDate() === selectedCalendarDate.getDate() &&
        date.getMonth() === selectedCalendarDate.getMonth() &&
        date.getFullYear() === selectedCalendarDate.getFullYear()
      
      days.push({ date, isCurrentMonth: true, hasData, pnl, isSelected })
    }
    
    // Add next month's leading days to fill the grid
    const remainingDays = 42 - days.length // 6 rows * 7 days
    for (let day = 1; day <= remainingDays; day++) {
      const date = new Date(year, month + 1, day)
      days.push({ date, isCurrentMonth: false, hasData: false, pnl: null, isSelected: false })
    }
    
    return days
  }, [selectedCalendarDate])

  // Get calendar data for a specific month
  const getCalendarData = useCallback((monthDate: Date) => {
    // This will be populated with actual date-based PNL data from detailed reports
    // For now, return empty structure
    return getDaysInMonth(monthDate)
  }, [getDaysInMonth])

  // Handle calendar date click
  const handleCalendarDateClick = useCallback((date: Date) => {
    setSelectedCalendarDate(date)
    setDayDetailsPanelOpen(true)
    // TODO: Fetch day-specific data from API or filter from existing data
    // For now, set empty array
    setDayDetailsData([])
  }, [])

  // Filter day details data based on filters
  const filteredDayDetailsData = useMemo(() => {
    let filtered = [...dayDetailsData]
    
    // Filter by strategy name
    if (dayDetailsFilters.strategyName) {
      filtered = filtered.filter((item: any) => 
        (item.strategyName || "").toLowerCase().includes(dayDetailsFilters.strategyName.toLowerCase())
      )
    }
    
    // Filter by P&L range
    if (dayDetailsFilters.pnlRange === "Profit Only") {
      filtered = filtered.filter((item: any) => (item.pnl || 0) > 0)
    } else if (dayDetailsFilters.pnlRange === "Loss Only") {
      filtered = filtered.filter((item: any) => (item.pnl || 0) < 0)
    } else if (dayDetailsFilters.pnlRange === "Above ₹5,000") {
      filtered = filtered.filter((item: any) => (item.pnl || 0) > 5000)
    } else if (dayDetailsFilters.pnlRange === "Below ₹-5,000") {
      filtered = filtered.filter((item: any) => (item.pnl || 0) < -5000)
    }
    
    // Filter by status
    if (dayDetailsFilters.status !== "All") {
      filtered = filtered.filter((item: any) => 
        (item.status || "").toLowerCase() === dayDetailsFilters.status.toLowerCase()
      )
    }
    
    // Sort
    if (dayDetailsFilters.sortBy === "P&L (High to Low)") {
      filtered.sort((a: any, b: any) => (b.pnl || 0) - (a.pnl || 0))
    } else if (dayDetailsFilters.sortBy === "P&L (Low to High)") {
      filtered.sort((a: any, b: any) => (a.pnl || 0) - (b.pnl || 0))
    } else if (dayDetailsFilters.sortBy === "Strategy Name (A-Z)") {
      filtered.sort((a: any, b: any) => (a.strategyName || "").localeCompare(b.strategyName || ""))
    } else if (dayDetailsFilters.sortBy === "Strategy Name (Z-A)") {
      filtered.sort((a: any, b: any) => (b.strategyName || "").localeCompare(a.strategyName || ""))
    }
    
    return filtered
  }, [dayDetailsData, dayDetailsFilters])

  // Helper function to render sort icons
  const renderSortIcons = (columnKey: string, size: 'small' | 'medium' = 'small') => {
    const isActive = sortConfig.key === columnKey
    const isAsc = isActive && sortConfig.direction === 'asc'
    const isDesc = isActive && sortConfig.direction === 'desc'
    const iconSize = size === 'medium' ? 'w-3 h-3' : 'w-2.5 h-2.5'
    
    return (
      <div className="flex flex-col -space-y-1">
        <ChevronUp 
          className={`${iconSize} transition-colors ${
            isAsc ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400 dark:text-gray-500'
          }`} 
        />
        <ChevronDown 
          className={`${iconSize} transition-colors ${
            isDesc ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400 dark:text-gray-500'
          }`} 
        />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#F5F5F5] dark:bg-gray-950">
      <Header />
      <main className="pt-16 pb-5">
        <div className="max-w-[1600px] mx-auto px-8 sm:px-12 lg:px-28">
          {/* Header Section */}
          <div className="flex items-start justify-between mb-3">
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-0.5">Track & Manage Your Algo</h1>
              <p className="text-gray-500 dark:text-gray-400 text-xs">
                Get a complete overview of your strategies, performance, positions, and order activity.
              </p>
            </div>
            <div className="flex items-center gap-3">
              {/* Forward/Live Toggle */}
              <div className="flex items-center p-1 rounded-lg bg-[#E8EAFF] dark:bg-gray-800">
                <button
                  onClick={() => setActiveToggle("FORWARD")}
                  className={`px-3 py-1 text-xs font-medium transition rounded-md ${
                    activeToggle === "FORWARD" ? "bg-[#5266FC] dark:bg-blue-500 text-white" : "text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100"
                  }`}
                >
                  FORWARD
                </button>
                <button
                  onClick={() => setActiveToggle("LIVE")}
                  className={`px-3 py-1 text-xs font-medium transition rounded-md ${
                    activeToggle === "LIVE" ? "bg-[#5266FC] dark:bg-blue-500 text-white" : "text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100"
                  }`}
                >
                  LIVE
                </button>
              </div>
              {/* Refresh Button */}
              <button 
                onClick={fetchActiveStrategies}
                disabled={loading}
                className="px-3 py-1.5 border border-blue-400 dark:border-blue-500 text-blue-500 dark:text-blue-400 bg-white dark:bg-gray-800 rounded-md text-xs font-medium hover:bg-blue-50 dark:hover:bg-blue-900/30 transition whitespace-nowrap disabled:opacity-50"
              >
                {loading ? "Loading..." : "Refresh"}
              </button>
              {/* Exit All Button */}
              <button 
                onClick={handleExitAll}
                disabled={exitAllLoading || filteredStrategies.length === 0 || loading}
                className="px-3 py-1.5 border border-red-400 dark:border-red-500 text-red-500 dark:text-red-400 bg-white dark:bg-gray-800 rounded-md text-xs font-medium hover:bg-red-50 dark:hover:bg-red-900/30 transition whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5"
              >
                {exitAllLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Exiting...
                  </>
                ) : (
                  "Exit all"
                )}
              </button>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-4 gap-2.5 mb-3">
            {/* Active Strategy Card */}
            <div className="py-2 px-2.5 border border-gray-200 dark:border-gray-700 rounded-md flex items-center justify-between bg-white dark:bg-gray-800">
              <div className="flex flex-col gap-0 justify-start items-start flex-1">
                <p className="text-lg font-bold text-gray-900 dark:text-gray-100">
                  {loading ? "..." : activeStrategyCount || 0}
                </p>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Active Strategy</p>
              </div>
              <div className="flex-shrink-0 ml-1.5">
                <img 
                  src="/images/img_strategy_1.gif" 
                  alt="Active Strategy"
                  className="w-12 h-12 sm:w-14 sm:h-14 object-contain"
                />
              </div>
            </div>

            {/* Deployed Capital Card */}
            <div className="py-2 px-2.5 border border-gray-200 dark:border-gray-700 rounded-md flex items-center justify-between bg-white dark:bg-gray-800">
              <div className="flex flex-col gap-0 justify-start items-start flex-1">
                <p className="text-lg font-bold text-gray-900 dark:text-gray-100">
                  {loading ? "..." : deployedCapital > 0 ? formatCapital(deployedCapital) : "₹0"}
                </p>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Deployed Capital</p>
              </div>
              <div className="flex-shrink-0 ml-1.5">
                <img 
                  src="/images/img_revenue_1.gif" 
                  alt="Deployed Capital"
                  className="w-12 h-12 sm:w-14 sm:h-14 object-contain"
                />
              </div>
            </div>

            {/* Today P&L Card */}
            <div className="py-2 px-2.5 border border-gray-200 dark:border-gray-700 rounded-md flex items-center justify-between bg-white dark:bg-gray-800">
              <div className="flex flex-col gap-0 justify-start items-start flex-1">
                <p className={`text-lg font-bold ${totalMtm >= 0 ? "text-green-500" : "text-red-500"}`}>
                  {loading ? "..." : totalMtm !== 0 ? formatPnL(totalMtm) : "₹0"}
                </p>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Today P&L</p>
              </div>
              <div className="flex-shrink-0 ml-1.5">
                <img 
                  src="/images/Profit1.gif" 
                  alt="Today P&L"
                  className="w-12 h-12 sm:w-14 sm:h-14 object-contain"
                />
              </div>
            </div>

            {/* Overall P&L Card */}
            <div className="py-2 px-2.5 border border-gray-200 dark:border-gray-700 rounded-md flex items-center justify-between bg-white dark:bg-gray-800">
              <div className="flex flex-col gap-0 justify-start items-start flex-1">
                <p className={`text-lg font-bold ${totalMtm >= 0 ? "text-green-500" : "text-red-500"}`}>
                  {loading ? "..." : totalMtm !== 0 ? formatPnL(totalMtm) : "₹0"}
                </p>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Overall P&L</p>
              </div>
              <div className="flex-shrink-0 ml-1.5">
                <img 
                  src="/images/InvestmentProfit.gif" 
                  alt="Overall P&L"
                  className="w-12 h-12 sm:w-14 sm:h-14 object-contain"
                />
              </div>
            </div>
          </div>

          {/* Tabs and Search */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-4">
            {/* Search - appears first on mobile, second on desktop */}
            <div className="relative order-1 md:order-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search Deployed Strategies"
                value={searchQuery}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
                className="pl-10 pr-3 py-1.5 border border-white dark:border-gray-700 bg-white dark:bg-gray-800 dark:text-gray-100 rounded-lg text-xs w-full md:w-64 focus:outline-none focus:border-[#5266FC] dark:focus:border-blue-500"
              />
            </div>
            {/* Tabs - appears second on mobile, first on desktop */}
            <div className="flex items-center gap-0 bg-white dark:bg-gray-800 order-2 md:order-1">
              {tabs.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-3 py-1.5 text-xs font-medium transition ${
                    activeTab === tab ? "bg-[#5266FC] dark:bg-blue-500 text-white" : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Table Header */}
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100">
              {activeTab === "Performance Report" ? "Performance Report" : activeTab === "Positions" ? "Positions" : activeTab === "OrderBook" ? "OrderBook" : "Deployed Algos"}
            </h2>
            <div className="flex items-center gap-2">
              {/* View Toggle for Performance Report */}
              {activeTab === "Performance Report" && (
                <div className="flex items-center gap-0 bg-[#E8EAFF] dark:bg-gray-700 p-1 rounded-lg mr-2">
                  <button
                    onClick={() => setCalendarViewMode("table")}
                    className={`px-3 py-1.5 text-xs font-medium rounded transition ${
                      calendarViewMode === "table" 
                        ? "bg-[#5266FC] dark:bg-blue-500 text-white" 
                        : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600"
                    }`}
                  >
                    📋 Table
                  </button>
                  <button
                    onClick={() => setCalendarViewMode("calendar")}
                    className={`px-3 py-1.5 text-xs font-medium rounded transition ${
                      calendarViewMode === "calendar" 
                        ? "bg-[#5266FC] dark:bg-blue-500 text-white" 
                        : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600"
                    }`}
                  >
                    📅 Calendar
                  </button>
                </div>
              )}
              {activeTab === "OrderBook" ? (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500 dark:text-gray-400">Date</span>
                  <input
                    type="date"
                    value={(() => {
                      // Convert UTC ISO string back to UTC date components for display
                      // This ensures the date picker shows the same date that was selected
                      const date = new Date(selectedDate)
                      const year = date.getUTCFullYear()
                      const month = String(date.getUTCMonth() + 1).padStart(2, '0')
                      const day = String(date.getUTCDate()).padStart(2, '0')
                      return `${year}-${month}-${day}`
                    })()}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                      const dateValue = e.target.value
                      if (dateValue) {
                        // Create date in UTC to avoid timezone issues
                        // dateValue is in format "YYYY-MM-DD" (date selected by user)
                        const [year, month, day] = dateValue.split('-').map(Number)
                        // Create UTC date at midnight for the selected date
                        const date = new Date(Date.UTC(year, month - 1, day, 0, 0, 0, 0))
                        const isoDate = date.toISOString()
                        setSelectedDate(isoDate)
                        // Don't call fetchCustomOrders here - useEffect will handle it
                      }
                    }}
                    className="px-2.5 py-1.5 border border-white dark:border-gray-700 bg-white dark:bg-gray-800 dark:text-gray-100 rounded-lg text-xs text-gray-700 focus:outline-none focus:border-[#5266FC] dark:focus:border-blue-500"
                  />
                </div>
              ) : activeTab !== "Performance Report" && (
                <>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500">From Date</span>
                    <div className="flex items-center gap-1.5 px-2.5 py-1.5 border border-white dark:border-gray-700 bg-white dark:bg-gray-800 rounded-lg">
                      <Calendar className="w-3.5 h-3.5 text-gray-400" />
                      <span className="text-xs text-gray-700">
                        {filteredStrategies.length > 0 
                          ? filteredStrategies[0]?.deployedOn || ""
                          : ""}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500">To Date</span>
                    <div className="flex items-center gap-1.5 px-2.5 py-1.5 border border-white dark:border-gray-700 bg-white dark:bg-gray-800 rounded-lg">
                      <Calendar className="w-3.5 h-3.5 text-gray-400" />
                      <span className="text-xs text-gray-700">
                        {new Date().toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                      </span>
                    </div>
                  </div>
                </>
              )}
              {activeTab !== "Performance Report" && (
                <button 
                  onClick={() => {
                    if (activeTab === "OrderBook") {
                      handleDownload('orders')
                    } else if (activeTab === "Positions") {
                      handleDownload('positions')
                    }
                  }}
                  className="p-2 text-[#5266FC] dark:text-blue-400 bg-white dark:bg-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition"
                >
                  <Download className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>

          {/* Performance Report Table */}
          {activeTab === "Performance Report" && calendarViewMode === "table" && (
            <div className="border border-gray-200 dark:border-gray-700 overflow-hidden bg-white dark:bg-gray-800">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[600px]">
                <thead className="bg-[#D6D9F6] dark:bg-gray-700">
                  <tr>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('srNo')}
                      >
                      <div className="flex items-center gap-1">
                        Sr.No
                        {renderSortIcons('srNo', 'medium')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('strategyName')}
                      >
                      <div className="flex items-center gap-1">
                        Strategy Name
                        {renderSortIcons('strategyName', 'medium')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('pnl')}
                      >
                      <div className="flex items-center gap-1">
                        P&L
                        {renderSortIcons('pnl', 'medium')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('status')}
                      >
                      <div className="flex items-center gap-1">
                        Status
                        {renderSortIcons('status', 'medium')}
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800">
                    {reportsLoading ? (
                      <tr>
                        <td colSpan={4} className="px-3 py-6 text-center text-gray-500 dark:text-gray-400">
                          <div className="flex items-center justify-center gap-2">
                            <Loader2 className="w-5 h-5 animate-spin text-[#5266FC] dark:text-blue-400" />
                            <span>Loading reports...</span>
                          </div>
                        </td>
                      </tr>
                    ) : error && activeTab === "Performance Report" ? (
                      <tr>
                        <td colSpan={4} className="px-4 py-8 text-center text-red-500 dark:text-red-400">
                          {error}
                        </td>
                      </tr>
                    ) : reportsWithStatus.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-4 py-8 text-center">
                          <div className="flex flex-col items-center justify-center">
                            <svg className="w-12 h-12 text-gray-400 dark:text-gray-500 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            <p className="text-gray-500 dark:text-gray-400 text-xs font-medium">No Reports Available</p>
                            <p className="text-gray-400 dark:text-gray-500 text-xs mt-1">There are no reports to display at the moment.</p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      getPaginatedData().map((report: any, index: number) => {
                        return (
                          <tr key={report.id || index} className="border-b border-gray-100 dark:border-gray-700 last:border-b-0 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">{report.srNo || (index + 1)}</td>
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">
                              <button
                                onClick={() => fetchDetailedReport(report.id)}
                                className="text-[#5266FC] dark:text-blue-400 hover:text-[#3d4fc7] dark:hover:text-blue-300 hover:underline cursor-pointer font-medium"
                              >
                                {report.strategyName || report.name || "N/A"}
                              </button>
                            </td>
                            <td className={`px-4 py-4 text-sm whitespace-nowrap font-medium ${(report.pnl || 0) >= 0 ? "text-green-500 dark:text-green-400" : "text-red-500 dark:text-red-400"}`}>
                              ₹{formatPnL(report.pnl || 0)}
                            </td>
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">
                              <span className={`inline-flex items-center px-3 py-1.5 rounded-md text-xs font-medium ${getStatusColor(report.status || "Unknown")}`}>
                                {formatStatus(report.status || "Unknown")}
                              </span>
                            </td>
                          </tr>
                        )
                      })
                    )}
                </tbody>
              </table>
              </div>
              
              {/* Show total entries count for Performance Report (no pagination) */}
              {activeTab === "Performance Report" && reportsWithStatus.length > 0 && (
                <div className="mt-4 px-4 text-sm text-gray-600 dark:text-gray-400">
                  Showing all {reportsWithStatus.length} {reportsWithStatus.length === 1 ? 'entry' : 'entries'}
                </div>
              )}
            </div>
          )}

          {/* Performance Report Calendar View */}
          {activeTab === "Performance Report" && calendarViewMode === "calendar" && (
            <div className="space-y-4">
              {/* Strategy Selector */}
              <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Select Strategy (or view All Strategies)
                </label>
                <select className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-sm focus:outline-none focus:border-[#5266FC] dark:focus:border-blue-500">
                  <option>All Strategies (Aggregated)</option>
                  {activeStrategies.map((strategy: ActiveStrategy) => (
                    <option key={strategy.sid} value={strategy.sid}>
                      {strategy.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Calendar Section */}
              <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6">
                {/* Calendar Header */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => {
                        const newMonth = new Date(calendarMonth)
                        newMonth.setMonth(newMonth.getMonth() - 1)
                        setCalendarMonth(newMonth)
                      }}
                      className="p-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 min-w-[200px] text-center">
                      {calendarMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                    </h3>
                    <button
                      onClick={() => {
                        const newMonth = new Date(calendarMonth)
                        newMonth.setMonth(newMonth.getMonth() + 1)
                        setCalendarMonth(newMonth)
                      }}
                      className="p-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-4 items-center">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                      <span className="text-sm text-gray-600 dark:text-gray-400">Profit Day</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-red-500"></div>
                      <span className="text-sm text-gray-600 dark:text-gray-400">Loss Day</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-gray-200 dark:bg-gray-600 border border-gray-300 dark:border-gray-500"></div>
                      <span className="text-sm text-gray-600 dark:text-gray-400">No Data (NA)</span>
                    </div>
                  </div>
                </div>

                {/* Calendar Grid */}
                <div className="grid grid-cols-7 gap-2">
                  {/* Day Headers */}
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                    <div key={day} className="text-center text-xs font-semibold text-gray-600 dark:text-gray-400 py-2">
                      {day}
                    </div>
                  ))}
                  
                  {/* Calendar Days */}
                  {getCalendarData(calendarMonth).map((day, index) => {
                    const dayDateStr = day.date.toISOString().split('T')[0]
                    // Check if this day has any report data (simplified - in real implementation, we'd need date-based PNL data)
                    // For now, we'll mark days as having no data (NA)
                    const hasData = false // TODO: Calculate from actual date-based PNL data
                    const pnl = null // TODO: Calculate from actual date-based PNL data
                    
                    return (
                      <div
                        key={index}
                        onClick={() => day.isCurrentMonth && handleCalendarDateClick(day.date)}
                        className={`
                          aspect-square border rounded-lg p-2 flex flex-col items-center justify-center cursor-pointer transition-all
                          ${!day.isCurrentMonth ? 'bg-gray-50 dark:bg-gray-900 text-gray-400 dark:text-gray-600 border-gray-200 dark:border-gray-700' : ''}
                          ${day.isCurrentMonth && !hasData ? 'bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:border-[#5266FC] dark:hover:border-blue-500' : ''}
                          ${day.isCurrentMonth && hasData && (pnl || 0) > 0 ? 'bg-green-50 dark:bg-green-900/20 border-green-300 dark:border-green-700 hover:border-green-500' : ''}
                          ${day.isCurrentMonth && hasData && (pnl || 0) < 0 ? 'bg-red-50 dark:bg-red-900/20 border-red-300 dark:border-red-700 hover:border-red-500' : ''}
                          ${day.isSelected ? 'ring-2 ring-[#5266FC] dark:ring-blue-500 bg-[#E8EAFF] dark:bg-blue-900/30' : ''}
                        `}
                      >
                        <span className={`text-sm font-semibold ${!day.isCurrentMonth ? 'text-gray-400' : 'text-gray-900 dark:text-gray-100'}`}>
                          {day.date.getDate()}
                        </span>
                        {day.isCurrentMonth && !hasData && (
                          <span className="text-[10px] text-gray-500 dark:text-gray-400 mt-1">NA</span>
                        )}
                        {day.isCurrentMonth && hasData && (
                          <div className={`w-1.5 h-1.5 rounded-full mt-1 ${(pnl || 0) > 0 ? 'bg-green-500' : 'bg-red-500'}`}></div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* Day Details Panel */}
              {dayDetailsPanelOpen && selectedCalendarDate && (
                <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6">
                  {/* Day Details Header */}
                  <div className="flex justify-between items-start mb-6 pb-4 border-b border-gray-200 dark:border-gray-700">
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Performance Details</h3>
                      <p className="text-base text-gray-600 dark:text-gray-400 mt-1">
                        {selectedCalendarDate.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setDayDetailsPanelOpen(false)
                        setSelectedCalendarDate(null)
                      }}
                      className="p-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Filters Section */}
                  <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-4 mb-6">
                    <div className="flex justify-between items-center mb-4">
                      <h4 className="text-sm font-semibold text-gray-900 dark:text-gray-100">🔍 Filter Strategies</h4>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Strategy Name</label>
                        <input
                          type="text"
                          value={dayDetailsFilters.strategyName}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDayDetailsFilters({ ...dayDetailsFilters, strategyName: e.target.value })}
                          placeholder="Search strategy..."
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-sm focus:outline-none focus:border-[#5266FC] dark:focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">P&L Range</label>
                        <select
                          value={dayDetailsFilters.pnlRange}
                          onChange={(e) => setDayDetailsFilters({ ...dayDetailsFilters, pnlRange: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-sm focus:outline-none focus:border-[#5266FC] dark:focus:border-blue-500"
                        >
                          <option>All</option>
                          <option>Profit Only</option>
                          <option>Loss Only</option>
                          <option>Above ₹5,000</option>
                          <option>Below ₹-5,000</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Status</label>
                        <select
                          value={dayDetailsFilters.status}
                          onChange={(e) => setDayDetailsFilters({ ...dayDetailsFilters, status: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-sm focus:outline-none focus:border-[#5266FC] dark:focus:border-blue-500"
                        >
                          <option>All</option>
                          <option>Active</option>
                          <option>Undeployed</option>
                          <option>Paused</option>
                          <option>Error</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Sort By</label>
                        <select
                          value={dayDetailsFilters.sortBy}
                          onChange={(e) => setDayDetailsFilters({ ...dayDetailsFilters, sortBy: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-sm focus:outline-none focus:border-[#5266FC] dark:focus:border-blue-500"
                        >
                          <option>P&L (High to Low)</option>
                          <option>P&L (Low to High)</option>
                          <option>Strategy Name (A-Z)</option>
                          <option>Strategy Name (Z-A)</option>
                        </select>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-4">
                      <button
                        onClick={() => {
                          // Filters are applied automatically via filteredDayDetailsData
                        }}
                        className="px-4 py-2 bg-[#5266FC] dark:bg-blue-500 text-white rounded-lg text-sm font-semibold hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition"
                      >
                        Apply Filters
                      </button>
                      <button
                        onClick={() => {
                          setDayDetailsFilters({
                            strategyName: "",
                            pnlRange: "All",
                            status: "All",
                            sortBy: "P&L (High to Low)"
                          })
                        }}
                        className="px-4 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg text-sm font-semibold hover:bg-gray-50 dark:hover:bg-gray-700 transition"
                      >
                        Reset
                      </button>
                    </div>
                  </div>

                  {/* Summary Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                    <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-4 text-center">
                      <div className="text-xs text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-2">Total P&L</div>
                      <div className={`text-2xl font-bold ${filteredDayDetailsData.reduce((sum: number, item: any) => sum + (item.pnl || 0), 0) >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        ₹{formatPnL(filteredDayDetailsData.reduce((sum: number, item: any) => sum + (item.pnl || 0), 0))}
                      </div>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-4 text-center">
                      <div className="text-xs text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-2">Active Strategies</div>
                      <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">{filteredDayDetailsData.length}</div>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-4 text-center">
                      <div className="text-xs text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-2">Winning</div>
                      <div className="text-2xl font-bold text-green-500">{filteredDayDetailsData.filter((item: any) => (item.pnl || 0) > 0).length}</div>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-4 text-center">
                      <div className="text-xs text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-2">Losing</div>
                      <div className="text-2xl font-bold text-red-500">{filteredDayDetailsData.filter((item: any) => (item.pnl || 0) < 0).length}</div>
                    </div>
                  </div>

                  {/* Strategies Table for Selected Day */}
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <h4 className="text-lg font-bold text-gray-900 dark:text-gray-100">
                        Strategy Performance on {selectedCalendarDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                      </h4>
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        Showing {filteredDayDetailsData.length} {filteredDayDetailsData.length === 1 ? 'strategy' : 'strategies'}
                      </span>
                    </div>
                    {filteredDayDetailsData.length === 0 ? (
                      <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                        No strategies found for this date
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead className="bg-[#D6D9F6] dark:bg-gray-700">
                            <tr>
                              <th className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200">Strategy Name</th>
                              <th className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200">P&L</th>
                              <th className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200">Status</th>
                              <th className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="bg-white dark:bg-gray-800">
                            {filteredDayDetailsData.map((item: any, index: number) => (
                              <tr key={index} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                                <td className="px-3 py-3 text-xs text-[#5266FC] dark:text-blue-400 font-medium cursor-pointer hover:underline">
                                  {item.strategyName || "N/A"}
                                </td>
                                <td className={`px-3 py-3 text-xs font-medium ${(item.pnl || 0) >= 0 ? 'text-green-500 dark:text-green-400' : 'text-red-500 dark:text-red-400'}`}>
                                  ₹{formatPnL(item.pnl || 0)}
                                </td>
                                <td className="px-3 py-3 text-xs">
                                  <span className={`inline-flex items-center px-3 py-1.5 rounded-md text-xs font-medium ${getStatusColor(item.status || "Unknown")}`}>
                                    {formatStatus(item.status || "Unknown")}
                                  </span>
                                </td>
                                <td className="px-3 py-3 text-xs">
                                  <button
                                    onClick={() => fetchDetailedReport(item.id)}
                                    className="px-3 py-1.5 bg-[#E8EAFF] dark:bg-blue-900/30 text-[#5266FC] dark:text-blue-400 rounded-lg text-xs font-semibold hover:bg-[#D3DAFF] dark:hover:bg-blue-900/50 transition"
                                  >
                                    View Details
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Positions Table */}
          {activeTab === "Positions" && (
            <div className="border border-gray-200 dark:border-gray-700 overflow-hidden bg-white dark:bg-gray-800">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[800px]">
                <thead className="bg-[#D6D9F6] dark:bg-gray-700">
                  <tr>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('symbol')}
                      >
                        <div className="flex items-center gap-1">
                          Symbol
                          {renderSortIcons('symbol', 'medium')}
                        </div>
                      </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('strike')}
                      >
                        <div className="flex items-center gap-1">
                          Strike
                          {renderSortIcons('strike', 'medium')}
                        </div>
                      </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('quantity')}
                      >
                        <div className="flex items-center gap-1">
                          Quantity
                          {renderSortIcons('quantity', 'medium')}
                        </div>
                      </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('mtm')}
                      >
                        <div className="flex items-center gap-1">
                          MTM
                          {renderSortIcons('mtm', 'medium')}
                        </div>
                      </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('expiry')}
                      >
                        <div className="flex items-center gap-1">
                          Expiry
                          {renderSortIcons('expiry', 'medium')}
                        </div>
                      </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('dateTime')}
                      >
                        <div className="flex items-center gap-1">
                          Date & Time
                          {renderSortIcons('dateTime', 'medium')}
                        </div>
                      </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800">
                    {loading ? (
                      <tr>
                        <td colSpan={6} className="px-4 py-8 text-center text-gray-500 dark:text-gray-400">
                          Loading positions...
                        </td>
                      </tr>
                    ) : positionsData.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-4 py-8 text-center">
                          <div className="flex flex-col items-center justify-center">
                            <svg className="w-12 h-12 text-gray-400 dark:text-gray-500 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                            </svg>
                            <p className="text-gray-500 dark:text-gray-400 text-sm font-medium">No Positions Available</p>
                            <p className="text-gray-400 dark:text-gray-500 text-xs mt-1">There are no active positions to display at the moment.</p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      getPaginatedData().map((row: any, index: number) => {
                        // eslint-disable-next-line @typescript-eslint/no-unused-vars
                        const _actualIndex = (currentPage - 1) * itemsPerPage + index
                        return (
                          <tr key={index} className="border-b border-gray-100 dark:border-gray-700 last:border-b-0 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">{row.symbol}</td>
                          <td className="px-4 py-4 text-sm text-gray-700 dark:text-gray-300 whitespace-nowrap">{row.strike}</td>
                          <td className="px-4 py-4 text-sm text-gray-700 dark:text-gray-300 whitespace-nowrap">{row.quantity}</td>
                          <td className={`px-4 py-4 text-sm whitespace-nowrap font-medium ${(row.mtm || 0) >= 0 ? "text-green-500 dark:text-green-400" : "text-red-500 dark:text-red-400"}`}>{row.mtm}</td>
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">{row.expiry}</td>
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">{row.dateTime}</td>
                          </tr>
                        )
                      })
                    )}
                </tbody>
              </table>
              </div>
            </div>
          )}

          {/* OrderBook Table */}
          {activeTab === "OrderBook" && (
            <div className="border border-gray-200 dark:border-gray-700 overflow-hidden bg-white dark:bg-gray-800">
              <div className="w-full">
                <table className="w-full table-auto border-collapse">
                <thead className="bg-[#D6D9F6] dark:bg-gray-700">
                  <tr>
                      <th 
                        className="px-3 py-2 text-center text-[10px] font-medium text-black dark:text-gray-200 whitespace-nowrap w-16 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                        onClick={() => handleSort('srNo')}
                      >
                      <div className="flex items-center justify-center gap-0.5">
                        Sr.No
                        {renderSortIcons('srNo')}
                      </div>
                    </th>
                      <th 
                        className="px-4 py-2 text-left text-[10px] font-medium text-black dark:text-gray-200 whitespace-nowrap min-w-[150px] cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                        onClick={() => handleSort('strategyName')}
                      >
                      <div className="flex items-center gap-0.5">
                        Strategy Name
                        {renderSortIcons('strategyName')}
                      </div>
                    </th>
                      <th 
                        className="px-4 py-2 text-left text-[10px] font-medium text-black dark:text-gray-200 whitespace-nowrap min-w-[140px] cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                        onClick={() => handleSort('dateTime')}
                      >
                      <div className="flex items-center gap-0.5">
                        Date & Time
                        {renderSortIcons('dateTime')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-left text-[10px] font-medium text-black dark:text-gray-200 whitespace-nowrap min-w-[100px] cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                        onClick={() => handleSort('symbol')}
                      >
                      <div className="flex items-center gap-0.5">
                        Symbol
                        {renderSortIcons('symbol')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-right text-[10px] font-medium text-black dark:text-gray-200 whitespace-nowrap min-w-[90px] cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                        onClick={() => handleSort('quantity')}
                      >
                      <div className="flex items-center justify-end gap-0.5">
                        Quantity
                        {renderSortIcons('quantity')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-right text-[10px] font-medium text-black dark:text-gray-200 whitespace-nowrap min-w-[100px] cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                        onClick={() => handleSort('price')}
                      >
                      <div className="flex items-center justify-end gap-0.5">
                        Price
                        {renderSortIcons('price')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-center text-[10px] font-medium text-black dark:text-gray-200 whitespace-nowrap min-w-[100px] cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                        onClick={() => handleSort('status')}
                      >
                      <div className="flex items-center justify-center gap-0.5">
                        Status
                        {renderSortIcons('status')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-center text-[10px] font-medium text-black dark:text-gray-200 whitespace-nowrap min-w-[80px] cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                        onClick={() => handleSort('id')}
                      >
                      <div className="flex items-center justify-center gap-0.5">
                        ID
                        {renderSortIcons('id')}
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800">
                    {(loading || customOrdersLoading) ? (
                      <tr>
                        <td colSpan={8} className="px-4 py-8 text-center text-gray-500 dark:text-gray-400">
                          <div className="flex items-center justify-center gap-2">
                            <Loader2 className="w-5 h-5 animate-spin text-[#5266FC] dark:text-blue-400" />
                            <span>Loading order book...</span>
                          </div>
                        </td>
                      </tr>
                    ) : orderBookData.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="px-4 py-8 text-center">
                          <div className="flex flex-col items-center justify-center">
                            <svg className="w-12 h-12 text-gray-400 dark:text-gray-500 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            <p className="text-gray-500 dark:text-gray-400 text-sm font-medium">No Orders Available</p>
                            <p className="text-gray-400 dark:text-gray-500 text-xs mt-1">There are no orders to display at the moment.</p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      getPaginatedData().map((row: any, index: number) => {
                        return (
                          <tr key={index} className="border-b border-gray-100 dark:border-gray-700 last:border-b-0 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                            <td className="px-3 py-2 text-[10px] text-gray-700 dark:text-gray-300 whitespace-nowrap text-center">{row.srNo || index + 1}</td>
                          <td className="px-4 py-2 text-[10px] text-gray-700 dark:text-gray-300 min-w-[150px] truncate" title={row.strategyName}>{row.strategyName}</td>
                          <td className="px-4 py-2 text-[10px] text-gray-700 dark:text-gray-300 whitespace-nowrap min-w-[140px]">{row.dateTime}</td>
                          <td className="px-3 py-2 text-[10px] text-gray-700 dark:text-gray-300 whitespace-nowrap min-w-[100px]">{row.symbol}</td>
                          <td className="px-3 py-2 text-[10px] text-gray-700 dark:text-gray-300 whitespace-nowrap text-right min-w-[90px]">{row.quantity}</td>
                            <td className="px-3 py-2 text-[10px] text-gray-700 dark:text-gray-300 whitespace-nowrap text-right font-medium min-w-[100px]">{row.price}</td>
                            <td className="px-3 py-2 text-[10px] text-gray-700 dark:text-gray-300 whitespace-nowrap text-center min-w-[100px]">{formatStatus(row.status)}</td>
                            <td className="px-3 py-2 text-[10px] text-gray-700 dark:text-gray-300 whitespace-nowrap text-center min-w-[80px]">{row.id}</td>
                          </tr>
                        )
                      })
                    )}
                </tbody>
              </table>
              </div>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-600 text-sm">{error}</p>
              <button 
                onClick={fetchActiveStrategies}
                className="mt-2 text-red-600 underline text-sm hover:text-red-800"
              >
                Try again
              </button>
            </div>
          )}

          {/* Deployed Algos Table */}
          {activeTab === "Deployed Algos" && (
            <div className="border border-gray-200 dark:border-gray-700 overflow-hidden bg-white dark:bg-gray-800">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[900px]">
                <thead className="bg-[#D6D9F6] dark:bg-gray-700">
                  <tr>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('srNo')}
                      >
                      <div className="flex items-center gap-1">
                        Sr.No
                        {renderSortIcons('srNo', 'medium')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('name')}
                      >
                      <div className="flex items-center gap-1">
                        Strategy Name
                        {renderSortIcons('name', 'medium')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('strategyMtm')}
                      >
                      <div className="flex items-center gap-1">
                        PNL
                        {renderSortIcons('strategyMtm', 'medium')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('status')}
                      >
                      <div className="flex items-center gap-1">
                        Status
                        {renderSortIcons('status', 'medium')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('multiplier')}
                      >
                        <div className="flex items-center gap-1">
                          Multiplier
                          {renderSortIcons('multiplier', 'medium')}
                      </div>
                    </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('execution')}
                      >
                        <div className="flex items-center gap-1">
                          Switch More
                          {renderSortIcons('execution', 'medium')}
                        </div>
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap">
                      <div className="flex items-center gap-1">
                        Actions
                        </div>
                      </th>
                      <th 
                        className="px-3 py-2 text-left text-xs font-medium text-black dark:text-gray-200 whitespace-nowrap cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        onClick={() => handleSort('deployedOn')}
                      >
                      <div className="flex items-center gap-1">
                       Trade Details
                        {renderSortIcons('deployedOn', 'medium')}
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800">
                    {loading ? (
                      <tr>
                        <td colSpan={8} className="px-4 py-8 text-center text-gray-500 dark:text-gray-400">
                          Loading strategies...
                        </td>
                      </tr>
                    ) : error ? (
                      <tr>
                        <td colSpan={8} className="px-4 py-8 text-center text-red-500 dark:text-red-400">
                          {error}
                        </td>
                      </tr>
                    ) : filteredStrategies.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="px-4 py-8 text-center">
                          <div className="flex flex-col items-center justify-center">
                            <svg className="w-12 h-12 text-gray-400 dark:text-gray-500 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                            </svg>
                            <p className="text-gray-500 dark:text-gray-400 text-sm font-medium">No Strategies Found</p>
                            <p className="text-gray-400 dark:text-gray-500 text-xs mt-1">
                              {searchQuery 
                                ? `No strategies match your search "${searchQuery}"`
                                : `No ${activeToggle === "LIVE" ? "Live Trading" : "Forward Test"} strategies available at the moment.`}
                            </p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      getPaginatedData().map((strategy: ActiveStrategy, index: number) => {
                        const returns = strategy.capital > 0 
                          ? ((strategy.strategyMtm / strategy.capital) * 100).toFixed(2) 
                          : "0.00"
                        const isActionLoading = actionLoading[strategy.sid] || false
                        const isMultiplierLoading = multiplierLoading[strategy.sid] || false
                        // eslint-disable-next-line @typescript-eslint/no-unused-vars
                        const _isLiveTrading = strategy.execution === "LiveTrading"
                        const currentMultiplier = parseInt(strategy.multiplier) || 1
                        
                        return (
                          <tr key={strategy.sid} data-strategy-id={strategy.sid} className="border-b border-gray-100 dark:border-gray-700 last:border-b-0">
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">{strategy.srNo || index + 1}</td>
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">{strategy.name}</td>
                            <td className={`px-4 py-4 text-sm whitespace-nowrap font-medium ${strategy.strategyMtm >= 0 ? "text-green-500 dark:text-green-400" : "text-red-500 dark:text-red-400"}`}>
                              ₹{formatPnL(strategy.strategyMtm)}
                            </td>
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">
                              {(() => {
                                const statusLower = strategy.status?.toLowerCase() || ''
                                const isErrorStatus = statusLower === "error" || statusLower === "failed"
                                const isLoading = errorActionLoading[strategy.sid] || false
                                
                                if (isErrorStatus) {
                                  return (
                                    <DropdownMenu>
                                      <DropdownMenuTrigger asChild>
                                        <button
                                          className={`inline-flex items-center px-3 py-1.5 rounded-md text-xs font-medium ${getStatusColor(strategy.status)} hover:opacity-80 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed`}
                                          disabled={isLoading}
                                        >
                                          {isLoading ? (
                                            <>
                                              <Loader2 className="w-3 h-3 mr-1.5 animate-spin" />
                                              Processing...
                                            </>
                                          ) : (
                                            <>
                                              {formatStatus(strategy.status)}
                                              <ChevronDown className="w-3 h-3 ml-1.5" />
                                            </>
                                          )}
                                        </button>
                                      </DropdownMenuTrigger>
                                      <DropdownMenuContent align="start" className="w-48">
                                        <DropdownMenuItem
                                          onClick={() => handleErrorAction('manuallyTraded', strategy.sid, strategy.name)}
                                          disabled={isLoading}
                                          className="cursor-pointer"
                                        >
                                          <FileText className="w-4 h-4 mr-2" />
                                          Manually Traded
                                        </DropdownMenuItem>
                                        <DropdownMenuItem
                                          onClick={() => handleErrorAction('retry', strategy.sid, strategy.name)}
                                          disabled={isLoading}
                                          className="cursor-pointer"
                                        >
                                          <RotateCw className="w-4 h-4 mr-2" />
                                          Retry
                                        </DropdownMenuItem>
                                        <DropdownMenuItem
                                          onClick={() => handleErrorAction('closePartialLegs', strategy.sid, strategy.name)}
                                          disabled={isLoading}
                                          className="cursor-pointer"
                                        >
                                          <Power className="w-4 h-4 mr-2" />
                                          Close Partial Legs
                                        </DropdownMenuItem>
                                      </DropdownMenuContent>
                                    </DropdownMenu>
                                  )
                                }
                                
                                return (
                                  <span className={`inline-flex items-center px-3 py-1.5 rounded-md text-xs font-medium ${getStatusColor(strategy.status)}`}>
                                    {formatStatus(strategy.status)}
                                  </span>
                                )
                              })()}
                            </td>
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">
                              <Select
                                value={String(currentMultiplier)}
                                onValueChange={(value) => {
                                  const newMultiplier = parseInt(value)
                                  if (newMultiplier >= 1 && newMultiplier <= 100) {
                                    handleMultiplierChange(strategy.sid, newMultiplier, strategy.execution, strategy.name)
                                  }
                                }}
                                disabled={isMultiplierLoading}
                              >
                                <SelectTrigger className="w-16 h-7 text-xs border-gray-300 px-1.5 py-0.5">
                                  {isMultiplierLoading ? (
                                    <div className="flex items-center justify-center">
                                      <Loader2 className="w-2.5 h-2.5 animate-spin" />
                                    </div>
                                  ) : (
                                    <SelectValue className="text-xs">
                                      {currentMultiplier}x
                                    </SelectValue>
                                  )}
                                </SelectTrigger>
                                <SelectContent className="max-h-[150px] overflow-y-auto w-16 p-0 min-w-[64px]">
                                  {Array.from({ length: 100 }, (_, i: number) => i + 1).map((mult: number) => (
                                    <SelectItem 
                                      key={mult} 
                                      value={String(mult)} 
                                      className="text-xs py-0.5 px-1 h-6 text-center justify-center pr-2 [&>span[class*='absolute']]:hidden"
                                    >
                                      {mult}x
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </td>
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">
                                  Forward
                                </span>
                                <Switch
                                  checked={strategy.execution === "LiveTrading"}
                                  onCheckedChange={(checked) => {
                                    const newExecution = checked ? "LiveTrading" : "PaperTrading"
                                    handleExecutionTypeChange(strategy.sid, newExecution)
                                  }}
                                  disabled={isActionLoading}
                                />
                                <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">
                                  Live
                                </span>
                              </div>
                            </td>
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <button
                                    className="flex items-center justify-center w-8 h-8 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                                    disabled={isActionLoading}
                                  >
                                    {isActionLoading ? (
                                      <Loader2 className="w-4 h-4 animate-spin text-gray-400 dark:text-blue-400" />
                                    ) : (
                                      <MoreVertical className="w-4 h-4 text-gray-600 dark:text-blue-400" />
                                    )}
                                  </button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-auto p-3">
                                  <div className="grid grid-cols-3 gap-2 min-w-[300px]">
                                    {strategy.status?.toLowerCase() === "paused" ? (
                                      // Only show Resume when status is paused
                                      <button
                                        onClick={() => {
                                          handleAction("resume", strategy.sid, strategy.name)
                                        }}
                                        className="flex flex-col items-center justify-center p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 hover:border-[#5266FC] transition-all cursor-pointer group"
                                      >
                                        <div className="w-8 h-8 flex items-center justify-center rounded-md bg-[#E8EAFF] group-hover:bg-[#5266FC] mb-2 transition-colors">
                                          <Play className="w-4 h-4 text-[#5266FC] group-hover:text-white transition-colors" />
                                        </div>
                                        <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Resume</span>
                                      </button>
                                    ) : (() => {
                                      const statusLower = strategy.status?.toLowerCase() || ""
                                      const isErrorStatus = statusLower === "error" || statusLower === "failed"
                                      
                                      return (
                                        <>
                                          {isErrorStatus && (
                                            <button
                                              onClick={() => handleAction("restart", strategy.sid, strategy.name)}
                                              className="flex flex-col items-center justify-center p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 hover:border-[#5266FC] transition-all cursor-pointer group"
                                            >
                                              <div className="w-8 h-8 flex items-center justify-center rounded-md bg-[#E8EAFF] group-hover:bg-[#5266FC] mb-2 transition-colors">
                                                <RotateCw className="w-4 h-4 text-[#5266FC] group-hover:text-white transition-colors" />
                                              </div>
                                              <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Restart</span>
                                            </button>
                                          )}
                                          <button
                                            onClick={() => handleAction("undeploy", strategy.sid, strategy.name)}
                                            className="flex flex-col items-center justify-center p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 hover:border-[#5266FC] transition-all cursor-pointer group"
                                          >
                                            <div className="w-8 h-8 flex items-center justify-center rounded-md bg-[#E8EAFF] group-hover:bg-[#5266FC] mb-2 transition-colors">
                                              <svg className="w-4 h-4 text-[#5266FC] group-hover:text-white transition-colors" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                <circle cx="12" cy="12" r="10"></circle>
                                                <line x1="8" y1="8" x2="16" y2="16"></line>
                                                <line x1="16" y1="8" x2="8" y2="16"></line>
                                              </svg>
                                            </div>
                                            <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Undeploy</span>
                                          </button>
                                          <button
                                            onClick={() => handleLogs(strategy.sid, strategy.name)}
                                            className="flex flex-col items-center justify-center p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 hover:border-[#5266FC] transition-all cursor-pointer group"
                                          >
                                            <div className="w-8 h-8 flex items-center justify-center rounded-md bg-[#E8EAFF] group-hover:bg-[#5266FC] mb-2 transition-colors">
                                              <FileText className="w-4 h-4 text-[#5266FC] group-hover:text-white transition-colors" />
                                            </div>
                                            <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Logs</span>
                                          </button>
                                          <button
                                            onClick={() => handleAction("exit", strategy.sid, strategy.name)}
                                            className="flex flex-col items-center justify-center p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 hover:border-[#5266FC] transition-all cursor-pointer group"
                                          >
                                            <div className="w-8 h-8 flex items-center justify-center rounded-md bg-[#E8EAFF] group-hover:bg-[#5266FC] mb-2 transition-colors">
                                              <LogOut className="w-4 h-4 text-[#5266FC] group-hover:text-white transition-colors" />
                                            </div>
                                            <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Exit</span>
                                          </button>
                                          <button
                                            onClick={() => {
                                              navigate(`/performance?strategyId=${strategy.sid}&tab=performance&from=my-strategy`, {
                                                state: {
                                                  from: "PNL",
                                                  strategyDescription: (strategy as any).description || "",
                                                  strategyCategory: strategy.category || (strategy as any).strategyType || ""
                                                }
                                              })
                                            }}
                                            className="flex flex-col items-center justify-center p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 hover:border-[#5266FC] transition-all cursor-pointer group"
                                          >
                                            <div className="w-8 h-8 flex items-center justify-center rounded-md bg-[#E8EAFF] group-hover:bg-[#5266FC] mb-2 transition-colors">
                                              <TrendingUp className="w-4 h-4 text-[#5266FC] group-hover:text-white transition-colors" />
                                            </div>
                                            <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Performance</span>
                                          </button>
                                          <button
                                            className="flex flex-col items-center justify-center p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 hover:border-[#5266FC] transition-all cursor-pointer group opacity-50"
                                            disabled
                                          >
                                            <div className="w-8 h-8 flex items-center justify-center rounded-md bg-[#E8EAFF] group-hover:bg-[#5266FC] mb-2 transition-colors">
                                              <svg className="w-4 h-4 text-[#5266FC] group-hover:text-white transition-colors" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                              </svg>
                                            </div>
                                            <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Edit</span>
                                          </button>
                                        </>
                                      )
                                    })()}
                                  </div>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </td>
                            <td className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 whitespace-nowrap">
                              <button
                                onClick={() => {
                                  setSelectedTradeDetailsStrategy({ id: strategy.sid, name: strategy.name, data: strategy })
                                  setTradeDetailsModalOpen(true)
                                }}
                                className="flex items-center justify-center w-8 h-8 rounded hover:bg-blue-50 dark:hover:bg-blue-900/30 text-blue-500 dark:text-blue-400 hover:text-blue-600 dark:hover:text-blue-300 transition-colors cursor-pointer"
                                title="Trade Details"
                              >
                                <ClipboardList className="w-5 h-5" />
                              </button>
                            </td>
                    </tr>
                        )
                      })
                    )}
                </tbody>
              </table>
              </div>
            </div>
            
            {/* Show total entries count for Performance Report (no pagination) */}
            {activeTab === "Performance Report" && reports.length > 0 && (
              <div className="mt-4 px-4 text-sm text-gray-600 dark:text-gray-400">
                Showing all {reports.length} {reports.length === 1 ? 'entry' : 'entries'}
              </div>
            )}
          )}

          {/* Pagination - Only show if there's more than 10 items, but not for Performance Report tab */}
          {totalPages > 1 && activeTab !== "Performance Report" && (
            <div className="flex items-center justify-between mt-6 px-4">
              {/* Page info */}
              <div className="text-sm text-gray-600">
                Showing {((currentPage - 1) * itemsPerPage) + 1} to {Math.min(currentPage * itemsPerPage, 
                  activeTab === "Performance Report" ? reports.length :
                  activeTab === "Deployed Algos" ? filteredStrategies.length : 
                  activeTab === "OrderBook" ? orderBookData.length : 
                  positionsData.length)} of {
                  activeTab === "Performance Report" ? reports.length :
                  activeTab === "Deployed Algos" ? filteredStrategies.length : 
                  activeTab === "OrderBook" ? orderBookData.length : 
                  positionsData.length} entries
              </div>

              {/* Pagination controls */}
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-white"
                >
                  Previous
                </button>
                
                {/* Page numbers */}
                <div className="flex items-center gap-1">
                  {/* First page */}
                  {totalPages > 0 && (
                    <button
                      onClick={() => setCurrentPage(1)}
                      className={`w-9 h-9 text-sm font-medium rounded-md transition ${
                        currentPage === 1 
                          ? "bg-blue-600 text-white" 
                          : "text-gray-700 bg-white border border-gray-300 hover:bg-gray-50"
                      }`}
                    >
                      1
                    </button>
                  )}
                  
                  {/* Ellipsis before current page range */}
                  {currentPage > 3 && totalPages > 5 && (
                    <span className="px-2 text-gray-400">...</span>
                  )}
                  
                  {/* Pages around current page */}
                  {Array.from({ length: totalPages }, (_, i: number) => i + 1)
                    .filter((page: number) => {
                      if (page === 1 || page === totalPages) return false
                      return Math.abs(page - currentPage) <= 1
                    })
                    .map((page: number) => (
                      <button
                        key={page}
                        onClick={() => setCurrentPage(page)}
                        className={`w-9 h-9 text-sm font-medium rounded-md transition ${
                          currentPage === page 
                            ? "bg-blue-600 text-white" 
                            : "text-gray-700 bg-white border border-gray-300 hover:bg-gray-50"
                        }`}
                      >
                        {page}
                      </button>
                    ))}
                  
                  {/* Ellipsis after current page range */}
                  {currentPage < totalPages - 2 && totalPages > 5 && (
                    <span className="px-2 text-gray-400">...</span>
                  )}
                  
                  {/* Last page */}
                  {totalPages > 1 && (
                    <button
                      onClick={() => setCurrentPage(totalPages)}
                      className={`w-9 h-9 text-sm font-medium rounded-md transition ${
                        currentPage === totalPages 
                          ? "bg-blue-600 text-white" 
                          : "text-gray-700 bg-white border border-gray-300 hover:bg-gray-50"
                      }`}
                    >
                      {totalPages}
                    </button>
                  )}
                </div>
                
                <button
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage >= totalPages}
                  className="px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-white"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Confirmation Modal for Execution Type Change */}
      {confirmDialogOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* Overlay */}
          <div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
            onClick={cancelExecutionTypeChange}
          />
          
          {/* Modal */}
          <div className="relative z-50 bg-white rounded-lg shadow-xl max-w-md w-full mx-4 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Confirm Execution Type Change
            </h3>
            <p className="text-sm text-gray-600 mb-6">
              Are you sure you want to switch this strategy to <strong>{pendingExecutionType === "LiveTrading" ? "Live Trading" : "Forward Test"}</strong> mode? This action will change the strategy's execution type.
            </p>
            
            {/* Buttons */}
            <div className="flex justify-end gap-3">
              <button
                onClick={cancelExecutionTypeChange}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={confirmExecutionTypeChange}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 transition-colors"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Exit All */}
      {exitAllDialogOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* Overlay */}
          <div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
            onClick={cancelExitAll}
          />
          
          {/* Modal */}
          <div className="relative z-50 bg-white rounded-lg shadow-xl max-w-md w-full mx-4 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Confirm Exit All Strategies
            </h3>
            <p className="text-sm text-gray-600 mb-6">
              Are you sure you want to exit all {filteredStrategies.length} {filteredStrategies.length === 1 ? 'strategy' : 'strategies'}? This action cannot be undone.
            </p>
            
            {/* Buttons */}
            <div className="flex justify-end gap-3">
              <button
                onClick={cancelExitAll}
                disabled={exitAllLoading}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Cancel
              </button>
              <button
                onClick={confirmExitAll}
                disabled={exitAllLoading}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {exitAllLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Exiting...</span>
                  </>
                ) : (
                  "Exit All"
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Multiplier Change */}
      {multiplierDialogOpen && pendingMultiplier && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* Overlay */}
          <div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
            onClick={cancelMultiplierChange}
          />
          
          {/* Modal */}
          <div className="relative z-50 bg-white rounded-lg shadow-xl max-w-md w-full mx-4 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Confirm Multiplier Change
            </h3>
            <p className="text-sm text-gray-600 mb-6">
              Are you sure you want to change the multiplier for <strong>{pendingMultiplier.strategyName}</strong> to <strong>{pendingMultiplier.multiplier}x</strong>? This will update the strategy's multiplier value.
            </p>
            
            {/* Buttons */}
            <div className="flex justify-end gap-3">
              <button
                onClick={cancelMultiplierChange}
                disabled={multiplierLoading[pendingMultiplier.strategyId]}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Cancel
              </button>
              <button
                onClick={confirmMultiplierChange}
                disabled={multiplierLoading[pendingMultiplier.strategyId]}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {multiplierLoading[pendingMultiplier.strategyId] && <Loader2 className="w-4 h-4 animate-spin" />}
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Action Confirmation Dialog */}
      {actionDialogOpen && pendingAction && (
        <Dialog open={actionDialogOpen} onOpenChange={setActionDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                Confirm {pendingAction.type.charAt(0).toUpperCase() + pendingAction.type.slice(1)} Action
              </DialogTitle>
              <DialogDescription>
                Are you sure you want to {pendingAction.type} the strategy <strong>{pendingAction.strategyName}</strong>? 
                {pendingAction.type === "undeploy" && " This will undeploy the strategy."}
                {pendingAction.type === "exit" && " This will exit the strategy."}
                {pendingAction.type === "resume" && " This will resume the strategy from standby mode."}
                {pendingAction.type === "restart" && " This will restart the strategy and retry any failed operations."}
                {pendingAction.type === "edit" && " This will load the strategy for editing."}
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <button
                onClick={cancelAction}
                disabled={actionLoading[pendingAction.strategyId]}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Cancel
              </button>
              <button
                onClick={confirmAction}
                disabled={actionLoading[pendingAction.strategyId]}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {actionLoading[pendingAction.strategyId] && <Loader2 className="w-4 h-4 animate-spin" />}
                Confirm
              </button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Logs Dialog */}
      {logsDialogOpen && (
        <Dialog open={logsDialogOpen} onOpenChange={setLogsDialogOpen}>
          <DialogContent className="max-w-[95vw] max-h-[90vh] overflow-hidden flex flex-col p-0">
            <DialogHeader className="px-6 pt-5 pb-3 border-b border-gray-200 bg-gray-50">
              <div className="flex items-center justify-between">
                <div>
                  <DialogTitle className="text-lg font-semibold text-gray-900">Strategy Logs</DialogTitle>
                  <DialogDescription className="text-xs text-gray-500 mt-1">
                    {logsData && (
                      <span>Strategy ID: <span className="font-mono font-medium text-gray-700">{logsData.strategyId || "N/A"}</span></span>
                    )}
                  </DialogDescription>
                </div>
                {logsData?.deployedOn && (
                  <div className="text-xs text-gray-500">
                    Deployed: <span className="font-mono text-gray-700">{logsData.deployedOn}</span>
                  </div>
                )}
              </div>
            </DialogHeader>
            <div className="flex-1 overflow-y-auto bg-white">
              {logsLoading ? (
                <div className="flex flex-col items-center justify-center py-16">
                  <Loader2 className="w-8 h-8 animate-spin text-[#5266FC] mb-3" />
                  <span className="text-sm text-gray-600">Loading logs...</span>
                </div>
              ) : logsData && logsData.statusList && logsData.statusList.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead className="sticky top-0 z-10 bg-[#F8F9FA] border-b-2 border-gray-300">
                      <tr>
                        <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider border-r border-gray-200">
                          Date
                        </th>
                        <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider border-r border-gray-200">
                          Time
                        </th>
                        <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider border-r border-gray-200 w-24">
                          Status
                        </th>
                        <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                          Message
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {logsData.statusList.map((log: any, index: number) => {
                        // Parse timestamp to separate date and time
                        let dateStr = "N/A"
                        let timeStr = "N/A"
                        
                        if (log.timeStamp) {
                          try {
                            // Try to parse various timestamp formats
                            const timestamp = log.timeStamp
                            // Check if it's ISO format or other formats
                            const date = new Date(timestamp)
                            if (!isNaN(date.getTime())) {
                              // Format date as YYYY-MM-DD
                              const year = date.getFullYear()
                              const month = String(date.getMonth() + 1).padStart(2, '0')
                              const day = String(date.getDate()).padStart(2, '0')
                              dateStr = `${year}-${month}-${day}`
                              
                              // Format time as HH:MM:SS
                              const hours = String(date.getHours()).padStart(2, '0')
                              const minutes = String(date.getMinutes()).padStart(2, '0')
                              const seconds = String(date.getSeconds()).padStart(2, '0')
                              timeStr = `${hours}:${minutes}:${seconds}`
                            } else {
                              // If parsing fails, try to extract date/time from string
                              const parts = timestamp.split(/[\sT]/)
                              if (parts.length >= 2) {
                                dateStr = parts[0]
                                timeStr = parts[1]?.substring(0, 8) || "N/A"
                              } else {
                                dateStr = timestamp
                                timeStr = "N/A"
                              }
                            }
                          } catch (e) {
                            dateStr = log.timeStamp
                            timeStr = "N/A"
                          }
                        }

                        const statusLower = (log.status || "").toLowerCase()
                        const isSuccess = statusLower === "active" || statusLower === "deployed" || statusLower === "success" || statusLower === "completed"
                        const isError = statusLower === "error" || statusLower === "failed" || statusLower === "failure"
                        const isWarning = statusLower === "warning" || statusLower === "pending" || statusLower === "processing"
                        const isInfo = statusLower === "info" || statusLower === "information"

                        return (
                          <tr 
                            key={index} 
                            className={`hover:bg-gray-50 transition-colors ${
                              isError ? "bg-red-50/30" : isWarning ? "bg-yellow-50/30" : "bg-white"
                            }`}
                          >
                            <td className="px-3 py-2.5 text-xs font-mono text-gray-700 whitespace-nowrap border-r border-gray-100">
                              {dateStr}
                            </td>
                            <td className="px-3 py-2.5 text-xs font-mono text-gray-700 whitespace-nowrap border-r border-gray-100">
                              {timeStr}
                            </td>
                            <td className="px-3 py-2.5 whitespace-nowrap border-r border-gray-100">
                              <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${
                                isSuccess
                                  ? "bg-green-100 text-green-800 border border-green-200"
                                  : isError
                                  ? "bg-red-100 text-red-800 border border-red-200"
                                  : isWarning
                                  ? "bg-yellow-100 text-yellow-800 border border-yellow-200"
                                  : isInfo
                                  ? "bg-blue-100 text-blue-800 border border-blue-200"
                                  : "bg-gray-100 text-gray-800 border border-gray-200"
                              }`}>
                                {formatStatus(log.status || "Unknown")}
                              </span>
                            </td>
                            <td className="px-3 py-2.5 text-xs text-gray-800">
                              {log.description && Array.isArray(log.description) && log.description.length > 0 ? (
                                <div className="space-y-0.5">
                                  {log.description.map((desc: string, descIndex: number) => (
                                    <div key={descIndex} className="leading-relaxed">
                                      {desc}
                                    </div>
                                  ))}
                                </div>
                              ) : (
                                <span className="text-gray-400 italic">No message</span>
                              )}
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-16 text-gray-400">
                  <FileText className="w-14 h-14 mb-4 opacity-40" />
                  <p className="text-sm font-medium text-gray-600">No logs available</p>
                  <p className="text-xs mt-1 text-gray-400">There are no logs to display for this strategy.</p>
                </div>
              )}
            </div>
            <DialogFooter className="px-6 py-3 border-t border-gray-200 bg-gray-50">
              <button
                onClick={() => setLogsDialogOpen(false)}
                className="px-5 py-2 text-sm font-medium text-white bg-[#5266FC] rounded-md hover:bg-[#5266FC]/90 transition-colors"
              >
                Close
              </button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Detailed Report Dialog */}
      <Dialog open={detailedReportDialogOpen} onOpenChange={setDetailedReportDialogOpen}>
        <DialogContent className="sm:max-w-6xl max-h-[90vh] overflow-y-auto bg-white dark:bg-gray-900">
          <DialogHeader className="pb-4 border-b border-gray-200 dark:border-gray-700">
            <DialogTitle className="text-xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
              {detailedReportLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin text-[#5266FC]" />
                  <span>Loading Report...</span>
                </>
              ) : (
                <>
                  <FileText className="w-5 h-5 text-[#5266FC] dark:text-blue-400" />
                  {detailedReportData?.strategyName || "Strategy Report"}
                </>
              )}
            </DialogTitle>
            <DialogDescription className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Detailed performance report for {detailedReportData?.strategyName || "this strategy"}
            </DialogDescription>
          </DialogHeader>

          {detailedReportLoading ? (
            <div className="flex flex-col items-center justify-center py-16">
              <Loader2 className="w-10 h-10 animate-spin text-[#5266FC] dark:text-blue-400 mb-4" />
              <span className="text-gray-600 dark:text-gray-400">Loading detailed report...</span>
            </div>
          ) : detailedReportData ? (
            <div className="space-y-6 pt-4">
              {/* Summary Section - Enhanced Design */}
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-800 dark:to-gray-700 p-5 rounded-xl border border-blue-100 dark:border-gray-600 shadow-sm">
                  <p className="text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 uppercase tracking-wide">Strategy ID</p>
                  <p className="text-lg font-bold text-gray-900 dark:text-gray-100">{detailedReportData.strategyID}</p>
                </div>
                <div className={`p-5 rounded-xl border shadow-sm ${
                  detailedReportData.totalPNL >= 0 
                    ? "bg-gradient-to-br from-green-50 to-emerald-50 dark:from-gray-800 dark:to-gray-700 border-green-100 dark:border-gray-600" 
                    : "bg-gradient-to-br from-red-50 to-rose-50 dark:from-gray-800 dark:to-gray-700 border-red-100 dark:border-gray-600"
                }`}>
                  <p className="text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 uppercase tracking-wide">Total P&L</p>
                  <p className={`text-lg font-bold ${detailedReportData.totalPNL >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                    ₹{formatPnL(detailedReportData.totalPNL || 0)}
                  </p>
                </div>
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-gray-800 dark:to-gray-700 p-5 rounded-xl border border-purple-100 dark:border-gray-600 shadow-sm">
                  <p className="text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 uppercase tracking-wide">Total Orders</p>
                  <p className="text-lg font-bold text-gray-900 dark:text-gray-100">
                    {detailedReportData.totalOrders != null && detailedReportData.totalOrders !== undefined
                      ? detailedReportData.totalOrders
                      : (detailedReportData.reportsSignalDTOs?.length ?? 0)}
                  </p>
                </div>
              </div>

              {/* Performance Chart */}
              {detailedReportData.reportsSignalDTOs && detailedReportData.reportsSignalDTOs.length > 0 && (() => {
                // Prepare chart data - reverse to show chronological order (oldest to newest)
                const chartData = [...detailedReportData.reportsSignalDTOs].reverse().map((signal: any) => ({
                  date: signal.date || "N/A",
                  pnl: signal.pnl || 0,
                  sequentialPNL: signal.sequentialPNL || 0,
                  pnlChange: signal.pnlChange || 0
                }))

                return (
                  <div className="border border-gray-200 dark:border-gray-700 rounded-xl p-6 bg-white dark:bg-gray-800 shadow-sm">
                    <div className="flex items-center gap-2 mb-6">
                      <TrendingUp className="w-5 h-5 text-[#5266FC] dark:text-blue-400" />
                      <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">Performance Chart</h3>
                    </div>
                    <ResponsiveContainer width="100%" height={300}>
                      <ComposedChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis 
                          dataKey="date" 
                          stroke="#6b7280"
                          style={{ fontSize: '12px' }}
                          angle={-45}
                          textAnchor="end"
                          height={80}
                        />
                        <YAxis 
                          yAxisId="left"
                          stroke="#6b7280"
                          style={{ fontSize: '12px' }}
                          tickFormatter={(value) => `₹${(value / 1000).toFixed(1)}K`}
                        />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: '#fff', 
                            border: '1px solid #e5e7eb',
                            borderRadius: '6px',
                            fontSize: '12px'
                          }}
                          formatter={(value: number, name: string) => {
                            if (name === 'sequentialPNL') return [`₹${formatPnL(value)}`, 'Cumulative P&L']
                            if (name === 'pnl') return [`₹${formatPnL(value)}`, 'Daily P&L']
                            return [value, name]
                          }}
                        />
                        <Legend 
                          wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }}
                        />
                        <Bar 
                          yAxisId="left"
                          dataKey="pnl" 
                          fill="#3b82f6"
                          name="Daily P&L"
                          radius={[4, 4, 0, 0]}
                        />
                        <Line 
                          yAxisId="left"
                          type="monotone" 
                          dataKey="sequentialPNL" 
                          stroke="#10b981" 
                          strokeWidth={2}
                          dot={{ fill: '#10b981', r: 4 }}
                          name="Cumulative P&L"
                        />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                )
              })()}

              {/* Signals Table */}
              <div className="border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden bg-white dark:bg-gray-800 shadow-sm">
                <div className="bg-[#D6D9F6] dark:bg-gray-700 px-6 py-4 border-b border-gray-200 dark:border-gray-600">
                  <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
                    <ClipboardList className="w-5 h-5 text-[#5266FC] dark:text-blue-400" />
                    Trading Signals
                  </h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 dark:bg-gray-700/50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide whitespace-nowrap">Date</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide whitespace-nowrap">P&L</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide whitespace-nowrap">P&L Change</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide whitespace-nowrap">Sequential P&L</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide whitespace-nowrap">Legs</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                      {detailedReportData.reportsSignalDTOs && detailedReportData.reportsSignalDTOs.length > 0 ? (
                        detailedReportData.reportsSignalDTOs.map((signal: any, index: number) => (
                          <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                            <td className="px-4 py-3 text-sm font-medium text-gray-900 dark:text-gray-100 whitespace-nowrap">{signal.date || "N/A"}</td>
                            <td className={`px-4 py-3 text-sm font-semibold whitespace-nowrap ${signal.pnl >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                              ₹{formatPnL(signal.pnl || 0)}
                            </td>
                            <td className={`px-4 py-3 text-sm font-semibold whitespace-nowrap ${signal.pnlChange >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                              ₹{formatPnL(signal.pnlChange || 0)}
                            </td>
                            <td className={`px-4 py-3 text-sm font-semibold whitespace-nowrap ${signal.sequentialPNL >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                              ₹{formatPnL(signal.sequentialPNL || 0)}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700 dark:text-gray-300">
                              <details className="cursor-pointer group">
                                <summary className="text-[#5266FC] dark:text-blue-400 hover:text-[#3d4fc7] dark:hover:text-blue-300 hover:underline font-medium flex items-center gap-1">
                                  <span>{signal.reportsLegDtoList?.length || 0} leg(s)</span>
                                  <ChevronDown className="w-4 h-4 inline-block group-open:rotate-180 transition-transform" />
                                </summary>
                                <div className="mt-3 ml-2 space-y-3 pl-4 border-l-2 border-[#5266FC] dark:border-blue-400">
                                  {signal.reportsLegDtoList?.map((leg: any, legIndex: number) => (
                                    <div key={legIndex} className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200 dark:border-gray-600">
                                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                                        <div>
                                          <span className="text-gray-500 dark:text-gray-400 font-medium">Leg ID:</span>
                                          <span className="ml-1 text-gray-900 dark:text-gray-100 font-semibold">{leg.legId}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-500 dark:text-gray-400 font-medium">Signal ID:</span>
                                          <span className="ml-1 text-gray-900 dark:text-gray-100 font-semibold">{leg.signalId}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-500 dark:text-gray-400 font-medium">Quantity:</span>
                                          <span className="ml-1 text-gray-900 dark:text-gray-100 font-semibold">{leg.quantity}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-500 dark:text-gray-400 font-medium">Price:</span>
                                          <span className="ml-1 text-gray-900 dark:text-gray-100 font-semibold">₹{formatPnL(leg.price || 0)}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-500 dark:text-gray-400 font-medium">Instrument:</span>
                                          <span className="ml-1 text-gray-900 dark:text-gray-100 font-semibold">{leg.instrument}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-500 dark:text-gray-400 font-medium">Date:</span>
                                          <span className="ml-1 text-gray-900 dark:text-gray-100 font-semibold">
                                            {leg.date ? new Date(leg.date * 1000).toLocaleString('en-IN', { 
                                              year: 'numeric', 
                                              month: '2-digit', 
                                              day: '2-digit', 
                                              hour: '2-digit', 
                                              minute: '2-digit', 
                                              second: '2-digit' 
                                            }) : "N/A"}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </details>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={5} className="px-4 py-8 text-center text-gray-500 dark:text-gray-400">
                            <div className="flex flex-col items-center gap-2">
                              <FileText className="w-8 h-8 text-gray-400 dark:text-gray-500" />
                              <span>No signal data available</span>
                            </div>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12">
              <p className="text-gray-500">No report data available</p>
            </div>
          )}

          <DialogFooter className="pt-4 border-t border-gray-200 dark:border-gray-700">
            <Button 
              onClick={() => setDetailedReportDialogOpen(false)} 
              variant="outline"
              className="px-6 py-2 border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Trade Details Modal */}
      {selectedTradeDetailsStrategy && (
        <TradeDetailsModal
          open={tradeDetailsModalOpen}
          onClose={() => {
            setTradeDetailsModalOpen(false)
            setSelectedTradeDetailsStrategy(null)
          }}
          strategyId={selectedTradeDetailsStrategy.id}
          strategyName={selectedTradeDetailsStrategy.name}
          strategyData={selectedTradeDetailsStrategy.data}
        />
      )}
    </div>
  )
}

