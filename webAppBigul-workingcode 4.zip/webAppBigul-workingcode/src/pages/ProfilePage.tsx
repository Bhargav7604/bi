import { useState, useEffect, useCallback, useRef } from "react"
import Header from "@components/Header"
import { Loader2, User, Mail, IdCard, Shield, Phone, MapPin } from "lucide-react"
import { authService } from "@/lib/api/auth.service"
import { useAuthStore } from "@/store/auth.store"
import { getClientIdFromToken, decodeJWT } from "@/lib/utils/jwt"

export default function ProfilePage() {
  const [loading, setLoading] = useState(true)
  const [userDetails, setUserDetails] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const { token, isAuthenticated } = useAuthStore()
  const profileFetchedRef = useRef<string | null>(null)
  const isFetchingProfileRef = useRef(false)

  const fetchUserDetails = useCallback(async () => {
    // Prevent duplicate calls
    const fetchKey = `${token ? 'authenticated' : 'unauthenticated'}`
    if (profileFetchedRef.current === fetchKey || isFetchingProfileRef.current) {
      return
    }
    if (!token || !isAuthenticated) {
      setError("Please login to view your profile")
      setLoading(false)
      return
    }

    isFetchingProfileRef.current = true
    setLoading(true)
    setError(null)

    try {
      // Step 1: Try to get clientId from token
      let clientId = getClientIdFromToken(token)
      console.log("Step 1: clientId from token:", clientId)
      
      // Step 2: If clientId not found in token, try to decode token directly
      if (!clientId) {
        console.warn("ClientId not found via getClientIdFromToken, attempting direct decode")
        const decoded = decodeJWT(token)
        console.log("Decoded token:", decoded)
        
        // Try alternative fields that might contain clientId
        if (decoded) {
          clientId = (decoded.unique_name as string) || 
                    (decoded.LoginId as string) || 
                    (decoded.loginId as string) ||
                    (decoded["unique_name"] as string) ||
                    (decoded["LoginId"] as string) ||
                    null
          console.log("Step 2: clientId from decoded token:", clientId)
        }
      }
      
      // Step 3: If still no clientId, call check API to get it
      if (!clientId) {
        console.warn("ClientId still not found, calling check API to get clientId")
        const { xtsToken } = useAuthStore.getState()
        
        if (!xtsToken) {
          console.error("xtsToken not available, cannot call check API")
          const errorMsg = "Authentication tokens are missing. Please login again."
          setError(errorMsg)
          setLoading(false)
          return
        }
        
        try {
          console.log("Calling check API to retrieve clientId...")
          const checkResponse = await authService.checkToken(token, xtsToken)
          console.log("Check API response:", checkResponse)
          
          if (checkResponse.success && checkResponse.data) {
            // The check API returns: { success: true, data: { userId, clientId, ... } }
            // The data might be nested, so check both response.data.data and response.data
            const checkData = checkResponse.data.data || checkResponse.data
            clientId = (checkData?.clientId as string) || null
            console.log("Step 3: clientId from check API:", clientId)
            
            if (!clientId) {
              console.error("Check API did not return clientId. Response data:", checkData)
            }
          } else {
            console.error("Check API failed:", checkResponse.error)
          }
        } catch (checkError) {
          console.error("Error calling check API:", checkError)
          // Don't return here - try to continue with getUserDetails if we can
        }
      }
      
      // Final check - if we still don't have clientId, show error
      if (!clientId) {
        console.error("Unable to retrieve clientId from any source")
        const errorMsg = "Unable to retrieve user information. Please login again."
        setError(errorMsg)
        setLoading(false)
        return
      }

      console.log("Fetching user details for clientId:", clientId)
      const response = await authService.getUserDetails(clientId)
      
      console.log("User details API response:", response)
      
      if (response.success && response.data) {
        // Handle nested data structure - response.data might contain a data property
        // The API response structure is: { success: true, data: { clientId, clientName, emailId, userId, mobileNo, address, ... } }
        const userData = response.data.data || response.data
        console.log("Setting user details:", userData)
        
        // Ensure we have the data object with all fields
        if (userData && typeof userData === 'object') {
          setUserDetails(userData)
        } else {
          setError("Invalid profile data received from server")
        }
      } else {
        const errorMsg = response.error?.message || "Failed to fetch profile information"
        setError(errorMsg)
        console.error("Failed to fetch user details:", response.error)
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : "An error occurred while fetching profile"
      setError(errorMsg)
      console.error("Error fetching user details:", err)
    } finally {
      setLoading(false)
      isFetchingProfileRef.current = false
      profileFetchedRef.current = fetchKey
    }
  }, [token, isAuthenticated])

  useEffect(() => {
    const fetchKey = `${token ? 'authenticated' : 'unauthenticated'}`
    // Only fetch if not already fetched for this token state
    if (profileFetchedRef.current !== fetchKey && !isFetchingProfileRef.current) {
      fetchUserDetails()
    }
  }, [token, isAuthenticated]) // Removed fetchUserDetails dependency


  return (
    <div className="min-h-screen bg-[#F5F5F5] dark:bg-gray-950">
      <Header />
      <main className="pt-24 pb-8">
        <div className="max-w-[1600px] mx-auto px-8 sm:px-12 lg:px-28">
          {/* Header Section */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-1">Profile</h1>
            <p className="text-gray-500 dark:text-gray-400">
              View and manage your account information and preferences.
            </p>
          </div>

          {/* Loading State */}
          {loading && (
            <div className="flex items-center justify-center py-12">
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="w-8 h-8 animate-spin text-[#5266FC] dark:text-blue-400" />
                <p className="text-gray-500 dark:text-gray-400 text-sm">Loading profile...</p>
              </div>
            </div>
          )}

          {/* Error State */}
          {error && !loading && (
            <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
              <p className="text-red-600 dark:text-red-400 text-sm">{error}</p>
              <button 
                onClick={fetchUserDetails}
                className="mt-2 text-red-600 dark:text-red-400 underline text-sm hover:text-red-800 dark:hover:text-red-300"
              >
                Try again
              </button>
            </div>
          )}

          {/* Profile Content */}
          {!loading && !error && userDetails && (
            <div className="space-y-6">
              {/* Profile Header Card */}
              <div className="bg-gradient-to-r from-[#5266FC] to-[#16C9C3] dark:from-blue-700 dark:to-blue-600 rounded-xl p-8 shadow-lg">
                <div className="flex items-center gap-6">
                  {/* Avatar */}
                  <div className="flex-shrink-0">
                    <div className="w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm border-4 border-white/30 flex items-center justify-center">
                      <User className="w-12 h-12 text-white" />
                    </div>
                  </div>

                  {/* User Info */}
                  <div className="flex-1">
                    <h2 className="text-3xl font-bold text-white mb-2">
                      {userDetails.clientName || userDetails.name || userDetails.clientId || "User"}
                    </h2>
                    {userDetails.emailId && (
                      <p className="text-white/90 text-lg flex items-center gap-2">
                        <Mail className="w-5 h-5" />
                        {userDetails.emailId}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Details Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Personal Information Card */}
                <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-6 flex items-center gap-2 pb-3 border-b border-gray-200 dark:border-gray-700">
                    <div className="p-2 bg-[#5266FC]/10 dark:bg-blue-900/30 rounded-lg">
                      <User className="w-5 h-5 text-[#5266FC] dark:text-blue-400" />
                    </div>
                    Personal Information
                  </h3>
                  <div className="space-y-5">
                    <div className="pb-4 border-b border-gray-100 dark:border-gray-700 last:border-b-0">
                      <label className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-2 block">
                        Full Name
                      </label>
                      <p className="text-base font-medium text-gray-900 dark:text-gray-100 mt-1">
                        {userDetails.clientName || userDetails.name || userDetails.fullName || "Not provided"}
                      </p>
                    </div>
                    <div className="pb-4 border-b border-gray-100 dark:border-gray-700 last:border-b-0">
                      <label className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-2 block">
                        Email Address
                      </label>
                      <p className="text-base font-medium text-gray-900 dark:text-gray-100 mt-1 flex items-center gap-2">
                        <Mail className="w-4 h-4 text-[#5266FC] dark:text-blue-400" />
                        {userDetails.emailId || userDetails.email || "Not provided"}
                      </p>
                    </div>
                    {userDetails.mobileNo && (
                      <div>
                        <label className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-2 block">
                          Mobile Number
                        </label>
                        <p className="text-base font-medium text-gray-900 dark:text-gray-100 mt-1 flex items-center gap-2">
                          <Phone className="w-4 h-4 text-[#5266FC] dark:text-blue-400" />
                          {userDetails.mobileNo}
                        </p>
                      </div>
                    )}
                    {userDetails.address && (
                      <div>
                        <label className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-2 block">
                          Address
                        </label>
                        <p className="text-base font-medium text-gray-900 dark:text-gray-100 mt-1 flex items-start gap-2">
                          <MapPin className="w-4 h-4 text-[#5266FC] dark:text-blue-400 mt-1 flex-shrink-0" />
                          <span>{userDetails.address}</span>
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Account Information Card */}
                <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-6 flex items-center gap-2 pb-3 border-b border-gray-200 dark:border-gray-700">
                    <div className="p-2 bg-[#5266FC]/10 dark:bg-blue-900/30 rounded-lg">
                      <Shield className="w-5 h-5 text-[#5266FC] dark:text-blue-400" />
                    </div>
                    Account Information
                  </h3>
                  <div className="space-y-5">
                    <div className="pb-4 border-b border-gray-100 dark:border-gray-700">
                      <label className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-2 block">
                        Client ID
                      </label>
                      <p className="text-base font-medium text-gray-900 dark:text-gray-100 mt-1 flex items-center gap-2">
                        <IdCard className="w-4 h-4 text-[#5266FC] dark:text-blue-400" />
                        <span className="font-mono bg-gray-50 dark:bg-gray-700 px-3 py-1.5 rounded-md border border-gray-200 dark:border-gray-600 text-gray-900 dark:text-gray-100">
                          {userDetails.clientId || "N/A"}
                        </span>
                      </p>
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-2 block">
                        User ID
                      </label>
                      <p className="text-base font-medium text-gray-900 dark:text-gray-100 mt-1">
                        <span className="font-mono bg-gray-50 dark:bg-gray-700 px-3 py-1.5 rounded-md border border-gray-200 dark:border-gray-600 inline-block text-gray-900 dark:text-gray-100">
                          {userDetails.userId || "N/A"}
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Refresh Button */}
              <div className="flex justify-end">
                <button
                  onClick={fetchUserDetails}
                  disabled={loading}
                  className="px-6 py-2 bg-[#5266FC] dark:bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-[#4255E6] dark:hover:bg-blue-600 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Refreshing...
                    </>
                  ) : (
                    "Refresh Profile"
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

