"use client"

import { useState, useMemo, useEffect } from "react"
import { useSearchParams, useNavigate } from "react-router-dom"
import { ArrowLeft, TrendingUp, TrendingDown, Calendar as CalendarIcon, Loader2, BarChart3, DollarSign, Target, ChevronLeft, ChevronRight, ChevronDown, ChevronUp } from "lucide-react"
import Header from "@components/Header"
import Calendar from "react-calendar"
import "react-calendar/dist/Calendar.css"
import { Button } from "@components/ui/button"
import { reportsService } from "@/lib/api/reports.service"
import { toastr } from "@/lib/utils/toastr"

interface ReportsLegDto {
  legId: number
  signalId: number | null
  date: number
  exchange: string
  underlying: number | null
  quantity: number
  price: number
  sequentialPNL: number | null
  instrument: number
}

interface ReportsSignalDTO {
  signalId: number | null
  pnl: number
  pnlChange: number
  sequentialPNL: number
  orderCount: number | null
  reportsLegDtoList: ReportsLegDto[]
  date: string
}

interface BacktestReportData {
  strategyName: string
  strategyID: number
  reportsSignalDTOs: ReportsSignalDTO[]
  totalOrders: number | null
  totalPNL: number
}

const parseDateString = (dateStr: string): Date | null => {
  try {
    const [day, month, year] = dateStr.split("-").map(Number)
    return new Date(year, month - 1, day)
  } catch {
    return null
  }
}

const formatCurrency = (value: number | null | undefined): string => {
  if (value == null) return "₹0"
  const formatted = value.toLocaleString("en-IN", { maximumFractionDigits: 2 })
  return `₹${formatted}`
}

const formatTimestamp = (timestamp: number): string => {
  try {
    const date = new Date(timestamp * 1000)
    const hours = String(date.getHours()).padStart(2, '0')
    const minutes = String(date.getMinutes()).padStart(2, '0')
    const seconds = String(date.getSeconds()).padStart(2, '0')
    return `${hours}:${minutes}:${seconds}`
  } catch {
    return "--"
  }
}

const ITEMS_PER_PAGE = 10

export default function BacktestResultsPage() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const strategyName = searchParams.get("strategyName") || ""

  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<BacktestReportData | null>(null)
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined)
  const [currentPage, setCurrentPage] = useState(1)
  const [calendarCollapsed, setCalendarCollapsed] = useState(false)

  useEffect(() => {
    const decodedStrategyName = decodeURIComponent(strategyName)
    
    if (!decodedStrategyName || decodedStrategyName.trim() === "") {
      toastr.error("Error", "Strategy name not provided")
      navigate("/")
      return
    }

    const fetchBacktestData = async () => {
      setLoading(true)
      try {
        const response = await reportsService.getDefaultStrategyReport(decodedStrategyName)
        
        if (response.success && response.data) {
          setData(response.data as BacktestReportData)
        } else {
          const errorMessage = response.error?.message || "Failed to get default strategy report"
          toastr.error("Error", errorMessage)
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "An error occurred"
        toastr.error("Error", errorMessage)
      } finally {
        setLoading(false)
      }
    }

    fetchBacktestData()
  }, [strategyName, navigate])

  const dateToSignalMap = useMemo(() => {
    if (!data?.reportsSignalDTOs || !Array.isArray(data.reportsSignalDTOs)) {
      return new Map<string, ReportsSignalDTO>()
    }
    
    const map = new Map<string, ReportsSignalDTO>()
    data.reportsSignalDTOs.forEach((signal) => {
      if (signal && signal.date) {
        const date = parseDateString(signal.date)
        if (date && !isNaN(date.getTime())) {
          const dateKey = date.toISOString().split('T')[0]
          map.set(dateKey, signal)
        }
      }
    })
    return map
  }, [data])

  const datesWithSignals = useMemo(() => {
    return Array.from(dateToSignalMap.keys()).map(key => new Date(key))
  }, [dateToSignalMap])

  const selectedSignal = useMemo(() => {
    if (!selectedDate) return null
    const dateKey = selectedDate.toISOString().split('T')[0]
    return dateToSignalMap.get(dateKey) || null
  }, [selectedDate, dateToSignalMap])

  useEffect(() => {
    if (datesWithSignals.length > 0 && !selectedDate) {
      setSelectedDate(datesWithSignals[0])
    }
  }, [datesWithSignals, selectedDate])

  const performanceMetrics = useMemo(() => {
    if (!data?.reportsSignalDTOs || !Array.isArray(data.reportsSignalDTOs)) {
      return null
    }

    const signals = data.reportsSignalDTOs
    const totalSignals = signals.length
    const profitableDays = signals.filter(s => s.pnl > 0).length
    const losingDays = signals.filter(s => s.pnl < 0).length
    const winRate = totalSignals > 0 ? (profitableDays / totalSignals) * 100 : 0
    const avgDailyPNL = totalSignals > 0 
      ? signals.reduce((sum, s) => sum + s.pnl, 0) / totalSignals 
      : 0

    return {
      totalSignals,
      profitableDays,
      losingDays,
      winRate: Math.round(winRate * 10) / 10,
      avgDailyPNL,
    }
  }, [data])

  // Pagination for table
  const paginatedLegs = useMemo(() => {
    if (!selectedSignal?.reportsLegDtoList || !Array.isArray(selectedSignal.reportsLegDtoList)) {
      return []
    }
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE
    const endIndex = startIndex + ITEMS_PER_PAGE
    return selectedSignal.reportsLegDtoList.slice(startIndex, endIndex)
  }, [selectedSignal, currentPage])

  const totalPages = useMemo(() => {
    if (!selectedSignal?.reportsLegDtoList || !Array.isArray(selectedSignal.reportsLegDtoList)) {
      return 0
    }
    return Math.ceil(selectedSignal.reportsLegDtoList.length / ITEMS_PER_PAGE)
  }, [selectedSignal])

  useEffect(() => {
    setCurrentPage(1)
  }, [selectedDate])

  // Tile className function for react-calendar
  const tileClassName = ({ date }: { date: Date }) => {
    const dateKey = date.toISOString().split('T')[0]
    const signal = dateToSignalMap.get(dateKey)
    
    if (!signal) return ""
    
    const classes: string[] = []
    
    if (signal.pnl > 0) {
      classes.push("bg-green-50 dark:bg-green-900/20")
    } else if (signal.pnl < 0) {
      classes.push("bg-red-50 dark:bg-red-900/20")
    }
    
    classes.push("border-2 border-[#5266FC]")
    
    return classes.join(" ")
  }

  return (
    <div className="min-h-screen bg-[#F5F5F5] dark:bg-gray-950">
      <Header />
      <main className="pt-16 pb-6">
        <div className="max-w-[1600px] mx-auto px-8 sm:px-12 lg:px-28">
          {/* Compact Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate(-1)}
                className="h-8 px-2"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div>
                <h1 className="text-lg font-bold text-gray-900 dark:text-gray-100">Backtest Results</h1>
                {data && (
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {data.strategyName} • ID: {data.strategyID}
                  </p>
                )}
              </div>
            </div>
          </div>

          {loading ? (
            <div className="fixed inset-0 flex items-center justify-center bg-[#F5F5F5] dark:bg-gray-950 z-50">
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="w-8 h-8 animate-spin text-[#5266FC] dark:text-blue-400" />
                <p className="text-sm text-gray-600 dark:text-gray-400">Loading backtest results...</p>
              </div>
            </div>
          ) : data ? (
            <div className="space-y-4">
              {/* Compact Metrics - Single Row */}
              {performanceMetrics && (
                <div className="grid grid-cols-6 gap-2">
                  <div className="bg-white dark:bg-gray-900 rounded border border-gray-200 dark:border-gray-700 p-3">
                    <p className="text-[10px] text-gray-500 dark:text-gray-400 mb-1">Total P&L</p>
                    <p className={`text-sm font-bold ${data.totalPNL >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                      {formatCurrency(data.totalPNL)}
                    </p>
                  </div>
                  <div className="bg-white dark:bg-gray-900 rounded border border-gray-200 dark:border-gray-700 p-3">
                    <p className="text-[10px] text-gray-500 dark:text-gray-400 mb-1">Win Rate</p>
                    <p className="text-sm font-bold text-gray-900 dark:text-gray-100">
                      {performanceMetrics.winRate}%
                    </p>
                  </div>
                  <div className="bg-white dark:bg-gray-900 rounded border border-gray-200 dark:border-gray-700 p-3">
                    <p className="text-[10px] text-gray-500 dark:text-gray-400 mb-1">Avg Daily</p>
                    <p className={`text-sm font-bold ${performanceMetrics.avgDailyPNL >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                      {formatCurrency(performanceMetrics.avgDailyPNL)}
                    </p>
                  </div>
                  <div className="bg-white dark:bg-gray-900 rounded border border-gray-200 dark:border-gray-700 p-3">
                    <p className="text-[10px] text-gray-500 dark:text-gray-400 mb-1">Signals</p>
                    <p className="text-sm font-bold text-gray-900 dark:text-gray-100">
                      {performanceMetrics.totalSignals}
                    </p>
                  </div>
                  <div className="bg-white dark:bg-gray-900 rounded border border-gray-200 dark:border-gray-700 p-3">
                    <p className="text-[10px] text-gray-500 dark:text-gray-400 mb-1">Wins</p>
                    <p className="text-sm font-bold text-green-600 dark:text-green-400">
                      {performanceMetrics.profitableDays}
                    </p>
                  </div>
                  <div className="bg-white dark:bg-gray-900 rounded border border-gray-200 dark:border-gray-700 p-3">
                    <p className="text-[10px] text-gray-500 dark:text-gray-400 mb-1">Losses</p>
                    <p className="text-sm font-bold text-red-600 dark:text-red-400">
                      {performanceMetrics.losingDays}
                    </p>
                  </div>
                </div>
              )}

              {/* Main Content - Side by Side */}
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                {/* Calendar - Clean Design */}
                <div className="lg:col-span-1">
                  <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
                    <button
                      onClick={() => setCalendarCollapsed(!calendarCollapsed)}
                      className="w-full flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <CalendarIcon className="w-4 h-4 text-[#5266FC]" />
                        <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">Date Selection</span>
                      </div>
                      {calendarCollapsed ? (
                        <ChevronDown className="w-4 h-4 text-gray-500" />
                      ) : (
                        <ChevronUp className="w-4 h-4 text-gray-500" />
                      )}
                    </button>
                    {!calendarCollapsed && (
                      <div className="p-3">
                        <style>{`
                          .react-calendar {
                            width: 100%;
                            border: none;
                            background: transparent;
                            font-family: inherit;
                            line-height: 1.125em;
                          }
                          .react-calendar__navigation {
                            display: flex;
                            height: 36px;
                            margin-bottom: 0.75em;
                            align-items: center;
                            justify-content: space-between;
                          }
                          .react-calendar__navigation__label {
                            flex-grow: 0 !important;
                            font-size: 0.875rem;
                            font-weight: 600;
                            color: #111827;
                            padding: 0 0.5rem;
                            pointer-events: none;
                          }
                          .react-calendar__navigation button {
                            min-width: 32px;
                            height: 32px;
                            background: none;
                            font-size: 0.875rem;
                            color: #374151;
                            border-radius: 6px;
                            padding: 0;
                            margin: 0 2px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                          }
                          .react-calendar__navigation button:enabled:hover,
                          .react-calendar__navigation button:enabled:focus {
                            background-color: #f3f4f6;
                          }
                          .react-calendar__navigation button[disabled] {
                            background-color: transparent;
                            opacity: 0.4;
                          }
                          .react-calendar__month-view__weekdays {
                            text-align: center;
                            text-transform: uppercase;
                            font-weight: 500;
                            font-size: 0.625rem;
                            color: #6b7280;
                            margin-bottom: 0.5em;
                            display: flex;
                            justify-content: space-between;
                          }
                          .react-calendar__month-view__weekdays__weekday {
                            padding: 0.25em 0;
                            flex: 1;
                            text-align: center;
                            overflow: hidden;
                            text-overflow: ellipsis;
                          }
                          .react-calendar__month-view__weekdays__weekday abbr {
                            text-decoration: none;
                            border-bottom: none;
                          }
                          .react-calendar__month-view__days {
                            display: grid !important;
                            grid-template-columns: repeat(7, 1fr);
                            gap: 2px;
                            margin-top: 0.25em;
                          }
                          .react-calendar__tile {
                            max-width: 100%;
                            padding: 0.375rem 0;
                            background: none;
                            text-align: center;
                            line-height: 1.25;
                            font-size: 0.75rem;
                            border-radius: 4px;
                            color: #111827;
                            transition: all 0.15s ease;
                            aspect-ratio: 1;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            position: relative;
                            margin: 0;
                          }
                          .react-calendar__tile:enabled:hover,
                          .react-calendar__tile:enabled:focus {
                            background-color: #f3f4f6;
                            outline: none;
                          }
                          .react-calendar__tile--now {
                            background: #f3f4f6;
                            font-weight: 600;
                          }
                          .react-calendar__tile--now:enabled:hover,
                          .react-calendar__tile--now:enabled:focus {
                            background: #e5e7eb;
                          }
                          .react-calendar__tile--active {
                            background: #5266FC !important;
                            color: white !important;
                            font-weight: 600;
                            z-index: 1;
                          }
                          .react-calendar__tile--active:enabled:hover,
                          .react-calendar__tile--active:enabled:focus {
                            background: #4255E6 !important;
                          }
                          .react-calendar__tile--neighboringMonth {
                            color: #9ca3af;
                            opacity: 0.4;
                          }
                          .react-calendar__tile--hasActive {
                            background: #dbeafe;
                          }
                          .react-calendar__tile--hasActive:enabled:hover,
                          .react-calendar__tile--hasActive:enabled:focus {
                            background: #bfdbfe;
                          }
                          .dark .react-calendar__navigation__label {
                            color: #f3f4f6;
                          }
                          .dark .react-calendar__navigation button {
                            color: #d1d5db;
                          }
                          .dark .react-calendar__navigation button:enabled:hover,
                          .dark .react-calendar__navigation button:enabled:focus {
                            background-color: #374151;
                          }
                          .dark .react-calendar__month-view__weekdays {
                            color: #9ca3af;
                          }
                          .dark .react-calendar__tile {
                            color: #f3f4f6;
                          }
                          .dark .react-calendar__tile:enabled:hover,
                          .dark .react-calendar__tile:enabled:focus {
                            background-color: #374151;
                          }
                          .dark .react-calendar__tile--now {
                            background: #374151;
                          }
                          .dark .react-calendar__tile--now:enabled:hover,
                          .dark .react-calendar__tile--now:enabled:focus {
                            background: #4b5563;
                          }
                          .dark .react-calendar__tile--hasActive {
                            background: #1e3a8a;
                          }
                          .dark .react-calendar__tile--hasActive:enabled:hover,
                          .dark .react-calendar__tile--hasActive:enabled:focus {
                            background: #1e40af;
                          }
                        `}</style>
                        <Calendar
                          onChange={(value) => {
                            if (value instanceof Date) {
                              setSelectedDate(value)
                            } else if (Array.isArray(value) && value[0]) {
                              setSelectedDate(value[0])
                            }
                          }}
                          value={selectedDate}
                          tileClassName={tileClassName}
                          className="w-full"
                          calendarType="gregory"
                          formatShortWeekday={(locale, date) => {
                            const days = ['S', 'M', 'T', 'W', 'T', 'F', 'S']
                            return days[date.getDay()]
                          }}
                        />
                        <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700 space-y-2">
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 bg-green-100 dark:bg-green-900/30 border border-green-400 dark:border-green-600 rounded-sm"></div>
                            <span className="text-xs text-gray-600 dark:text-gray-400">Profitable Day</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 bg-red-100 dark:bg-red-900/30 border border-red-400 dark:border-red-600 rounded-sm"></div>
                            <span className="text-xs text-gray-600 dark:text-gray-400">Losing Day</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 border-2 border-[#5266FC] rounded-sm bg-transparent"></div>
                            <span className="text-xs text-gray-600 dark:text-gray-400">Has Signals</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Trading Signals Table - Takes 3/4 width */}
                <div className="lg:col-span-3">
                  <div className="bg-white dark:bg-gray-900 rounded border border-gray-200 dark:border-gray-700">
                    {selectedSignal ? (
                      <div>
                        {/* Compact Header */}
                        <div className="flex items-center justify-between p-3 border-b border-gray-200 dark:border-gray-700">
                          <div>
                            <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">Trading Signals</h3>
                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{selectedSignal.date}</p>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <p className="text-[10px] text-gray-500 dark:text-gray-400">Daily P&L</p>
                              <p className={`text-sm font-bold flex items-center gap-1 ${selectedSignal.pnl >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                                {selectedSignal.pnl >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                                {formatCurrency(selectedSignal.pnl)}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="text-[10px] text-gray-500 dark:text-gray-400">Cumulative</p>
                              <p className={`text-sm font-bold ${selectedSignal.sequentialPNL >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                                {formatCurrency(selectedSignal.sequentialPNL)}
                              </p>
                            </div>
                          </div>
                        </div>

                        {/* Compact Table with Fixed Height */}
                        <div className="overflow-x-auto max-h-[500px]">
                          <table className="w-full">
                            <thead className="bg-gray-50 dark:bg-gray-800 sticky top-0 z-10">
                              <tr>
                                <th className="px-3 py-2 text-left text-[10px] font-semibold text-gray-700 dark:text-gray-300 uppercase">Time</th>
                                <th className="px-3 py-2 text-left text-[10px] font-semibold text-gray-700 dark:text-gray-300 uppercase">Instrument</th>
                                <th className="px-3 py-2 text-left text-[10px] font-semibold text-gray-700 dark:text-gray-300 uppercase">Qty</th>
                                <th className="px-3 py-2 text-left text-[10px] font-semibold text-gray-700 dark:text-gray-300 uppercase">Price</th>
                                <th className="px-3 py-2 text-left text-[10px] font-semibold text-gray-700 dark:text-gray-300 uppercase">Leg ID</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                              {paginatedLegs.length > 0 ? (
                                paginatedLegs.map((leg, index) => (
                                  <tr key={leg?.legId || index} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <td className="px-3 py-2 text-xs text-gray-900 dark:text-gray-100">
                                      {leg?.date ? formatTimestamp(leg.date) : "--"}
                                    </td>
                                    <td className="px-3 py-2 text-xs text-gray-900 dark:text-gray-100 font-mono">
                                      {leg?.instrument ?? "--"}
                                    </td>
                                    <td className="px-3 py-2 text-xs text-gray-900 dark:text-gray-100">
                                      {leg?.quantity ?? "--"}
                                    </td>
                                    <td className="px-3 py-2 text-xs text-gray-900 dark:text-gray-100">
                                      {leg?.price ? formatCurrency(leg.price) : "--"}
                                    </td>
                                    <td className="px-3 py-2 text-xs text-gray-500 dark:text-gray-400 font-mono">
                                      {leg?.legId ?? "--"}
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan={5} className="px-3 py-8 text-xs text-center text-gray-500 dark:text-gray-400">
                                    No trading legs available
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>

                        {/* Compact Pagination */}
                        {totalPages > 1 && (
                          <div className="flex items-center justify-between px-3 py-2 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
                            <div className="text-[10px] text-gray-600 dark:text-gray-400">
                              Page {currentPage} of {totalPages} • {selectedSignal.reportsLegDtoList.length} total legs
                            </div>
                            <div className="flex items-center gap-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                                disabled={currentPage === 1}
                                className="h-7 px-2 text-xs"
                              >
                                <ChevronLeft className="w-3 h-3" />
                              </Button>
                              <span className="text-xs text-gray-600 dark:text-gray-400 px-2">
                                {currentPage}
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                                disabled={currentPage === totalPages}
                                className="h-7 px-2 text-xs"
                              >
                                <ChevronRight className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-12 text-gray-400">
                        <CalendarIcon className="w-12 h-12 mb-2 opacity-40" />
                        <p className="text-xs text-gray-600 dark:text-gray-400">Select a date to view signals</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-gray-400">
              <CalendarIcon className="w-12 h-12 mb-2 opacity-40" />
              <p className="text-xs text-gray-600 dark:text-gray-400">No backtest data available</p>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
