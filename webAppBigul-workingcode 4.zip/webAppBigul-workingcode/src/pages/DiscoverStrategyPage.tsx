import Header from "@components/Header"
import DiscoverStrategy from "@components/DiscoverStrategy"

export default function DiscoverStrategyPage() {
  return (
    <div className="min-h-screen bg-[#F5F5F5] dark:bg-gray-950">
      <Header />
      <DiscoverStrategy />
    </div>
  )
}

