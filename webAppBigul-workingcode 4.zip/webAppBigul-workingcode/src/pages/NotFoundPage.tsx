import { Link } from "react-router-dom"
import Header from "@components/Header"

export default function NotFoundPage() {
  return (
    <div className="min-h-screen" style={{ backgroundColor: "#F5F5F5" }}>
      <Header />
      <div className="pt-24 pb-8">
        <div className="max-w-7xl mx-auto px-8 sm:px-12 lg:px-28">
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
            <h1 className="text-6xl font-bold text-gray-900 mb-4">404</h1>
            <p className="text-xl text-gray-600 mb-8">Page Not Found</p>
            <Link
              to="/"
              className="px-6 py-3 bg-[#5266FC] text-white rounded-md font-medium hover:bg-[#4255E6] transition-colors"
            >
              Go Back Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

