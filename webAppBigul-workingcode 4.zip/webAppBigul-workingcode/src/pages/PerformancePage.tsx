import React, { useState, useRef, useEffect, useCallback, useMemo } from "react"
import { logger } from "@/lib/utils/logger"
import { useSearchParams, Link, useLocation, useNavigate } from "react-router-dom"
import { Bookmark, Share2, Star, ChevronRight, Zap, Info, ArrowUpRight, Loader2, Minus, Plus, Settings, Sliders, TrendingUp, BarChart3, Target, Calendar, DollarSign, AlertTriangle } from "lucide-react"
import { Area, AreaChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip as RechartsTooltip } from "recharts"
// import PayoffChart from "@components/PayoffChart"
import Header from "@components/Header"
import { reportsService } from "@/lib/api/reports.service"
import { authService } from "@/lib/api/auth.service"
import { strategyService } from "@/lib/api/strategy.service"
import { diyService } from "@/lib/api/diy.service"
import { useAuthStore } from "@/store/auth.store"
import { useActiveStrategies } from "@/hooks/useActiveStrategies"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@components/ui/dialog"
import { Button } from "@components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@components/ui/select"
import { ToggleGroup, ToggleGroupItem } from "@components/ui/toggle-group"
import { Tooltip, TooltipContent, TooltipTrigger } from "@components/ui/tooltip"
import { Card, CardContent, CardHeader, CardTitle } from "@components/ui/card"
import type { DropdownsResponse, StatisticsResponse } from "@/lib/api/types"

// Module-level cache to persist across StrictMode remounts
// This ensures API calls are only made once even if component remounts
const apiCallCache = {
  details: new Map<string, boolean>(),
  reports: new Map<string, boolean>(),
  statistics: new Map<string, boolean>(),
  related: new Map<string, boolean>(),
  isFetching: {
    details: false,
    reports: false,
    statistics: false,
    related: false,
  }
}

export default function PerformancePage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const location = useLocation()
  const strategyId = searchParams.get("strategyId") ? Number(searchParams.get("strategyId")) : null
  const tabParam = searchParams.get("tab")
  
  // Set initial tab from URL parameter, default to "performance"
  const getInitialTab = () => {
    if (tabParam === "orders") return "orders"
    if (tabParam === "performance") return "performance"
    // Default to performance tab when coming from My Strategy
    return "performance"
  }
  
  // Get the source page from URL parameter, location state, or referrer
  const getSourcePage = () => {
    // First check URL parameter (most reliable, persists across refreshes)
    const fromParam = searchParams.get("from")
    if (fromParam === "discover") {
      return "Discover Strategy"
    } else if (fromParam === "home") {
      return "Home"
    } else if (fromParam === "my-strategy") {
      return "PNL"
    } else if (fromParam === "create-strategy") {
      return "Build Custom Strategy"
    }
    
    // Check if state was passed during navigation
    const state = location.state as { from?: string; strategyTitle?: string; strategyDescription?: string; strategyCategory?: string } | null
    if (state?.from) {
      return state.from
    }
    
    // Check referrer from document
    if (typeof window !== "undefined" && document.referrer) {
      const referrer = new URL(document.referrer)
      const pathname = referrer.pathname
      
      if (pathname.includes("/discover")) {
        return "Discover Strategy"
      } else if (pathname.includes("/my-strategy")) {
        return "PNL"
      } else if (pathname.includes("/create-strategy")) {
        return "Build Custom Strategy"
      } else if (pathname === "/" || pathname.includes("/home")) {
        return "Home"
      }
    }
    
    // Default to PNL if coming from my-strategy context
    return "PNL"
  }
  
  const sourcePage = getSourcePage()
  const sourcePageLink = sourcePage === "Discover Strategy" ? "/discover" 
    : sourcePage === "PNL" ? "/my-strategy"
    : sourcePage === "Build Custom Strategy" ? "/create-strategy"
    : "/"
  
  // Convert sourcePage to from parameter for URL
  const getFromParam = (page: string): string => {
    if (page === "Discover Strategy") return "discover"
    if (page === "Home") return "home"
    if (page === "PNL") return "my-strategy"
    if (page === "Build Custom Strategy") return "create-strategy"
    return "home"
  }
  const [activeTab, setActiveTab] = useState(getInitialTab)
  const [statsMode, setStatsMode] = useState("simple")
  const [strategyDetails, setStrategyDetails] = useState<any>(null)
  const [isPopular, setIsPopular] = useState<boolean>(false)
  const [strategyReports, setStrategyReports] = useState<any>(null)
  const [reportsLoading, setReportsLoading] = useState(false)
  const [statisticsData, setStatisticsData] = useState<any[]>([])
  const [fullStatisticsData, setFullStatisticsData] = useState<any>(null)
  const [statisticsLoading, setStatisticsLoading] = useState(false)
  const [ordersData, setOrdersData] = useState<any[]>([])
  const [ordersCurrentPage, setOrdersCurrentPage] = useState(1)
  const ordersPerPage = 10
  
  // Calculate pagination for orders
  const ordersTotalPages = Math.ceil(ordersData.length / ordersPerPage)
  const ordersStartIndex = (ordersCurrentPage - 1) * ordersPerPage
  const ordersEndIndex = ordersStartIndex + ordersPerPage
  const paginatedOrdersData = ordersData.slice(ordersStartIndex, ordersEndIndex)
  
  // Reset to page 1 when orders data changes - use useMemo for derived state
  useEffect(() => {
    if (ordersData.length > 0 && ordersCurrentPage > Math.ceil(ordersData.length / ordersPerPage)) {
      setOrdersCurrentPage(1)
    }
  }, [ordersData.length, ordersCurrentPage, ordersPerPage])
  const [relatedStrategies, setRelatedStrategies] = useState<any[]>([])
  const [relatedStrategiesLoading, setRelatedStrategiesLoading] = useState(false)
  const relatedStrategiesFetchedRef = useRef(false)
  const dataFetchedRef = useRef<string | null>(null) // Track which strategyId we've fetched data for
  const isFetchingRef = useRef(false) // Prevent concurrent fetches
  
  // Individual refs for each API to prevent duplicates even with StrictMode
  const detailsFetchedRef = useRef<string | null>(null)
  const isFetchingDetailsRef = useRef(false)
  const reportsFetchedRef = useRef<string | null>(null)
  const isFetchingReportsRef = useRef(false)
  const statisticsFetchedRef = useRef<string | null>(null)
  const isFetchingStatisticsRef = useRef(false)
  const relatedStrategiesFetchedRef2 = useRef<string | null>(null)
  const isFetchingRelatedRef = useRef(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isCheckingAuth, setIsCheckingAuth] = useState(false)
  const { token, isAuthenticated, xtsToken, userId } = useAuthStore()
  const { activeStrategies, refetch: refetchActiveStrategies } = useActiveStrategies()
  
  // Deploy dialog state
  const [deployDialogOpen, setDeployDialogOpen] = useState(false)
  const [deployMode, setDeployMode] = useState<'normal' | 'customize'>('normal') // Track deploy mode
  const [multiplier, setMultiplier] = useState<number>(1)
  const [executionTypeId, setExecutionTypeId] = useState<string>("LiveTrading")
  const [deployLoading, setDeployLoading] = useState(false)
  const [deployError, setDeployError] = useState<string | null>(null)
  const [marginNeeded, setMarginNeeded] = useState<number>(0)
  const [marginAvailable, _setMarginAvailable] = useState<number>(15425.10)
  const [undeployLoading, setUndeployLoading] = useState(false)
  const [undeployDialogOpen, setUndeployDialogOpen] = useState(false)
  const [pendingUndeployStrategy, setPendingUndeployStrategy] = useState<{ strategyId: number; strategyName: string } | null>(null)
  
  // Backtest consent dialog state
  const [backtestConsentOpen, setBacktestConsentOpen] = useState(false)
  const [pendingBacktestStrategy, setPendingBacktestStrategy] = useState<string | null>(null)
  const [backtestConsentLoading, setBacktestConsentLoading] = useState(false)
  
  const navigate = useNavigate()
  
  // Dropdowns state
  const [dropdowns, setDropdowns] = useState<DropdownsResponse['data'] | null>(null)
  const [dropdownsLoading, setDropdownsLoading] = useState(false)
  
  // All customize deploy fields state
  const [strategyType, setStrategyType] = useState<string>("Intraday")
  const [underlying, setUnderlying] = useState<number>(1)
  const [expiryType, setExpiryType] = useState<string>("CurrentWeek")
  const [strikeSelection, setStrikeSelection] = useState<string>("SpotAtm")
  const [positionType, setPositionType] = useState<string>("OPTION")
  const [entryDays, setEntryDays] = useState<number[]>([1, 2, 3, 4, 5])
  const [exitAfterEntry, setExitAfterEntry] = useState<number>(3)
  const [exitOnExpiry, setExitOnExpiry] = useState<string>("yes")
  const [segmentType, setSegmentType] = useState<string>("Ce")
  const [order, setOrder] = useState<string>("Buy")
  const [profitMtm, setProfitMtm] = useState<string>("PercentOfCapital")
  const [tgt, setTgt] = useState<string>("PercentOfEntryPrice")
  const [trl, setTrl] = useState<string>("PercentOfEntry")
  
  // Share modal state
  const [shareModalOpen, setShareModalOpen] = useState(false)
  
  // Performance chart tooltip state
  const [performanceTooltip, setPerformanceTooltip] = useState<{
    x: number
    y: number
    date?: string
    value?: number
    label?: string
  } | null>(null)
  const performanceChartRef = useRef<HTMLDivElement>(null)

  // Function to ensure userId is available by calling check API if needed
  const ensureUserId = useCallback(async (): Promise<boolean> => {
    // If userId is already available, return true
    if (userId) {
      return true
    }

    // If tokens are not available, cannot proceed
    if (!token || !xtsToken) {
      logger.warn("PerformancePage: Cannot ensure userId - tokens missing")
      return false
    }

    // If already checking, wait
    if (isCheckingAuth) {
      logger.log("PerformancePage: Already checking auth, waiting...")
      return false
    }

    setIsCheckingAuth(true)
    try {
      logger.log("📡 PerformancePage: userId not available, calling check API to get it...")
      const checkResponse = await authService.checkToken(token, xtsToken)
      logger.log("📡 PerformancePage: Check API response:", checkResponse)

      if (checkResponse.success && checkResponse.data) {
        const checkData = checkResponse.data as any
        const responseUserId = checkData?.data?.userId || checkData?.userId

        if (responseUserId) {
          logger.log("✅ PerformancePage: userId received from check API:", responseUserId)
          useAuthStore.getState().setUserId(responseUserId)
          return true
        } else {
          logger.error("❌ PerformancePage: Check API did not return userId")
          setError("Failed to retrieve user information. Please login again.")
          return false
        }
      } else {
        logger.error("❌ PerformancePage: Check API failed:", checkResponse.error)
        setError(checkResponse.error?.message || "Authentication failed. Please login again.")
        return false
      }
    } catch (err) {
      logger.error("❌ PerformancePage: Exception during check API call:", err)
      setError(err instanceof Error ? err.message : "An error occurred during authentication")
      return false
    } finally {
      setIsCheckingAuth(false)
    }
  }, [token, xtsToken, userId, isCheckingAuth])

  // Handle backtest click - show consent dialog first
  const handleBacktestClick = useCallback((card: any, e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    
    const strategyName = (card.title || "") as string
    if (!strategyName) {
      return
    }

    // Show consent dialog
    setPendingBacktestStrategy(strategyName)
    setBacktestConsentOpen(true)
  }, [])

  // Handle consent confirmation
  const handleBacktestConsent = useCallback(() => {
    if (pendingBacktestStrategy) {
      setBacktestConsentLoading(true)
      // Navigate immediately - the page will handle loading
      navigate(`/backtest-results?strategyName=${encodeURIComponent(pendingBacktestStrategy)}`)
      setBacktestConsentOpen(false)
      setPendingBacktestStrategy(null)
      setBacktestConsentLoading(false)
    }
  }, [pendingBacktestStrategy, navigate])

  // Transform strategy data to card format
  const transformStrategyToCard = useCallback((strategy: any) => {
    // Generate tags
    const tags: string[] = []
    
    // Add underlying
    const getUnderlyingName = (underlying: string | number | undefined): string => {
      const underlyingMap: Record<string | number, string> = {
        1: "Nifty", 
        2: "Bank Nifty", 
        3: "FinNifty", 
        4: "Sensex", 
        5: "Bankex",
      }
      return underlyingMap[underlying as string | number] || "Nifty"
    }
    
    if (strategy.underlying) {
      tags.push(getUnderlyingName(strategy.underlying))
    }
    
    if (strategy.positionType) {
      tags.push(strategy.positionType)
    }
    
    if (strategy.executionType) {
      if (strategy.executionType === "PaperTrading") {
        tags.push("Forward Test")
      } else if (strategy.executionType === "LiveTrading") {
        tags.push("Live Trading")
      }
    }
    
    // Format capital
    const formatCapital = (capital: number | string | undefined): string => {
      if (!capital) return "₹0"
      if (typeof capital === "string") {
        if (capital.includes("₹")) return capital
        const num = parseFloat(capital)
        if (isNaN(num)) return capital
        capital = num
      }
      if (capital >= 100000) {
        return `₹${(capital / 100000).toFixed(2)}L`
      } else if (capital >= 1000) {
        return `₹${(capital / 1000).toFixed(2)}k`
      }
      return `₹${capital.toLocaleString('en-IN')}`
    }
    
    return {
      id: strategy.id || strategy.sid,
      title: strategy.name || strategy.title || "Untitled Strategy",
      tags: tags.length > 0 ? tags : ["Strategy"],
      description: strategy.description || "Strategy description not available.",
      minCapital: formatCapital(strategy.minCapital || strategy.requiredCapital || strategy.capital),
      avgReturn: "Backtest",
      riskLevel: "Medium",
    }
  }, [])

  // Fetch strategy details - same pattern as MyStrategyPage
  const fetchStrategyDetails = useCallback(async () => {
    if (!strategyId) {
      setLoading(false)
      setError("Strategy ID is required")
      return
    }

    const strategyIdKey = String(strategyId)
    const cacheKey = `details-${strategyIdKey}`
    
    // Prevent duplicate calls - check module-level cache first (works with StrictMode)
    if (apiCallCache.details.has(cacheKey) || apiCallCache.isFetching.details) {
      return
    }

    if (!token || !isAuthenticated) {
      setLoading(false)
      setError("Authentication required. Please login again.")
      return
    }

    // Set fetching flag in both ref and cache
    isFetchingDetailsRef.current = true
    apiCallCache.isFetching.details = true

    // Ensure userId is available - call check API if needed
    const currentUserId = useAuthStore.getState().userId
    if (!currentUserId) {
      logger.log("⚠️ PerformancePage: userId not in store, calling check API...")
      const hasUserId = await ensureUserId()
      if (!hasUserId) {
        setLoading(false)
        isFetchingDetailsRef.current = false
        return
      }
    }

    setLoading(true)
    setError(null)
    try {
      logger.log("📡 PerformancePage: Calling getStrategyDetails API with strategyId:", strategyId)
      const detailsResponse = await reportsService.getStrategyDetails({ strategyId })
      logger.log("📡 PerformancePage: getStrategyDetails API Response:", detailsResponse)
      
      if (detailsResponse.success && detailsResponse.data) {
        logger.log("✅ PerformancePage: Strategy details received")
        // Extract detailedStrategyResponse from nested structure
        const responseData = detailsResponse.data as any
        const strategyData = responseData.detailedStrategyResponse || responseData.data || responseData
        logger.log("📊 PerformancePage: Extracted strategy data:", strategyData)
        logger.log("📊 PerformancePage: Strategy category from API:", strategyData?.category || strategyData?.strategyType || "not found")
        
        // Ensure category is preserved if it exists in the response
        if (strategyData && !strategyData.category) {
          // Try to get category from nested structures
          const categoryFromNested = (responseData as any)?.category || (responseData as any)?.strategyCategory
          if (categoryFromNested) {
            strategyData.category = categoryFromNested
            logger.log("📊 PerformancePage: Added category from nested structure:", categoryFromNested)
          }
        }
        
        setStrategyDetails(strategyData)
        
        // Check if activeStrategiesDropdown exists in response for related strategies
        if (responseData.activeStrategiesDropdown && Array.isArray(responseData.activeStrategiesDropdown) && responseData.activeStrategiesDropdown.length > 0) {
          logger.log("📊 PerformancePage: Found activeStrategiesDropdown with", responseData.activeStrategiesDropdown.length, "strategies")
          // Transform dropdown strategies to card format
          const transformed = responseData.activeStrategiesDropdown
            .filter((s: any) => s.sid !== strategyId) // Exclude current strategy
            .slice(0, 3) // Limit to 3 strategies
            .map((strategy: any) => transformStrategyToCard(strategy))
          setRelatedStrategies(transformed)
          relatedStrategiesFetchedRef.current = true
        } else {
          // If no dropdown data, we'll fetch popular strategies separately
          logger.log("📊 PerformancePage: No activeStrategiesDropdown, will fetch popular strategies separately")
        }
      } else {
        const errorMsg = detailsResponse.error?.message || "Failed to fetch strategy details"
        logger.warn("⚠️ PerformancePage: Failed to fetch strategy details:", errorMsg)
        setError(errorMsg)
      }
    } catch (err) {
      logger.error("❌ PerformancePage: Exception during getStrategyDetails API call:", err)
        setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
      isFetchingDetailsRef.current = false
      detailsFetchedRef.current = strategyIdKey
      apiCallCache.isFetching.details = false
      apiCallCache.details.set(cacheKey, true)
    }
  }, [strategyId, token, isAuthenticated, ensureUserId, transformStrategyToCard])

  // Fetch strategy reports - same pattern as MyStrategyPage
  const fetchStrategyReports = useCallback(async () => {
    if (!strategyId) {
      return
    }

    const strategyIdKey = String(strategyId)
    const cacheKey = `reports-${strategyIdKey}`
    
    // Prevent duplicate calls - check module-level cache first (works with StrictMode)
    if (apiCallCache.reports.has(cacheKey) || apiCallCache.isFetching.reports) {
      return
    }

    if (!token || !isAuthenticated) {
      return
    }

    // Set fetching flag in both ref and cache
    isFetchingReportsRef.current = true
    apiCallCache.isFetching.reports = true
    setReportsLoading(true)

    // Ensure userId is available - call check API if needed
    const currentUserId = useAuthStore.getState().userId
    if (!currentUserId) {
      const hasUserId = await ensureUserId()
      if (!hasUserId) {
        isFetchingReportsRef.current = false
        return
      }
    }

    try {
      const reportsResponse = await reportsService.getStrategyReports({
        fromDate: "",
        toDate: "",
        strategyId,
      })
      console.log("📡 PerformancePage: getStrategyReports API Response:", reportsResponse)
      
      if (reportsResponse.success && reportsResponse.data) {
        const responseData = reportsResponse.data as any
        console.log("✅ PerformancePage: Strategy reports received from API")
        console.log("📊 PerformancePage: Reports data structure:", responseData)
        console.log("📊 PerformancePage: reportsSignalDTOs count:", responseData.reportsSignalDTOs?.length || 0)
        // Set strategyReports - this will be used by PayoffChart
        // Commented out for now
        setStrategyReports(responseData)
        
        // Extract orders from reportsSignalDTOs if available
        // Each signal has a reportsLegDtoList array with leg details
        if (responseData.reportsSignalDTOs && Array.isArray(responseData.reportsSignalDTOs)) {
          console.log("📊 PerformancePage: Found reportsSignalDTOs:", responseData.reportsSignalDTOs.length, "items")
          
          // Flatten all legs from all signals into a single array
          const allLegs: any[] = []
          responseData.reportsSignalDTOs.forEach((signal: any) => {
            if (signal.reportsLegDtoList && Array.isArray(signal.reportsLegDtoList)) {
              signal.reportsLegDtoList.forEach((leg: any) => {
                // Format date from timestamp (leg.date is in seconds with decimals)
                const entryDate = leg.date ? new Date(leg.date * 1000).toLocaleString('en-IN', {
                  year: 'numeric',
                  month: '2-digit',
                  day: '2-digit',
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit'
                }) : ""
                
                allLegs.push({
                  legId: leg.legId || "",
                  tradedInstrument: leg.instrument ? `Instrument ${leg.instrument}` : "",
                  ltp: "N/A", // LTP not available in API response
                  tradedLots: leg.quantity || 0,
                  entryPrice: leg.price ? `₹${leg.price.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "",
                  exitPrice: "N/A", // Exit price not available in individual leg data
                  entryTime: entryDate,
                  exitTime: "N/A", // Exit time not available in individual leg data
                  pnl: signal.pnl ? `₹${signal.pnl.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "₹0.00",
                  signalId: leg.signalId || "",
                  date: signal.date || "",
                })
              })
            }
          })
          
          console.log("📊 PerformancePage: Mapped orders from legs:", allLegs.length, "items")
          setOrdersData(allLegs)
        } else {
          // If no orders, set empty array
          setOrdersData([])
        }
      } else {
        console.warn("⚠️ PerformancePage: Failed to fetch strategy reports:", reportsResponse.error)
      }
    } catch (err) {
      console.error("❌ PerformancePage: Exception during getStrategyReports API call:", err)
    } finally {
      isFetchingReportsRef.current = false
      reportsFetchedRef.current = strategyIdKey
      apiCallCache.isFetching.reports = false
      apiCallCache.reports.set(cacheKey, true)
      setReportsLoading(false)
    }
  }, [strategyId, token, isAuthenticated, ensureUserId])

  // Fetch statistics for a strategy
  const fetchStatistics = useCallback(async () => {
    if (!strategyId) {
      return
    }

    const strategyIdKey = String(strategyId)
    const cacheKey = `statistics-${strategyIdKey}`
    
    // Prevent duplicate calls - check module-level cache first (works with StrictMode)
    if (apiCallCache.statistics.has(cacheKey) || apiCallCache.isFetching.statistics) {
      return
    }

    if (!token || !isAuthenticated) {
      isFetchingStatisticsRef.current = false
      return
    }

    // Set fetching flag in both ref and cache
    isFetchingStatisticsRef.current = true
    apiCallCache.isFetching.statistics = true

    if (!token || !isAuthenticated) {
      isFetchingStatisticsRef.current = false
      return
    }

    // Ensure userId is available - call check API if needed
    const currentUserId = useAuthStore.getState().userId
    if (!currentUserId) {
      console.log("⚠️ PerformancePage: userId not in store, calling check API...")
      const hasUserId = await ensureUserId()
      if (!hasUserId) {
        isFetchingStatisticsRef.current = false
        return
      }
    }

    setStatisticsLoading(true)
    setError(null)
    try {
      console.log("📡 PerformancePage: Calling getStatistics API with strategyId:", strategyId)
      console.log("📡 PerformancePage: strategyId type:", typeof strategyId, "value:", strategyId)
      console.log("📡 PerformancePage: API endpoint: GET /ql/statistics/" + strategyId)
      
      if (!strategyId || isNaN(Number(strategyId))) {
        console.error("❌ PerformancePage: Invalid strategyId:", strategyId)
        setError("Invalid strategy ID")
        setStatisticsLoading(false)
        isFetchingStatisticsRef.current = false
        return
      }
      
      const statisticsResponse = await reportsService.getStatistics(strategyId)
      console.log("📡 PerformancePage: getStatistics API Response:", statisticsResponse)
      
      if (statisticsResponse.success && statisticsResponse.data) {
        const statsData = statisticsResponse.data as any
        console.log("✅ PerformancePage: Statistics received:", statsData)
        console.log("✅ PerformancePage: Statistics data structure:", {
          performanceOverview: statsData?.performanceOverview,
          statistics: statsData?.statistics,
          weekStatsSummary: statsData?.weekStatsSummary,
          profitStatistics: statsData?.profitStatistics,
          riskMetrics: statsData?.riskMetrics,
          statisticsIndexes: statsData?.statisticsIndexes
        })
        
        // Transform API data to table format - use statistics array directly from API
        const formatValue = (value: any): string => {
          if (value === null || value === undefined) return "0"
          if (typeof value === 'number') {
            // Format numbers with proper formatting
            if (value % 1 === 0) {
              return value.toString()
            } else {
              return value.toFixed(2)
            }
          }
          return value.toString()
        }
        
        // Use the statistics array directly from API response
        const transformedStats = statsData?.statistics?.map((stat: any, index: number) => ({
          srNo: index + 1,
          name: stat.name || "",
          value: formatValue(stat.value || 0)
        })) || []
        
        console.log("✅ PerformancePage: Transformed statistics:", transformedStats)
        setStatisticsData(transformedStats)
        
        // Store full statistics data for detailed display - statsData is already the data object
        setFullStatisticsData(statsData || null)
        console.log("✅ PerformancePage: Full statistics data stored:", statsData)
      } else {
        console.warn("⚠️ PerformancePage: Failed to fetch statistics:", statisticsResponse.error)
      }
    } catch (err) {
      console.error("❌ PerformancePage: Exception during getStatistics API call:", err)
    } finally {
      setStatisticsLoading(false)
      isFetchingStatisticsRef.current = false
      statisticsFetchedRef.current = strategyIdKey
      apiCallCache.isFetching.statistics = false
      apiCallCache.statistics.set(cacheKey, true)
    }
  }, [strategyId, token, isAuthenticated, ensureUserId])

  // Fetch related strategies from popular category
  const fetchRelatedStrategies = useCallback(async () => {
    if (!token || !isAuthenticated) {
      return
    }

    const strategyIdKey = strategyId ? String(strategyId) : 'no-strategy'
    const fetchKey = `related-${strategyIdKey}`
    const cacheKey = `related-${strategyIdKey}`
    
    // Prevent duplicate calls - check module-level cache first (works with StrictMode)
    if (apiCallCache.related.has(cacheKey) || apiCallCache.isFetching.related) {
      return
    }

    // Set fetching flag in both ref and cache
    isFetchingRelatedRef.current = true
    apiCallCache.isFetching.related = true
    setRelatedStrategiesLoading(true)
    
    try {
      const response = await strategyService.getReadyToDeployStrategies("popular")
      
      if (response.success && response.data) {
        const responseData = response.data as any
        let strategiesData: any[] = []
        
        // Extract strategies from nested structure
        if (responseData.strategies?.popular && Array.isArray(responseData.strategies.popular)) {
          strategiesData = responseData.strategies.popular
        } else if (responseData.data?.strategies?.popular && Array.isArray(responseData.data.strategies.popular)) {
          strategiesData = responseData.data.strategies.popular
        }
        
        // Transform and filter (exclude current strategy, limit to 3)
        const transformed = strategiesData
          .filter((s: any) => s.id !== strategyId && s.sid !== strategyId)
          .slice(0, 3)
          .map((strategy: any) => transformStrategyToCard(strategy))
        
        setRelatedStrategies(transformed)
        relatedStrategiesFetchedRef2.current = fetchKey
      }
    } catch (err) {
      console.error("❌ PerformancePage: Failed to fetch related strategies:", err)
    } finally {
      setRelatedStrategiesLoading(false)
      isFetchingRelatedRef.current = false
      relatedStrategiesFetchedRef2.current = fetchKey
      apiCallCache.isFetching.related = false
      apiCallCache.related.set(cacheKey, true)
    }
  }, [strategyId, token, isAuthenticated, transformStrategyToCard])

  // Scroll to top when strategyId changes or component mounts
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [strategyId])

  // Single function to load all data - called only once per strategyId
  // Removed from useCallback to prevent recreation - using refs for control
  const loadAllData = async () => {
    if (!strategyId || !token || !isAuthenticated) {
      if (!strategyId) setError("Strategy ID is required")
      else if (!token || !isAuthenticated) setError("Authentication required. Please login again.")
      setLoading(false)
      return
    }

    const strategyIdKey = String(strategyId)
    
    // Check if already fetched for this strategyId
    if (dataFetchedRef.current === strategyIdKey || isFetchingRef.current) {
      return
    }

    isFetchingRef.current = true
    
    try {
      // Ensure userId is available
      if (!useAuthStore.getState().userId) {
        await ensureUserId()
      }
      
      // Call all APIs once - sequentially
      // Each function has its own ref check, so safe to call
      await fetchStrategyDetails()
      await fetchStrategyReports()
      await fetchStatistics()
      
      // Fetch related strategies only if not already fetched
      const strategyIdKey2 = strategyId ? String(strategyId) : 'no-strategy'
      const fetchKey2 = `related-${strategyIdKey2}`
      if (relatedStrategiesFetchedRef2.current !== fetchKey2 && !isFetchingRelatedRef.current) {
        await fetchRelatedStrategies()
      }
      
      dataFetchedRef.current = strategyIdKey
    } catch (error) {
      logger.error("❌ PerformancePage: Error during data fetch:", error)
      dataFetchedRef.current = null
    } finally {
      isFetchingRef.current = false
    }
  }

  // Call APIs only once when strategyId/token/isAuthenticated are ready
  // No dependencies on callbacks to prevent re-runs
  useEffect(() => {
    const strategyIdKey = strategyId ? String(strategyId) : null
    
    // Reset when strategyId changes
    if (strategyIdKey && dataFetchedRef.current !== strategyIdKey) {
      dataFetchedRef.current = null
      relatedStrategiesFetchedRef.current = false
      isFetchingRef.current = false
      // Reset individual API refs when strategyId changes
      detailsFetchedRef.current = null
      reportsFetchedRef.current = null
      statisticsFetchedRef.current = null
      relatedStrategiesFetchedRef2.current = null
      isFetchingDetailsRef.current = false
      isFetchingReportsRef.current = false
      isFetchingStatisticsRef.current = false
      isFetchingRelatedRef.current = false
      
      // Clear module-level cache for this strategyId
      apiCallCache.details.delete(`details-${strategyIdKey}`)
      apiCallCache.reports.delete(`reports-${strategyIdKey}`)
      apiCallCache.statistics.delete(`statistics-${strategyIdKey}`)
      apiCallCache.related.delete(`related-${strategyIdKey}`)
    }
    
    // Load data once - only if not already fetched or fetching
    if (strategyId && token && isAuthenticated && !isFetchingRef.current && dataFetchedRef.current !== strategyIdKey) {
      loadAllData()
    }
  }, [strategyId, token, isAuthenticated]) // Only essential dependencies

  // Check if a strategy is deployed
  const isStrategyDeployed = useCallback((strategyId: number | null): boolean => {
    if (!strategyId) return false
    return activeStrategies.some((active) => active.sid === strategyId)
  }, [activeStrategies])

  // Calculate margin needed based on multiplier and strategy
  const calculateMarginNeeded = useCallback((mult: number): number => {
    if (!strategyDetails) return 0
    const baseMargin = strategyDetails.minCapital || strategyDetails.requiredCapital || strategyDetails.capital || 0
    return baseMargin * mult
  }, [strategyDetails])

  // Handle multiplier change
  const handleMultiplierChange = (delta: number) => {
    setMultiplier((prev) => {
      const newMultiplier = Math.max(0, Math.min(100, prev + delta))
      const newMargin = calculateMarginNeeded(newMultiplier)
      setMarginNeeded(newMargin)
      return newMultiplier
    })
  }

  // Update margin when multiplier or strategy changes - only when dialog is open
  // Use useMemo instead of useEffect for derived state
  const calculatedMargin = useMemo(() => {
    if (strategyDetails && deployDialogOpen) {
      return calculateMarginNeeded(multiplier)
    }
    return 0
  }, [multiplier, strategyDetails, deployDialogOpen, calculateMarginNeeded])
  
  // Update margin state only when calculated value changes
  useEffect(() => {
    if (deployDialogOpen) {
      setMarginNeeded(calculatedMargin)
    }
  }, [calculatedMargin, deployDialogOpen])

  // Check if strategy is from popular category and update state
  const checkPopularStrategy = useCallback(() => {
    // First check location state (passed from MyStrategyPage) - this is immediate
    const state = location.state as { strategyCategory?: string } | null
    if (state?.strategyCategory) {
      const category = String(state.strategyCategory).toLowerCase().trim()
      if (category === "popular") {
        console.log("✅ PerformancePage: Strategy is popular (from location state):", category)
        setIsPopular(true)
        return
      }
    }
    
    // Then check strategyDetails (from API response)
    if (strategyDetails) {
      // Check direct category field (most common)
      const category = String(strategyDetails?.category || "").toLowerCase().trim()
      if (category === "popular") {
        console.log("✅ PerformancePage: Strategy is popular (from strategyDetails.category):", category)
        setIsPopular(true)
        return
      }
      
      // Check alternative fields
      const strategyType = String(strategyDetails?.strategyType || "").toLowerCase().trim()
      if (strategyType === "popular") {
        console.log("✅ PerformancePage: Strategy is popular (from strategyDetails.strategyType):", strategyType)
        setIsPopular(true)
        return
      }
      
      // Check nested structures
      const nestedCategory = String((strategyDetails as any)?.strategyCategory || (strategyDetails as any)?.categoryName || (strategyDetails as any)?.type || "").toLowerCase().trim()
      if (nestedCategory === "popular") {
        console.log("✅ PerformancePage: Strategy is popular (from nested):", nestedCategory)
        setIsPopular(true)
        return
      }
    }
    
    console.log("❌ PerformancePage: Strategy is NOT popular. State category:", state?.strategyCategory, "Details category:", strategyDetails?.category, "Details strategyType:", strategyDetails?.strategyType)
    setIsPopular(false)
  }, [strategyDetails, location.state])

  // Update popular status when location state or strategy details change
  // Use useMemo to derive state instead of useEffect
  const isPopularDerived = useMemo(() => {
    // First check location state (passed from MyStrategyPage) - this is immediate
    const state = location.state as { strategyCategory?: string } | null
    if (state?.strategyCategory) {
      const category = String(state.strategyCategory).toLowerCase().trim()
      if (category === "popular") {
        return true
      }
    }
    
    // Then check strategyDetails (from API response)
    if (strategyDetails) {
      const category = String(strategyDetails?.category || "").toLowerCase().trim()
      if (category === "popular") {
        return true
      }
      
      const strategyType = String(strategyDetails?.strategyType || "").toLowerCase().trim()
      if (strategyType === "popular") {
        return true
      }
      
      const nestedCategory = String((strategyDetails as any)?.strategyCategory || (strategyDetails as any)?.categoryName || (strategyDetails as any)?.type || "").toLowerCase().trim()
      if (nestedCategory === "popular") {
        return true
      }
    }
    
    return false
  }, [strategyDetails, location.state])
  
  // Update state only when derived value changes
  useEffect(() => {
    setIsPopular(isPopularDerived)
  }, [isPopularDerived])

  // Fetch dropdowns when modal opens
  const fetchDropdowns = useCallback(async () => {
    setDropdownsLoading(true)
    try {
      const response = await diyService.getDropdowns()
      if (response.success && response.data) {
        setDropdowns(response.data as DropdownsResponse & { [key: string]: unknown })
        console.log("✅ PerformancePage: Dropdowns loaded:", response.data)
      } else {
        console.warn("⚠️ PerformancePage: Failed to fetch dropdowns:", response.error)
      }
    } catch (error) {
      console.error("❌ PerformancePage: Error fetching dropdowns:", error)
    } finally {
      setDropdownsLoading(false)
    }
  }, [])

  // Handle normal deploy button click (only multiplier and execution type)
  const handleNormalDeployClick = () => {
    setDeployMode('normal')
    setMultiplier(strategyDetails?.multiplier || 1)
    setExecutionTypeId(strategyDetails?.executionType || "LiveTrading")
    setDeployError(null)
    setDeployDialogOpen(true)
  }

  // Handle customize deploy button click (all fields)
  const handleCustomizeDeployClick = () => {
    setDeployMode('customize')
    // Reset all fields to defaults or strategy details values
    setMultiplier(strategyDetails?.multiplier || 1)
    setExecutionTypeId(strategyDetails?.executionType || "LiveTrading")
    setStrategyType(strategyDetails?.typeOfStrategy || strategyDetails?.positionType || "Intraday")
    setUnderlying(typeof strategyDetails?.underlying === 'number' ? strategyDetails.underlying : (typeof strategyDetails?.underlying === 'string' ? parseInt(strategyDetails.underlying) : 1))
    setExpiryType(strategyDetails?.entryDetails?.expiry || "CurrentWeek")
    setStrikeSelection(strategyDetails?.atmType || "SpotAtm")
    setPositionType(strategyDetails?.positionType || "OPTION")
    setEntryDays(strategyDetails?.entryDetails?.entryDaysList || [1, 2, 3, 4, 5])
    setExitAfterEntry(strategyDetails?.exitDetails?.exitAfterEntryDays || 3)
    setExitOnExpiry(strategyDetails?.exitDetails?.exitOnExpiryFlag === "Yes" ? "yes" : "no")
    setProfitMtm(strategyDetails?.exitDetails?.targetUnitType || "PercentOfCapital")
    setDeployError(null)
    setDeployDialogOpen(true)
    // Fetch dropdowns when customize modal opens
    fetchDropdowns()
  }

  // Handle deploy submission
  const handleDeploySubmit = async () => {
    if (!strategyId) return

    setDeployLoading(true)
    setDeployError(null)

    try {
      // Build request based on deploy mode
      let deployRequest: any = {
        strategyId: strategyId,
        multiplier: multiplier,
        executionTypeId: executionTypeId,
      }

      // Only include additional fields for customize deploy
      if (deployMode === 'customize') {
        deployRequest = {
          ...deployRequest,
          strategyType: strategyType,
          underlying: underlying,
          expiryType: expiryType,
          strikeSelection: strikeSelection,
          positionType: positionType,
          entryDays: entryDays,
          exitAfterEntry: exitAfterEntry,
          exitOnExpiry: exitOnExpiry,
          segmentType: segmentType,
          order: order,
          profitMtm: profitMtm,
          tgt: tgt,
          trl: trl,
        }
        console.log("📡 PerformancePage: Sending customize deploy request with all fields:", deployRequest)
      } else {
        console.log("📡 PerformancePage: Sending normal deploy request (multiplier + executionType only):", deployRequest)
      }
      
      const response = await strategyService.oneClickDeploy(deployRequest)

      if (response.success) {
        // Success - close dialog, refresh active strategies, and refresh strategy details
        setDeployDialogOpen(false)
        await refetchActiveStrategies() // Refresh active strategies
        await fetchStrategyDetails() // Refresh strategy details
        console.log("✅ Strategy deployed successfully:", response)
      } else {
        const errorMsg = response.error?.message || "Failed to deploy strategy"
        setDeployError(errorMsg)
      }
    } catch (err) {
      console.error("Error deploying strategy:", err)
      const errorMsg = err instanceof Error ? err.message : "An error occurred while deploying"
      setDeployError(errorMsg)
    } finally {
      setDeployLoading(false)
    }
  }

  // Handle undeploy click - show confirmation dialog
  const handleUndeployClick = () => {
    if (!strategyId) return
    const strategy = activeStrategies.find(s => s.sid === strategyId)
    const strategyName = strategy?.name || strategyDetails?.name || strategyReports?.strategyName || "Strategy"
    setPendingUndeployStrategy({ strategyId, strategyName })
    setUndeployDialogOpen(true)
  }

  // Handle undeploy confirmation
  const handleUndeployConfirm = async () => {
    if (!pendingUndeployStrategy) return
    
    setUndeployDialogOpen(false)
    setUndeployLoading(true)
    const { strategyId: id, strategyName: _strategyName } = pendingUndeployStrategy
    
    try {
      const response = await strategyService.undeployStrategy(id)
      if (response.success) {
        // Refresh active strategies and strategy details
        await refetchActiveStrategies()
        await fetchStrategyDetails()
        console.log("✅ Strategy undeployed successfully:", response)
      } else {
        console.error("❌ Failed to undeploy strategy:", response.error?.message)
      }
    } catch (err) {
      console.error("Error undeploying strategy:", err)
    } finally {
      setUndeployLoading(false)
      setPendingUndeployStrategy(null)
    }
  }

  // Cancel undeploy
  const handleUndeployCancel = () => {
    setUndeployDialogOpen(false)
    setPendingUndeployStrategy(null)
  }

  // Close deploy dialog
  const handleDeployDialogClose = (open: boolean) => {
    if (!deployLoading && !open) {
      setDeployDialogOpen(false)
      setDeployMode('normal') // Reset to normal mode when closing
      setDeployError(null)
    }
  }


  // Get strategy initials for icon
  const getStrategyInitials = (name: string): string => {
    const words = name.split(/\s+/)
    if (words.length >= 2) {
      return (words[0][0] + words[1][0]).toUpperCase()
    }
    return name.substring(0, 2).toUpperCase()
  }

  // Get underlying name
  const getUnderlyingName = (underlying: string | number | undefined): string => {
    const underlyingMap: Record<string | number, string> = {
      1: "Nifty", 
      2: "Bank Nifty", 
      3: "FinNifty", 
      4: "Sensex", 
      5: "Bankex",
    }
    return underlyingMap[underlying as string | number] || "Nifty"
  }

  // Generate tags from strategy details
  const generateStrategyTags = useCallback((): string[] => {
    const tags: string[] = []
    
    // Add underlying - check multiple possible fields
    const underlying = strategyDetails?.underlying || strategyDetails?.underlyingId || strategyDetails?.underlyingName
    if (underlying) {
      tags.push(getUnderlyingName(underlying))
    }
    
    // Add position type or duration (e.g., "Intraday")
    const positionType = strategyDetails?.positionType || strategyDetails?.duration || strategyDetails?.type
    if (positionType) {
      // Map common values
      const positionLower = String(positionType).toLowerCase()
      if (positionLower.includes("intraday")) {
        tags.push("Intraday")
      } else if (positionLower.includes("positional")) {
        tags.push("Positional")
      } else if (positionLower.includes("btst") || positionLower.includes("stbt")) {
        tags.push("BTST / STBT")
      } else {
        tags.push(String(positionType))
      }
    }
    
    // Add status if available (e.g., "Standby")
    const status = strategyDetails?.status || strategyDetails?.strategyStatus
    if (status) {
      const statusLower = String(status).toLowerCase()
      if (statusLower === "standby" || statusLower === "active" || statusLower === "running" || statusLower === "deployed") {
        tags.push("Standby")
      }
    }
    
    return tags
  }, [strategyDetails])


  // Memoize statistics data to prevent recalculation
  const displayStatisticsData = useMemo(() => statisticsData, [statisticsData])
  
  // Memoize strategy tags to prevent recalculation
  const strategyTags = useMemo(() => generateStrategyTags(), [generateStrategyTags])

  // Equity Curve Data - moved outside IIFE to follow Rules of Hooks
  const equityData = useMemo(() => {
    let data: any[] = []
    if (strategyReports?.reportsSignalDTOs && Array.isArray(strategyReports.reportsSignalDTOs) && strategyReports.reportsSignalDTOs.length > 0) {
      // Reverse to show chronological order (oldest to newest) for proper equity curve progression
      data = [...strategyReports.reportsSignalDTOs].reverse().map((signal: any) => ({
        date: signal.date || "N/A",
        value: signal.sequentialPNL || 0, // sequentialPNL from API represents cumulative P&L (equity value)
      }))
      
      console.log("📊 PerformancePage: Equity curve data prepared:", data.length, "points")
    } else {
      console.log("⚠️ PerformancePage: No equity curve data available from API")
    }
    return data
  }, [strategyReports])

  // Format currency helper - memoized to prevent recreation
  const formatCurrency = useCallback((value: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }, [])

  // Format date helper - memoized to prevent recreation
  const formatDate = useCallback((dateStr: string) => {
    try {
      const date = new Date(dateStr)
      return date.toLocaleDateString("en-IN", { 
        day: "numeric", 
        month: "short", 
        year: "numeric" 
      })
    } catch {
      return dateStr
    }
  }, [])

  // Generate unique gradient IDs to prevent conflicts
  const gradientId = useMemo(() => `equityGradient-${strategyId || 'default'}`, [strategyId])
  const gradientHoverId = useMemo(() => `equityGradientHover-${strategyId || 'default'}`, [strategyId])

  // Equity Curve Chart Component - defined outside IIFE to follow Rules of Hooks
  const EquityCurveChartComponent = React.memo(({ 
    equityData, 
    formatCurrency, 
    formatDate, 
    gradientId, 
    gradientHoverId 
  }: { 
    equityData: any[]
    formatCurrency: (value: number) => string
    formatDate: (dateStr: string) => string
    gradientId: string
    gradientHoverId: string
  }) => {
      const chartContainerRef = useRef<HTMLDivElement>(null)
      const [tooltip, setTooltip] = useState<{
        x: number
        y: number
        date: string
        value: number
        index: number
      } | null>(null)
      const [isHovering, setIsHovering] = useState(false)
      const [containerHeight, setContainerHeight] = useState(400)

      const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        if (!chartContainerRef.current || equityData.length === 0) return

        const rect = chartContainerRef.current.getBoundingClientRect()
        const x = e.clientX - rect.left
        const y = e.clientY - rect.top

        // Chart area bounds (accounting for margins)
        const chartMargin = { top: 10, right: 20, left: 10, bottom: 20 }
        const chartWidth = rect.width - chartMargin.left - chartMargin.right
        const chartHeight = rect.height - chartMargin.top - chartMargin.bottom

        // Check if mouse is within chart area
        if (
          x >= chartMargin.left &&
          x <= rect.width - chartMargin.right &&
          y >= chartMargin.top &&
          y <= rect.height - chartMargin.bottom
        ) {
          // Calculate which data point is closest based on x position
          const relativeX = x - chartMargin.left
          const dataIndex = Math.round(
            (relativeX / chartWidth) * (equityData.length - 1)
          )
          const clampedIndex = Math.max(0, Math.min(dataIndex, equityData.length - 1))
          const dataPoint = equityData[clampedIndex]

          if (dataPoint) {
            // Calculate y position on the line
            const minValue = Math.min(...equityData.map(d => d.value))
            const maxValue = Math.max(...equityData.map(d => d.value))
            const valueRange = maxValue - minValue || 1
            const relativeValue = (dataPoint.value - minValue) / valueRange
            const chartY = chartMargin.top + chartHeight - (relativeValue * chartHeight)

            setTooltip({
              x: x,
              y: chartY,
              date: dataPoint.date,
              value: dataPoint.value,
              index: clampedIndex,
            })
            setIsHovering(true)
          }
        } else {
          setTooltip(null)
          setIsHovering(false)
        }
      }, [equityData])

      const handleMouseLeave = useCallback(() => {
        setTooltip(null)
        setIsHovering(false)
      }, [])

      useEffect(() => {
        if (chartContainerRef.current) {
          setContainerHeight(chartContainerRef.current.clientHeight)
        }
      }, [])

      return (
        <div
          ref={chartContainerRef}
          className="relative w-full h-full"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
        >
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart 
                data={equityData} 
                margin={{ top: 10, right: 20, left: 10, bottom: 20 }}
              >
                <defs>
                  <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#5266FC" stopOpacity={0.25} />
                    <stop offset="100%" stopColor="#5266FC" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id={gradientHoverId} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#5266FC" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="#5266FC" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid 
                  strokeDasharray="3 3" 
                  stroke="#d1d5db" 
                  strokeOpacity={0.8}
                  vertical={false}
                  className="dark:stroke-gray-600"
                />
                <XAxis
                  dataKey="date"
                  axisLine={{ stroke: "#e5e7eb", strokeWidth: 1 }}
                  tickLine={false}
                  tick={{ fill: "#6b7280", fontSize: 11, fontWeight: 500 }}
                  className="dark:text-gray-400 dark:[&_line]:stroke-gray-700"
                  dy={10}
                  tickFormatter={(value) => {
                    try {
                      const date = new Date(value)
                      return date.toLocaleDateString("en-IN", { day: "numeric", month: "short" })
                    } catch {
                      return value
                    }
                  }}
                />
                <YAxis
                  axisLine={{ stroke: "#e5e7eb", strokeWidth: 1 }}
                  tickLine={false}
                  tick={{ fill: "#6b7280", fontSize: 11, fontWeight: 500 }}
                  className="dark:text-gray-400 dark:[&_line]:stroke-gray-700"
                  tickFormatter={(value) => {
                    if (Math.abs(value) >= 100000) return `₹${(value / 100000).toFixed(1)}L`
                    if (Math.abs(value) >= 1000) return `₹${(value / 1000).toFixed(0)}K`
                    return `₹${value}`
                  }}
                  dx={-5}
                  domain={["dataMin - 5000", "dataMax + 5000"]}
                />
                <RechartsTooltip 
                content={() => null}
                cursor={false}
                />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#5266FC"
                  strokeWidth={2.5} 
                  fill={isHovering ? `url(#${gradientHoverId})` : `url(#${gradientId})`}
                  dot={false}
                  activeDot={false}
                  style={{ transition: "all 0.2s ease" }}
                />
              </AreaChart>
            </ResponsiveContainer>

          {/* Overlay for visual indicators */}
          {tooltip && (
            <>
              {/* Vertical line indicator */}
              <svg
                className="absolute pointer-events-none z-10"
                style={{
                  left: 0,
                  top: 0,
                  width: '100%',
                  height: '100%',
                }}
              >
                <line
                  x1={tooltip.x}
                  y1={10}
                  x2={tooltip.x}
                  y2={containerHeight - 20}
                  stroke="#5266FC"
                  strokeWidth={1.5}
                  strokeDasharray="4 4"
                  opacity={0.6}
                />
              </svg>
              
              {/* Data point indicator */}
              <div
                className="absolute pointer-events-none z-20"
                style={{
                  left: `${tooltip.x}px`,
                  top: `${tooltip.y}px`,
                  transform: "translate(-50%, -50%)",
                }}
              >
                <div 
                  className="rounded-full border-2 border-white dark:border-gray-800 shadow-lg"
                  style={{
                    width: '10px',
                    height: '10px',
                    backgroundColor: '#5266FC',
                  }}
                />
          </div>

              {/* Custom Tooltip that follows mouse */}
              <div
                className="absolute pointer-events-none z-30 transition-all duration-150 ease-out"
                style={{
                  left: `${Math.max(100, Math.min(tooltip.x, (chartContainerRef.current?.clientWidth || 800) - 100))}px`,
                  top: `${Math.max(10, Math.min(tooltip.y - 100, (containerHeight || 400) - 150))}px`,
                  transform: "translateX(-50%)",
                }}
              >
                <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded shadow-md px-2 py-1.5 whitespace-nowrap backdrop-blur-sm">
                  <div className="flex flex-col gap-0.5">
                    <p className="text-[9px] text-gray-500 dark:text-gray-400 font-medium">
                      {formatDate(tooltip.date)}
                    </p>
                    <p className="text-xs font-bold text-blue-600 dark:text-blue-400">
                      {formatCurrency(tooltip.value)}
                    </p>
                  </div>
                  {/* Tooltip arrow */}
                  <div 
                    className="absolute left-1/2 -bottom-1 transform -translate-x-1/2 w-1 h-1 bg-white dark:bg-gray-900 border-r border-b border-gray-200 dark:border-gray-700 rotate-45"
                    style={{ marginBottom: '-2px' }}
                  />
                </div>
              </div>
            </>
          )}
        </div>
      )
  })

  // Removed defaultOrdersData - using only real API data

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _algoCards = [
    {
      title: "NF-Delta Neutral",
      tags: ["Nifty", "Hedged", "Directional"],
      description:
        "A strategy involving selling both a call and a put option at put option at A strategy involving selling both a call.",
      minCapital: "₹80,000",
      avgReturn: "Backtest",
      riskLevel: "Medium",
    },
    {
      title: "NF-Delta Neutral",
      tags: ["Nifty", "Hedged", "Directional"],
      description:
        "A strategy involving selling both a call and a put option at put option at A strategy involving selling both a call.",
      minCapital: "₹80,000",
      avgReturn: "Backtest",
      riskLevel: "Medium",
    },
    {
      title: "NF-Delta Neutral",
      tags: ["Nifty", "Hedged", "Directional"],
      description:
        "A strategy involving selling both a call and a put option at put option at A strategy involving selling both a call.",
      minCapital: "₹80,000",
      avgReturn: "Backtest",
      riskLevel: "Medium",
    },
  ]

  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const [activeTestimonialIndex, setActiveTestimonialIndex] = useState(0)
  
  const testimonials = [
    {
      id: 1,
      rating: 4,
      text: "I have used so many Algo platforms, but Bigul's is the best interface and smoothest quality, I have seen.",
      name: "Sagar Sharma, Delhi",
      date: "May 8, 2025",
    },
    {
      id: 2,
      rating: 5,
      text: "I forward tested this for 2 weeks and made ₹18K virtual profit. Now running live for 1 month — up ₹34K real money!",
      name: "Anant G, Mumbai",
      date: "Jun 12, 2025",
    },
    {
      id: 3,
      rating: 4,
      text: "I have been on Biguls Algo platform since last 3 months and has been a hassle free journey so far. Thank you.",
      name: "Aditya N, Indore",
      date: "May 5, 2025",
    },
  ]

  // Scroll to specific testimonial index
  const scrollToTestimonial = (index: number) => {
    if (scrollContainerRef.current) {
      const cardWidth = 280 // Base card width + gap
      const scrollPosition = index * cardWidth
      scrollContainerRef.current.scrollTo({
        left: scrollPosition,
        behavior: "smooth",
      })
      setActiveTestimonialIndex(index)
    }
  }

  // Update active testimonial index based on scroll position
  useEffect(() => {
    const container = scrollContainerRef.current
    if (!container) return

    const handleScroll = () => {
      const cardWidth = 280 // Base card width + gap
      const scrollLeft = container.scrollLeft
      const newIndex = Math.round(scrollLeft / cardWidth)
      setActiveTestimonialIndex(Math.min(newIndex, testimonials.length - 1))
    }

    container.addEventListener('scroll', handleScroll)
    return () => container.removeEventListener('scroll', handleScroll)
  }, [testimonials.length])

  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating)
    const totalStars = 5

    return (
      <div className="flex flex-row justify-start items-center gap-0.5">
        {[...Array(totalStars)].map((_, index) => (
          <Star
            key={index}
            className={`w-4 h-4 ${
              index < fullStars
                ? "fill-amber-400 text-amber-400"
                : "fill-none text-gray-300 stroke-gray-300"
            }`}
          />
        ))}
      </div>
    )
  }

  const getTagStyle = (_tag: string) => {
    // All tags (Nifty, Intraday, Live Trading, Available, etc.) use the same blue color - matching DiscoverStrategy
    return "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400"
  }

  return (
    <div className="min-h-screen bg-[#F5F5F5] dark:bg-gray-950">
      <Header />
      <div className="pt-16 pb-8">
        <div className="max-w-[1600px] mx-auto px-8 sm:px-12 lg:px-28">
        {/* Breadcrumb */}
        <div className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400 mb-2.5">
          <Link to="/" className="hover:text-gray-700 dark:hover:text-gray-300 transition-colors">Dashboard</Link>
          <ChevronRight className="w-3 h-3" />
          <Link to={sourcePageLink} className="hover:text-gray-700 dark:hover:text-gray-300 transition-colors">{sourcePage}</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-blue-500 dark:text-blue-400">
            {loading ? "Loading..." : 
              strategyDetails?.name
                ? strategyDetails.name
                : strategyReports?.strategyName
                  ? strategyReports.strategyName
                  : strategyId
                    ? `Strategy (${strategyId})`
                    : "Strategy"}
          </span>
        </div>

        {/* Main Content Section with White Background */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-3 mb-3">
          {/* Title Section */}
          <div className="flex items-center justify-between gap-2 mb-1.5 flex-wrap">
            <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">
              {loading ? "Loading..." : 
                (() => {
                  const state = location.state as { strategyTitle?: string } | null
                  if (state?.strategyTitle) {
                    return `${state.strategyTitle} (${strategyId})`
                  }
                  if (strategyDetails?.name) {
                    return `${strategyDetails.name} (${strategyId})`
                  }
                  if (strategyReports?.strategyName) {
                    return `${strategyReports.strategyName} (${strategyId})`
                  }
                  return `Strategy (${strategyId})`
                })()}
            </h1>
            </div>
            {/* Deploy/Undeploy Button */}
            {strategyId && (
              <div className="flex-shrink-0 flex items-center gap-2">
                {loading ? (
                  <div className="px-3 py-1.5 flex items-center justify-center gap-1.5 text-xs text-gray-500 dark:text-gray-400">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Loading...</span>
                  </div>
                ) : (
                  <>
                    {/* Show Undeploy if deployed, Deploy buttons if not deployed */}
                    {isStrategyDeployed(strategyId) ? (
                      <>
                        {/* Customize Deploy - Show even when deployed (ONLY for popular strategies) - LEFT */}
                        {isPopular && (
                          <button 
                            onClick={handleCustomizeDeployClick}
                            className="px-3 py-1.5 bg-white dark:bg-gray-800 border border-[#5266FC] dark:border-blue-500 text-[#5266FC] dark:text-blue-400 rounded-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-opacity flex items-center justify-center gap-1.5 text-xs"
                            title="Customize Deploy Options"
                          >
                            <Settings className="w-3.5 h-3.5" />
                            <span>Customize</span>
                          </button>
                        )}
                        
                        {/* Undeploy button - always show when deployed - RIGHT */}
                        <button 
                          onClick={handleUndeployClick}
                          disabled={undeployLoading}
                          className="px-3 py-1.5 bg-red-500 dark:bg-red-600 text-white rounded-sm hover:opacity-90 transition-opacity flex items-center justify-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed text-xs"
                          title="Undeploy Strategy"
                        >
                          {undeployLoading ? (
                            <>
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              <span>Undeploying...</span>
                            </> 
                          ) : (
                            <>
                              <ArrowUpRight className="w-3.5 h-3.5 rotate-180" />
                              <span>Undeploy</span>
                            </>
                          )}
                        </button>
                      </>
                    ) : (
                      <>
                        {/* Normal Deploy - Only multiplier and execution type (for all strategies) */}
                        <button 
                          onClick={handleNormalDeployClick}
                          className="px-3 py-1.5 bg-gradient-to-br from-[#5367fc] via-[#4d6ff7] to-[#00e8b0] text-white rounded-sm hover:opacity-90 transition-opacity flex items-center justify-center gap-1.5 text-xs"
                          title="Deploy Strategy"
                        >
                          <ArrowUpRight className="w-3.5 h-3.5" />
                          <span>Deploy</span>
                        </button>
                        
                        {/* Customize Deploy - All fields (ONLY for popular strategies) */}
                        {isPopular && (
                          <button 
                            onClick={handleCustomizeDeployClick}
                            className="px-3 py-1.5 bg-white dark:bg-gray-800 border border-[#5266FC] dark:border-blue-500 text-[#5266FC] dark:text-blue-400 rounded-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-opacity flex items-center justify-center gap-1.5 text-xs"
                            title="Customize Deploy Options"
                          >
                            <Settings className="w-3.5 h-3.5" />
                            <span>Customize</span>
                          </button>
                        )}
                      </>
                    )}
                  </>
                )}
              </div>
            )}
          </div>

          {/* Category, Tags, and Average Return */}
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 px-1.5 py-0.5 rounded text-[10px] font-medium">
              {strategyDetails?.category || strategyDetails?.strategyType || "Inhouse"}
            </span>
            {/* Tags */}
            {!loading && strategyDetails && (
              <div className="flex items-center gap-2 flex-wrap">
                {generateStrategyTags().map((tag, index) => (
                  <span 
                    key={index} 
                    className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${getTagStyle(tag)}`}
                  >
                    {tag}
            </span>
                ))}
              </div>
            )}
          </div>

          {/* Description */}
          <div className="text-gray-600 dark:text-gray-300 text-xs leading-relaxed mb-4">
            {loading ? (
              <div className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-[#5266FC]" />
                <span>Loading strategy details...</span>
              </div>
            ) : error ? (
              <span className="text-red-500">{error}</span>
            ) : (() => {
              const state = location.state as { strategyDescription?: string } | null
              const passedDescription = state?.strategyDescription
              const apiDescription = strategyDetails?.description
              return passedDescription || apiDescription || "Strategy performance details and analytics."
            })()}
          </div>

          {/* Capital Stats */}
          <div className="flex gap-6 mb-4">
            <div>
              <p className="text-gray-500 dark:text-gray-400 text-xs">Minimum Amount</p>
              <p className="text-base font-semibold text-gray-900 dark:text-gray-100">
                {loading ? "..." : strategyDetails?.minCapital 
                  ? `₹${typeof strategyDetails.minCapital === 'number' 
                      ? (strategyDetails.minCapital / 100000).toFixed(2) + "L"
                      : strategyDetails.minCapital}`
                  : strategyDetails?.requiredCapital
                    ? `₹${typeof strategyDetails.requiredCapital === 'number'
                        ? (strategyDetails.requiredCapital / 100000).toFixed(2) + "L"
                        : strategyDetails.requiredCapital}`
                    : statisticsData.find(s => s.name === "Capital Required")?.value 
                      ? `₹${statisticsData.find(s => s.name === "Capital Required")?.value}`
                      : "₹0"}
              </p>
            </div>
            <div className="border-l border-gray-200 dark:border-gray-700 pl-6">
              <p className="text-gray-500 dark:text-gray-400 text-xs">Capital Deployed</p>
              <p className="text-base font-semibold text-gray-900 dark:text-gray-100">
                {loading ? "..." : strategyDetails?.capital 
                  ? `₹${typeof strategyDetails.capital === 'number' 
                      ? (strategyDetails.capital / 100000).toFixed(2) + "L"
                      : strategyDetails.capital}`
                  : strategyDetails?.requiredCapital
                    ? `₹${typeof strategyDetails.requiredCapital === 'number'
                        ? (strategyDetails.requiredCapital / 100000).toFixed(2) + "L"
                        : strategyDetails.requiredCapital}`
                    : statisticsData.find(s => s.name === "Capital Required")?.value 
                      ? `₹${statisticsData.find(s => s.name === "Capital Required")?.value}`
                      : "₹0"}
              </p>
            </div>
          </div>

          {/* Tabs */}
          <div className="border-b border-gray-200 dark:border-gray-700 mb-4">
            <div className="flex gap-8">
              {["Performance", /* "Payoff Chart", */ "Orders"].map((tab) => {
                const tabValue = tab.toLowerCase().replace(" ", "-")
                return (
                  <button
                    key={tab}
                    onClick={() => {
                      setActiveTab(tabValue)
                      // Update URL to preserve tab state
                      const newSearchParams = new URLSearchParams(searchParams)
                      newSearchParams.set("tab", tabValue)
                      setSearchParams(newSearchParams, { replace: true })
                    }}
                    className={`pb-2 text-xs font-medium border-b-2 transition-colors ${
                      activeTab === tabValue
                        ? "border-blue-500 text-blue-500"
                        : "border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 dark:bg-gray-800"
                    }`}
                  >
                    {tab}
                  </button>
                )
              })}
            </div>
          </div>

          {/* Chart Section - Conditional Rendering */}
          {/* Payoff Chart tab commented out for now */}
          {/* {activeTab === "payoff-chart" ? (
            <div className="mb-4 w-full overflow-hidden">
              <PayoffChart 
                strategyDetails={strategyDetails}
                strategyLegs={strategyDetails?.strategyLegTableDTO?.data || strategyDetails?.strategyLegs}
                strategyReports={strategyReports}
                currentPrice={strategyDetails?.indexCurrentPrice || strategyDetails?.currentPrice}
                basePrice={strategyDetails?.indexBasePrice || strategyDetails?.basePrice}
              />
            </div>
          ) : */}
          {activeTab === "performance" ? (
            <div className="rounded-lg p-4 mb-4">
          {/* Time Period Buttons - Only show if data is available */}
          {(() => {
            const avgMonthlyROI = statisticsData.find(s => s.name === "Avg Monthly ROI")?.value
            const totalROI = statisticsData.find(s => s.name === "Total ROI")?.value
            const maxProfit = statisticsData.find(s => s.name === "Max Profit In Day")?.value
            const maxLoss = statisticsData.find(s => s.name === "Max Loss In Day")?.value
            
            const hasAnyData = !statisticsLoading && (avgMonthlyROI || totalROI || maxProfit || maxLoss)
            
            if (!hasAnyData) return null
            
            return (
              <div className="flex gap-6 mb-4">
                {avgMonthlyROI && (
                  <div className="text-center">
                    <p className="text-xs text-gray-500 dark:text-gray-400">1M</p>
                    <p className={`text-xs font-medium ${
                      parseFloat(avgMonthlyROI || "0") >= 0 ? "text-green-500" : "text-red-500"
                    }`}>
                      {avgMonthlyROI}%
                    </p>
                  </div>
                )}
                {totalROI && (
                  <div className="text-center">
                    <p className="text-xs text-gray-500 dark:text-gray-400">Total ROI</p>
                    <p className={`text-xs font-medium ${
                      parseFloat(totalROI || "0") >= 0 ? "text-green-500" : "text-red-500"
                    }`}>
                      {totalROI}%
                    </p>
                  </div>
                )}
                {maxProfit && (
                  <div className="text-center">
                    <p className="text-xs text-gray-500 dark:text-gray-400">Max Profit</p>
                    <p className={`text-xs font-medium ${
                      parseFloat(maxProfit || "0") >= 0 ? "text-green-500" : "text-red-500"
                    }`}>
                      ₹{parseFloat(maxProfit || "0").toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                  </div>
                )}
                {maxLoss && (
                  <div className="text-center">
                    <p className="text-xs text-gray-500 dark:text-gray-400">Max Loss</p>
                    <p className="text-xs font-medium text-red-500">
                      ₹{parseFloat(maxLoss || "0").toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                  </div>
                )}
              </div>
            )
          })()}

          {/* Equity Curve Chart - Data from getStrategyReports API */}
          {(() => {
            // Data source: getStrategyReports API response
            // API endpoint: POST /ql/reports/strategyreports
            // Response structure: { data: { reportsSignalDTOs: [{ date, sequentialPNL, pnl, ... }] } }
            // The fetchStrategyReports function calls this API and stores result in strategyReports state
            
            const hasChartData = equityData.length > 0

            // Show spinner while loading reports or if reports haven't been loaded yet
            if (reportsLoading || (strategyReports === null && !statisticsLoading)) {
              return (
                <div className="border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 p-4">
                  <div className="h-[350px] flex items-center justify-center">
                    <div className="flex items-center gap-2 text-gray-500 dark:text-gray-400">
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span className="text-sm">Loading equity curve...</span>
                    </div>
                  </div>
                </div>
              )
            }

            // Only show "no data" message if reports have been loaded but have no data
            if (!hasChartData && strategyReports !== null) {
              return (
                <div className="border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 p-4">
                  <div className="h-[350px] flex items-center justify-center">
                    <div className="text-center">
                      <TrendingUp className="w-16 h-16 mx-auto text-gray-400 dark:text-gray-500 mb-4 opacity-50" />
                      <p className="text-gray-500 dark:text-gray-400 text-sm font-medium">Equity Curve Data Not Available</p>
                      <p className="text-gray-400 dark:text-gray-500 text-xs mt-1">Performance data will be available once the strategy has trading history</p>
                    </div>
                  </div>
                </div>
              )
            }

            // Calculate metrics
            const startValue = equityData[0]?.value || 0
            const endValue = equityData[equityData.length - 1]?.value || 0
            const totalReturn = startValue !== 0 ? ((endValue - startValue) / Math.abs(startValue)) * 100 : 0
            const isPositive = totalReturn >= 0

            return (
              <div className="border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
                {/* Header */}
                <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-gray-50 to-white dark:from-gray-900/50 dark:to-gray-800">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
                        <TrendingUp className={`w-5 h-5 ${isPositive ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`} />
                        Equity Curve
                      </h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 font-medium">Cumulative Performance Over Time</p>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="text-right">
                        <p className="text-xs text-gray-500 dark:text-gray-400 font-medium uppercase tracking-wide">Total Returns</p>
                        <p className={`text-base font-bold mt-0.5 ${isPositive ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                          {isPositive ? '+' : ''}{totalReturn.toFixed(2)}%
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-500 dark:text-gray-400 font-medium uppercase tracking-wide">Current Value</p>
                        <p className="text-base font-bold text-gray-900 dark:text-gray-100 mt-0.5">{formatCurrency(endValue)}</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Chart */}
                <div className="p-6 bg-gray-50/50 dark:bg-gray-900/30">
                  <div className="h-[400px] w-full">
                    <EquityCurveChartComponent 
                      equityData={equityData}
                      formatCurrency={formatCurrency}
                      formatDate={formatDate}
                      gradientId={gradientId}
                      gradientHoverId={gradientHoverId}
                    />
                  </div>
                </div>
              </div>
            )
          })()}

          <div className="flex items-center gap-1.5 text-orange-500 dark:text-orange-400 text-xs mt-3">
            <Info className="w-3.5 h-3.5" />
            <span>Backtesting results are based on past data. Historical data does not guarantee future results.</span>
          </div>
          </div>
        ) : (
          <div className="rounded-lg p-4 mb-4">
            <div className="overflow-x-auto -mx-4 px-4">
              <div className="inline-block min-w-full align-middle">
                <div className="overflow-hidden border border-gray-100 dark:border-gray-700">
                  <table className="w-full min-w-[800px]">
                <thead className="bg-[#EAE8FF] dark:bg-gray-700">
                  <tr>
                    <th className="text-center py-2 px-3 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Leg_Id</th>
                    <th className="text-center py-2 px-3 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Traded_Instrument</th>
                    <th className="text-center py-2 px-3 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">LTP</th>
                    <th className="text-center py-2 px-3 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Traded_Lots</th>
                    <th className="text-center py-2 px-3 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Entry_Price</th>
                    <th className="text-center py-2 px-3 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Exit_Price</th>
                    <th className="text-center py-2 px-3 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Entry_Time</th>
                    <th className="text-center py-2 px-3 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Exit_Time</th>
                    <th className="text-center py-2 px-3 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">P&L</th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800">
                  {paginatedOrdersData.length > 0 ? (
                    paginatedOrdersData.map((row, index) => (
                    <tr
                      key={index}
                      className="border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 last:border-b-0 hover:bg-gray-50 dark:hover:bg-gray-700/50"
                    >
                      <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300 text-center">{row.legId}</td>
                      <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300 text-center">{row.tradedInstrument}</td>
                      <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300 text-center">{row.ltp}</td>
                      <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300 text-center">{row.tradedLots}</td>
                      <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300 text-center">{row.entryPrice}</td>
                      <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300 text-center">{row.exitPrice}</td>
                      <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300 text-center">{row.entryTime}</td>
                      <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300 text-center">{row.exitTime}</td>
                      <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300 text-center">{row.pnl}</td>
                    </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={9} className="py-6 px-3 text-center text-gray-500 dark:text-gray-400">
                        <div className="flex flex-col items-center justify-center">
                          <p className="text-xs font-medium">No orders data available</p>
                          <p className="text-[10px] mt-0.5">Orders will appear here once the strategy has trading activity</p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
                  </table>
                </div>
              </div>
            </div>
            
            {/* Pagination for Orders */}
            {ordersData.length > ordersPerPage && (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mt-4 mb-8 px-4 py-4 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
                {/* Page info */}
                <div className="text-xs text-gray-600 dark:text-gray-400 whitespace-nowrap">
                  Showing {ordersStartIndex + 1} to {Math.min(ordersEndIndex, ordersData.length)} of {ordersData.length} entries
                </div>

                {/* Pagination controls */}
                <div className="flex items-center gap-2 flex-wrap justify-center">
                  <button 
                    onClick={() => setOrdersCurrentPage(Math.max(1, ordersCurrentPage - 1))}
                    disabled={ordersCurrentPage === 1}
                    className="px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-white dark:disabled:hover:bg-gray-800"
                  >
                    Previous
                  </button>
                  
                  {/* Page numbers */}
                  <div className="flex items-center gap-1">
                    {Array.from({ length: Math.min(ordersTotalPages, 5) }, (_, i) => {
                      let pageNum
                      if (ordersTotalPages <= 5) {
                        pageNum = i + 1
                      } else if (ordersCurrentPage <= 3) {
                        pageNum = i + 1
                      } else if (ordersCurrentPage >= ordersTotalPages - 2) {
                        pageNum = ordersTotalPages - 4 + i
                      } else {
                        pageNum = ordersCurrentPage - 2 + i
                      }
                      
                      return (
                        <button
                          key={pageNum}
                          onClick={() => setOrdersCurrentPage(pageNum)}
                          className={`w-8 h-8 text-xs font-medium rounded-md transition ${
                            ordersCurrentPage === pageNum 
                              ? "bg-blue-600 dark:bg-blue-500 text-white" 
                              : "text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700"
                          }`}
                        >
                          {pageNum}
                        </button>
                      )
                    })}
                  </div>
                  
                  <button 
                    onClick={() => setOrdersCurrentPage(Math.min(ordersTotalPages, ordersCurrentPage + 1))}
                    disabled={ordersCurrentPage >= ordersTotalPages}
                    className="px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-white dark:disabled:hover:bg-gray-800"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
        </div>

        {/* Performance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
          {/* Performance Overview */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-3 border border-gray-100 dark:border-gray-700">
            <h3 className="text-xs font-semibold text-gray-900 dark:text-gray-100 mb-2">Performance Overview</h3>
            <div className="flex justify-between items-start pb-2 border-b border-gray-200 dark:border-gray-700">
              <div>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Win Ratio</p>
                <p className="text-lg font-bold text-blue-500 dark:text-blue-400">
                  {statisticsLoading ? "..." : 
                    statisticsData.find(s => s.name === "Win Rate")?.value 
                      ? `${statisticsData.find(s => s.name === "Win Rate")?.value}%`
                      : "0%"}
                </p>
              </div>
              <img src="/images/chart1.png" alt="Performance Chart" className="w-20 h-10 object-contain" />
            </div>
            <div className="flex justify-between mt-2">
              <div>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Win Days</p>
                <p className="text-xs font-semibold text-gray-900 dark:text-gray-100">
                  {statisticsLoading ? "..." : 
                    statisticsData.find(s => s.name === "Win Days")?.value || "0"}
                </p>
              </div>
              <div>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Loss Days</p>
                <p className="text-xs font-semibold text-gray-900 dark:text-gray-100">
                  {statisticsLoading ? "..." : 
                    statisticsData.find(s => s.name === "Loss Days")?.value || "0"}
                </p>
              </div>
            </div>
          </div>

          {/* Profit Statistics */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-3 border border-gray-100 dark:border-gray-700">
            <h3 className="text-xs font-semibold text-gray-900 dark:text-gray-100 mb-2">Profit Statistics</h3>
            <div className="flex justify-between items-start pb-2 border-b border-gray-200 dark:border-gray-700">
              <div>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Total Profit</p>
                <p className="text-lg font-bold text-green-500 dark:text-green-400">
                  {statisticsLoading ? "..." : 
                    statisticsData.find(s => s.name === "Total Profit")?.value 
                      ? `₹${parseFloat(statisticsData.find(s => s.name === "Total Profit")?.value || "0").toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                      : "₹0.00"}
                </p>
              </div>
              <img src="/images/chart2.png" alt="Profit Chart" className="w-24 h-12 object-contain" />
            </div>
            <div className="flex justify-between mt-3">
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400">Monthly Average</p>
                <p className="text-xs font-semibold text-gray-900 dark:text-gray-100">
                  {statisticsLoading ? "..." : 
                    statisticsData.find(s => s.name === "Avg Monthly Profit")?.value 
                      ? `₹${parseFloat(statisticsData.find(s => s.name === "Avg Monthly Profit")?.value || "0").toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                      : "₹0.00"}
                </p>
              </div>
              <div>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Total ROI</p>
                <p className="text-xs font-semibold text-gray-900 dark:text-gray-100">
                  {statisticsLoading ? "..." : 
                    strategyDetails?.roi 
                      ? `${strategyDetails.roi}%`
                      : statisticsData.find(s => s.name === "Win Rate")?.value
                        ? `${statisticsData.find(s => s.name === "Win Rate")?.value}`
                        : "0%"}
                </p>
              </div>
            </div>
          </div>

          {/* Risk Metrics */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-3 border border-gray-100 dark:border-gray-700">
            <h3 className="text-xs font-semibold text-gray-900 dark:text-gray-100 mb-2">Risk Metrics</h3>
            <div className="flex justify-between items-start pb-2 border-b border-gray-200 dark:border-gray-700">
              <div>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Max Drawdown</p>
                <p className="text-lg font-bold text-red-500 dark:text-red-400">
                  {statisticsLoading ? "..." : 
                    fullStatisticsData?.riskMetrics?.maxDrawDown 
                      ? `₹${parseFloat(fullStatisticsData.riskMetrics.maxDrawDown || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                      : statisticsData.find(s => s.name === "Max Drawdown")?.value
                        ? `₹${parseFloat(statisticsData.find(s => s.name === "Max Drawdown")?.value || "0").toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                        : "₹0.00"}
                </p>
              </div>
              <img src="/images/chart3.png" alt="Risk Chart" className="w-24 h-12 object-contain" />
            </div>
            <div className="flex justify-between mt-3">
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400">Total Trading Days</p>
                <p className="text-xs font-semibold text-gray-900 dark:text-gray-100">
                  {statisticsLoading ? "..." : 
                    statisticsData.find(s => s.name === "Total Trading Days")?.value || "0"}
                </p>
              </div>
              <div>
                <p className="text-[10px] text-gray-500 dark:text-gray-400">Max Losing Streak</p>
                <p className="text-xs font-semibold text-gray-900 dark:text-gray-100">
                  {statisticsLoading ? "..." : 
                    statisticsData.find(s => s.name === "Max Losing Streak Days")?.value || "0"} days
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Statistics */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100">Detailed Statistics</h2>
          </div>

          {statisticsLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-5 h-5 animate-spin text-[#5266FC] dark:text-blue-400" />
              <span className="ml-2 text-gray-500 dark:text-gray-400 text-sm">Loading statistics...</span>
            </div>
          ) : fullStatisticsData ? (
            <div className="space-y-4">
              {/* Main Statistics Table */}
              <div className="overflow-x-auto -mx-4 px-4">
                <div className="inline-block min-w-full align-middle">
                  <div className="overflow-hidden border border-gray-100 dark:border-gray-700">
                    <table className="w-full min-w-[600px]">
                      <thead className="bg-[#EAE8FF] dark:bg-gray-700">
                        <tr>
                          <th className="text-left py-2 px-3 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Sr. No.</th>
                          <th className="text-left py-2 px-3 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Name</th>
                          <th className="text-left py-2 px-3 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Value</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white dark:bg-gray-800">
                        {displayStatisticsData.length > 0 ? (
                          displayStatisticsData.map((row, index) => (
                            <tr
                              key={row.srNo || index}
                              className="border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 last:border-b-0 hover:bg-gray-50 dark:hover:bg-gray-700/50"
                            >
                              <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300">{row.srNo}</td>
                              <td className="py-2 px-3 text-xs text-gray-900 dark:text-gray-100">{row.name}</td>
                              <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300 text-left">
                                {row.name === "Capital Required" || row.name === "Avg Monthly Profit" || row.name === "Total Profit" || row.name === "Max Profit In Day" || row.name === "Max Loss In Day" || row.name === "Avg Profit/Loss Daily" || row.name === "Avg Profit On Profit Days" || row.name === "Avg Loss On Loss Days" || row.name === "Max Drawdown"
                                  ? `₹${parseFloat(row.value || "0").toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                                  : row.name === "Win Rate" || row.name === "Loss Rate" || row.name === "Total ROI" || row.name === "Avg Monthly ROI" || row.name === "Max Drawdown %"
                                  ? `${row.value}%`
                                  : row.value}
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={3} className="py-8 text-center text-gray-500 dark:text-gray-400 text-sm">
                              No statistics data available
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Week Stats Summary */}
              {fullStatisticsData.weekStatsSummary && Array.isArray(fullStatisticsData.weekStatsSummary) && fullStatisticsData.weekStatsSummary.length > 0 && (
                <div className="border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 overflow-hidden">
                  <div className="bg-[#EAE8FF] dark:bg-gray-700 px-4 py-2">
                    <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">Week Stats Summary</h3>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[600px]">
                      <thead className="bg-gray-50 dark:bg-gray-900">
                        <tr>
                          <th className="text-left py-2 px-4 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Day</th>
                          <th className="text-right py-2 px-4 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Returns</th>
                          <th className="text-right py-2 px-4 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Max Profit</th>
                          <th className="text-right py-2 px-4 text-[10px] font-semibold text-gray-600 dark:text-gray-300 uppercase">Max Loss</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white dark:bg-gray-800">
                        {fullStatisticsData.weekStatsSummary.map((day: any, index: number) => (
                          <tr key={index} className="border-t border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                            <td className="py-2 px-4 text-xs text-gray-900 dark:text-gray-100 font-medium">{day.day}</td>
                            <td className={`py-2 px-4 text-xs text-right ${day.returns >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                              ₹{parseFloat(day.returns || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                            <td className="py-2 px-4 text-xs text-right text-green-600 dark:text-green-400">
                              ₹{parseFloat(day.maxProfit || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                            <td className="py-2 px-4 text-xs text-right text-red-600 dark:text-red-400">
                              ₹{parseFloat(day.maxLoss || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400 text-sm">
              No statistics data available
            </div>
          )}
        </div>

        {/* Traders Also Viewed */}
        <div className="mb-6 bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100">Traders who viewed this algo also viewed:</h2>
            <Link to="/discover?tab=popular" className="text-blue-500 dark:text-blue-400 text-xs font-medium underline hover:text-blue-600 dark:hover:text-blue-500">
              View More
            </Link>
          </div>

          {relatedStrategiesLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-[#5266FC] dark:text-blue-400" />
              <span className="ml-2 text-gray-600 dark:text-gray-400">Loading related strategies...</span>
            </div>
          ) : relatedStrategies.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-3 lg:gap-3">
              {relatedStrategies.map((card) => (
                <Link
                  key={card.id}
                  to={`/performance?strategyId=${card.id}&tab=performance&from=${getFromParam(sourcePage)}`}
                  state={{ from: sourcePage, strategyDescription: card.description || "" }}
                  className="flex flex-col gap-2 sm:gap-2.5 lg:gap-2.5 justify-start items-start border border-gray-200 dark:border-gray-700 rounded-sm p-4 sm:p-5 lg:p-5 bg-white dark:bg-gray-800 shadow-sm hover:shadow-md transition-shadow overflow-hidden min-w-0"
                >
                {/* Header Row */}
                <div className="flex flex-row justify-between items-start w-full min-w-0 gap-2">
                  <div className="flex flex-col gap-1 sm:gap-1 lg:gap-1 justify-start items-start flex-1 pr-2 min-w-0">
                    <p className="text-xs sm:text-sm font-medium leading-4 sm:leading-5 text-left text-gray-900 dark:text-gray-100 break-words w-full line-clamp-2">
                      {(() => {
                        // Format title to replace abbreviations (matching DiscoverStrategy)
                        let formatted = String(card.title || "")
                        formatted = formatted.replace(/^NF-/i, 'NIFTY -')
                        formatted = formatted.replace(/\sNF-/gi, ' NIFTY -')
                        formatted = formatted.replace(/^BN-/i, 'BANK NIFTY -')
                        formatted = formatted.replace(/\sBN-/gi, ' BANK NIFTY -')
                        formatted = formatted.replace(/(Delta)\s+(Neutral)\s+(Hedge)/gi, '$1\u00A0$2 $3')
                        return formatted
                      })()}
                    </p>
                  </div>
                  <div className="flex flex-col justify-start items-end gap-1 flex-shrink-0">
                    <div className="flex flex-row justify-end items-start gap-1.5 sm:gap-2">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="text-gray-400 dark:text-gray-500 hover:text-[#5266FC] dark:hover:text-blue-400 transition-colors cursor-pointer">
                            <Info className="w-4 h-4" />
                          </button>
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs p-2 text-xs leading-tight text-center dark:bg-gray-800 dark:text-gray-100 dark:border-gray-700">
                          <p>{String(card.description || "No description available")}</p>
                        </TooltipContent>
                      </Tooltip>
                      <button className="text-gray-400 dark:text-gray-500 hover:text-[#5266FC] dark:hover:text-blue-400 transition-colors cursor-pointer">
                        <Bookmark className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={(e) => {
                          e.preventDefault()
                          setShareModalOpen(true)
                        }}
                        className="text-gray-400 dark:text-gray-500 hover:text-[#5266FC] dark:hover:text-blue-400 transition-colors cursor-pointer"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Tags Row - Full Width */}
                <div className="flex flex-row flex-wrap justify-start items-center w-full gap-1 sm:gap-1.5 lg:gap-1.5 overflow-hidden">
                  {card.tags?.map((tag: string, tagIndex: number) => (
                    <span key={tagIndex} className={`text-[9px] sm:text-[10px] font-normal leading-3 text-left rounded px-1.5 sm:px-2 py-0.5 whitespace-nowrap ${getTagStyle(tag)}`}>
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Description */}
                <p className="text-[10px] sm:text-xs font-normal leading-4 sm:leading-5 text-left text-gray-500 dark:text-gray-400 w-full line-clamp-3 overflow-hidden min-h-[3rem]">
                  {card.description}
                </p>

                {/* Bottom Row */}
                <div className="flex flex-row justify-between items-end w-full mt-auto gap-3 sm:gap-4 min-w-0">
                  <div className="flex flex-col justify-start items-start min-w-0 flex-1 basis-0">
                    <p className="text-[8px] sm:text-[9px] font-normal leading-3 text-left text-gray-500 dark:text-gray-400 whitespace-nowrap">
                      Min Capital
                    </p>
                    <p className="text-[11px] sm:text-xs font-medium leading-4 text-left text-gray-900 dark:text-gray-100 whitespace-nowrap truncate w-full">
                      {card.minCapital}
                    </p>
                  </div>
                  <div className="flex flex-col justify-start items-center min-w-0 flex-1 basis-0">
                    <p className="text-[8px] sm:text-[9px] font-normal leading-3 text-center text-gray-500 dark:text-gray-400 whitespace-nowrap">
                      Avg Return
                    </p>
                    <button
                      onClick={(e) => handleBacktestClick(card, e)}
                      className="text-[11px] sm:text-xs font-semibold leading-4 text-center whitespace-nowrap truncate w-full cursor-pointer hover:opacity-80 transition-opacity relative"
                      type="button"
                    >
                      <span className="relative inline-block">
                        <span 
                          className="inline-block bg-gradient-to-r from-[#4d6ff7] to-[#00e8b0] bg-clip-text text-transparent"
                          style={{
                            backgroundImage: 'linear-gradient(to right, #4d6ff7, #00e8b0)',
                            WebkitBackgroundClip: 'text',
                            WebkitTextFillColor: 'transparent',
                            backgroundClip: 'text',
                          }}
                        >
                          {card.avgReturn}
                        </span>
                        <span 
                          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[85%] h-[1.5px] bg-gradient-to-r from-[#4d6ff7] to-[#00e8b0]"
                        />
                      </span>
                    </button>
                  </div>
                  <div className="flex flex-col justify-start items-start min-w-0 flex-1 basis-0">
                    <p className="text-[8px] sm:text-[9px] font-normal leading-3 text-left text-gray-500 whitespace-nowrap">
                      Risk Level
                    </p>
                    <p className="text-[11px] sm:text-xs font-medium leading-4 text-left text-amber-600 whitespace-nowrap truncate w-full">
                      {card.riskLevel}
                    </p>
                  </div>
                  <div className="w-7 h-7 sm:w-8 sm:h-8 p-1.5 bg-gradient-to-br from-[#5367fc] via-[#4d6ff7] to-[#00e8b0] rounded-sm hover:opacity-90 transition-opacity flex items-center justify-center flex-shrink-0 cursor-pointer ml-2">
                    <ArrowUpRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              No related strategies available
            </div>
          )}
        </div>

        {/* Testimonials */}
        <div className="mb-6 bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex flex-col gap-2 sm:gap-3 lg:gap-3 justify-start items-center w-full mb-4">
            {/* Header - Centered */}
            <div className="flex flex-row justify-center items-center w-full">
              <h2 className="text-lg sm:text-xl font-medium leading-6 text-center text-gray-900 dark:text-gray-100">
                Testimonials
              </h2>
            </div>
          </div>

          {/* Testimonials Slider with Pagination Dots */}
          <div className="relative w-full">
            {/* Testimonials Slider - Centered */}
            <div
              ref={scrollContainerRef}
              className="w-full overflow-x-auto pb-8 hide-scrollbar scroll-smooth relative"
              style={{
                scrollbarWidth: 'none',
                msOverflowStyle: 'none',
              }}
            >
              <div className="flex flex-row gap-2.5 sm:gap-3 lg:gap-3 justify-center items-stretch w-full">
                {testimonials.map((testimonial) => (
                  <div
                    key={testimonial.id}
                    className="flex flex-col gap-2 sm:gap-2.5 lg:gap-2.5 justify-start items-start w-[220px] sm:w-[240px] lg:w-[260px] flex-shrink-0 border border-gray-200 dark:border-gray-700 rounded-sm p-2.5 sm:p-3 lg:p-3 bg-white dark:bg-gray-800 shadow-sm hover:shadow-md transition-shadow"
                  >
                    {renderStars(testimonial.rating)}

                    <p className="text-[10px] sm:text-xs font-normal leading-3 sm:leading-4 text-left text-gray-500 dark:text-gray-400 w-full flex-1 line-clamp-4">
                      {testimonial.text}
                    </p>

                    <div className="flex flex-col gap-0.5 justify-start items-start w-full">
                      <p className="text-xs font-medium leading-4 text-left text-gray-900 dark:text-gray-100">
                        {testimonial.name}
                      </p>
                      <p className="text-[10px] font-normal leading-3 text-left text-gray-500 dark:text-gray-400">
                        {testimonial.date}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Pagination Dots - Bottom Center */}
            <div className="flex justify-center items-center gap-2 mt-4">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => scrollToTestimonial(index)}
                  className={`transition-all duration-300 rounded-full ${
                    activeTestimonialIndex === index
                      ? "w-2.5 h-2.5 bg-[#5367FC] dark:bg-blue-500"
                      : "w-2 h-2 bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-500"
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
          </div>
        </div>
        </div>
      </div>
      </div>

      {/* Deploy Strategy Dialog */}
      <Dialog open={deployDialogOpen} onOpenChange={handleDeployDialogClose}>
        <DialogContent className={deployMode === 'normal' ? "sm:max-w-md p-0 gap-0 max-h-[90vh] flex flex-col bg-white dark:bg-gray-900 rounded-lg shadow-2xl overflow-hidden" : "sm:max-w-xl p-0 gap-0 max-h-[85vh] flex flex-col bg-white dark:bg-gray-900 rounded-lg shadow-2xl overflow-hidden"}>
          {deployError && (
            <div className="bg-gradient-to-r from-red-50 to-red-100 border-b border-red-200 px-4 py-2 flex-shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></div>
                <p className="text-red-800 text-xs font-medium">{deployError}</p>
              </div>
            </div>
          )}

          {deployMode === 'normal' ? (
            <div className="px-5 pt-5 pb-3">
              {/* Header with Icon and Title */}
              {strategyDetails && (
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 rounded-full bg-[#5266FC] dark:bg-blue-500 flex items-center justify-center flex-shrink-0">
                    <span className="text-white font-semibold text-xs">
                      {getStrategyInitials(strategyDetails.name || "Strategy")}
                    </span>
                  </div>
                  <div>
                    <DialogTitle className="text-base font-semibold text-[#1e293b] dark:text-gray-100 mb-0">
                      {strategyDetails.name || "Strategy"} ({strategyId})
                    </DialogTitle>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="px-4 pt-4 pb-3 flex-shrink-0 bg-gradient-to-br from-[#5266FC]/5 via-white dark:via-gray-800 to-[#00e8b0]/5 border-b border-gray-100 dark:border-gray-700">
              {/* Header with Icon and Title */}
              {strategyDetails && (
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#5266FC] to-[#4D6FF7] dark:from-blue-500 dark:to-blue-600 flex items-center justify-center flex-shrink-0 shadow-md">
                    <span className="text-white font-bold text-xs">
                      {getStrategyInitials(strategyDetails.name || "Strategy")}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <DialogTitle className="text-sm font-bold text-gray-900 dark:text-gray-100 truncate">
                      Customize Deployment
                    </DialogTitle>
                    <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                      {strategyDetails.name || "Strategy"} • ID: {strategyId}
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Scrollable Content Area */}
          {deployMode === 'normal' ? (
            <div className="px-5 pb-3">
              <div className="space-y-3">
                {/* Multiplier and Execution Type - Labels on left, controls on right */}
                <div className="space-y-3">
                  {/* Multiplier */}
                  <div className="flex items-center justify-between gap-3">
                    <label className="text-xs font-medium text-gray-700 dark:text-gray-300">
                      Multiplier
                    </label>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleMultiplierChange(-1)}
                        disabled={deployLoading || multiplier <= 0}
                        className="w-8 h-8 flex items-center justify-center rounded border-0 bg-[#4D6FF7] text-white hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={multiplier}
                        onChange={(e) => {
                          const val = parseInt(e.target.value) || 0
                          setMultiplier(Math.max(0, Math.min(100, val)))
                          setMarginNeeded(calculateMarginNeeded(val))
                        }}
                        className="w-12 h-8 px-1 text-center text-sm font-medium border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100 rounded focus:outline-none focus:ring-1 focus:ring-[#5266FC] dark:focus:ring-blue-500 focus:border-transparent"
                        disabled={deployLoading}
                      />
                      <button
                        type="button"
                        onClick={() => handleMultiplierChange(1)}
                        disabled={deployLoading || multiplier >= 100}
                        className="w-8 h-8 flex items-center justify-center rounded border-0 bg-[#4D6FF7] text-white hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Divider Line */}
                  <div className="border-t border-gray-200 dark:border-gray-700"></div>

                  {/* Execution Type */}
                  <div className="flex items-center justify-between gap-3">
                    <label className="text-xs font-medium text-gray-700 dark:text-gray-300">
                      Execution Type
                    </label>
                    <ToggleGroup
                      type="single"
                      value={executionTypeId === "PaperTrading" ? "PaperTrading" : "LiveTrading"}
                      onValueChange={(value) => {
                        if (value) {
                          setExecutionTypeId(value === "PaperTrading" ? "PaperTrading" : "LiveTrading")
                        }
                      }}
                      disabled={deployLoading}
                      className="bg-[#E8EAFF] rounded border-0 overflow-hidden w-auto"
                    >
                      <ToggleGroupItem
                        value="PaperTrading"
                        className="h-7 px-3 data-[state=on]:bg-[#5266FC] dark:data-[state=on]:bg-blue-500 data-[state=on]:text-white data-[state=off]:bg-transparent data-[state=off]:text-[#5266FC] dark:data-[state=off]:text-blue-400 border-0 rounded-none text-xs font-medium py-0 flex flex-col items-center justify-center"
                      >
                        <span>FORWARD</span>
                        <span className="text-[9px] font-normal leading-none">Simulation Trade</span>
                      </ToggleGroupItem>
                      <ToggleGroupItem
                        value="LiveTrading"
                        className="h-7 px-3 data-[state=on]:bg-[#5266FC] dark:data-[state=on]:bg-blue-500 data-[state=on]:text-white data-[state=off]:bg-transparent data-[state=off]:text-[#5266FC] dark:data-[state=off]:text-blue-400 border-0 rounded-none text-xs font-medium py-0"
                      >
                        LIVE
                      </ToggleGroupItem>
                    </ToggleGroup>
                  </div>
                </div>

                {/* Deployment Nudges */}
                {executionTypeId === "PaperTrading" && (
                  <div className="mt-4 p-4 bg-[#E8EAFF] dark:bg-blue-900/20 border border-[#5266FC] dark:border-blue-500 rounded-lg flex gap-3 animate-in slide-in-from-top-2 duration-300">
                    <Info className="w-5 h-5 text-[#5266FC] dark:text-blue-400 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-[#5266FC] dark:text-blue-400 mb-1">Forward Test Mode</div>
                      <div className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                        <strong>No real money will be used</strong> and <strong>no real trades will be placed on the exchange</strong>. This is a simulation mode to test your strategy performance using historical and live market data without any financial risk.
                      </div>
                    </div>
                  </div>
                )}

                {executionTypeId === "LiveTrading" && strategyDetails && (
                  <div className="mt-4 p-4 bg-[#FEF3C7] dark:bg-yellow-900/20 border border-[#F59E0B] dark:border-yellow-500 rounded-lg flex gap-3 animate-in slide-in-from-top-2 duration-300">
                    <AlertTriangle className="w-5 h-5 text-[#F59E0B] dark:text-yellow-400 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-[#92400E] dark:text-yellow-400 mb-1">Capital Requirements Vary</div>
                      <div className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed mb-3">
                        Capital requirements are different for <strong>Expiry Day</strong> and <strong>Non-Expiry Day</strong>. Please ensure you have sufficient capital available.
                      </div>
                      <div className="bg-white dark:bg-gray-800 rounded-md p-3 border border-gray-200 dark:border-gray-700">
                        <table className="w-full text-xs">
                          <thead>
                            <tr className="border-b border-gray-200 dark:border-gray-700">
                              <th className="text-left py-2 text-gray-600 dark:text-gray-400 font-semibold">Day Type</th>
                              <th className="text-left py-2 text-gray-600 dark:text-gray-400 font-semibold">Minimum Capital Required</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="border-b border-gray-100 dark:border-gray-700">
                              <td className="py-2 text-gray-700 dark:text-gray-300">Expiry Day</td>
                              <td className="py-2 font-semibold text-[#5266FC] dark:text-blue-400">
                                {(() => {
                                  const expiryCapital = strategyDetails.minCapital || strategyDetails.requiredCapital || 0
                                  return expiryCapital >= 100000 
                                    ? `₹${(expiryCapital / 100000).toFixed(2)}L`
                                    : expiryCapital >= 1000
                                    ? `₹${(expiryCapital / 1000).toFixed(2)}K`
                                    : `₹${expiryCapital.toLocaleString('en-IN')}`
                                })()}
                              </td>
                            </tr>
                            <tr>
                              <td className="py-2 text-gray-700 dark:text-gray-300">Non-Expiry Day</td>
                              <td className="py-2 font-semibold text-[#5266FC] dark:text-blue-400">
                                {(() => {
                                  const expiryCapital = strategyDetails.minCapital || strategyDetails.requiredCapital || 0
                                  const nonExpiryCapital = (strategyDetails as any).nonExpiryCapital || Math.round(expiryCapital * 0.7)
                                  return nonExpiryCapital >= 100000 
                                    ? `₹${(nonExpiryCapital / 100000).toFixed(2)}L`
                                    : nonExpiryCapital >= 1000
                                    ? `₹${(nonExpiryCapital / 1000).toFixed(2)}K`
                                    : `₹${nonExpiryCapital.toLocaleString('en-IN')}`
                                })()}
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}

                {/* Margin Information - Single Row */}
                <div className="flex justify-between items-center pt-3 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-600 dark:text-gray-400">Margin Needed</span>
                    <span className="text-sm text-gray-900 dark:text-gray-100">
                      {new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 }).format(marginNeeded)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 ml-auto">
                    <span className="text-xs text-gray-600 dark:text-gray-400">Margin Available</span>
                    <span className="text-sm text-gray-900 dark:text-gray-100">
                      {new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(marginAvailable)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="px-4 py-3 overflow-y-auto flex-1 bg-gray-50/50 dark:bg-gray-900/50">
              <div className="space-y-3">
                {/* Customize Deploy: All Fields */}
                {/* Basic Settings Section */}
                  <div className="bg-white dark:bg-gray-800 rounded-lg p-3 shadow-sm border border-gray-100 dark:border-gray-700 space-y-2.5">
                    <div className="flex items-center gap-1.5 pb-1.5 border-b border-gray-100 dark:border-gray-700">
                      <div className="w-6 h-6 rounded-md bg-gradient-to-br from-[#5266FC] to-[#4D6FF7] flex items-center justify-center">
                        <Sliders className="w-3 h-3 text-white" />
                      </div>
                      <h3 className="text-xs font-bold text-gray-900 dark:text-gray-100">Basic Settings</h3>
                    </div>
                    
                    {/* Two Column Layout for Basic Settings */}
                    <div className="grid grid-cols-2 gap-2.5">
                  {/* Multiplier */}
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-1">
                      <Zap className="w-3 h-3 text-[#5266FC]" />
                      Multiplier
                    </label>
                    {dropdownsLoading ? (
                      <div className="flex items-center gap-1.5 px-2 py-1.5 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <Loader2 className="w-3 h-3 animate-spin text-[#5266FC] dark:text-blue-400" />
                        <span className="text-xs text-gray-500 dark:text-gray-400">Loading...</span>
                      </div>
                    ) : (dropdowns?.lot && dropdowns.lot.length > 0) || (dropdowns?.multiplier && dropdowns.multiplier.length > 0) ? (
                      <Select
                        value={String(multiplier)}
                        onValueChange={(value) => {
                          const val = parseInt(value) || 1
                          setMultiplier(val)
                          setMarginNeeded(calculateMarginNeeded(val))
                        }}
                        disabled={deployLoading}
                      >
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="max-h-[200px] overflow-y-auto">
                          {(dropdowns.lot || dropdowns.multiplier || []).map((option) => (
                            <SelectItem key={option.key} value={String(option.key)} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <div className="flex items-center gap-1 bg-gray-50 rounded-md p-0.5">
                        <button
                          type="button"
                          onClick={() => handleMultiplierChange(-1)}
                          disabled={deployLoading || multiplier <= 0}
                          className="w-6 h-6 flex items-center justify-center rounded bg-[#5266FC] text-white hover:bg-[#4D6FF7] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={multiplier}
                          onChange={(e) => {
                            const val = parseInt(e.target.value) || 0
                            setMultiplier(Math.max(0, Math.min(100, val)))
                            setMarginNeeded(calculateMarginNeeded(val))
                          }}
                          className="w-12 h-6 px-1 text-center text-xs font-semibold border border-gray-200 dark:border-gray-600 rounded focus:outline-none focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20 focus:border-[#5266FC] dark:focus:border-blue-500 bg-white dark:bg-gray-800 dark:text-gray-100"
                          disabled={deployLoading}
                        />
                        <button
                          type="button"
                          onClick={() => handleMultiplierChange(1)}
                          disabled={deployLoading || multiplier >= 100}
                          className="w-6 h-6 flex items-center justify-center rounded bg-[#5266FC] text-white hover:bg-[#4D6FF7] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Execution Type */}
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-1">
                      <BarChart3 className="w-3 h-3 text-[#5266FC]" />
                      Execution Type
                    </label>
                    {dropdownsLoading ? (
                      <div className="flex items-center gap-1.5 px-2 py-1.5 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <Loader2 className="w-3 h-3 animate-spin text-[#5266FC] dark:text-blue-400" />
                        <span className="text-xs text-gray-500 dark:text-gray-400">Loading...</span>
                      </div>
                    ) : dropdowns?.executionType && dropdowns.executionType.length > 0 ? (
                      <Select value={executionTypeId} onValueChange={setExecutionTypeId} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {dropdowns.executionType.map((option) => (
                            <SelectItem key={option.key} value={option.key} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <ToggleGroup
                        type="single"
                        value={executionTypeId === "PaperTrading" ? "PaperTrading" : "LiveTrading"}
                        onValueChange={(value) => {
                          if (value) setExecutionTypeId(value === "PaperTrading" ? "PaperTrading" : "LiveTrading")
                        }}
                        disabled={deployLoading}
                        className="bg-gray-50 dark:bg-gray-800 rounded-md p-0.5 border border-gray-200 dark:border-gray-700 h-7"
                      >
                        <ToggleGroupItem value="PaperTrading" className="h-6 px-2 data-[state=on]:bg-gradient-to-r data-[state=on]:from-[#5266FC] data-[state=on]:to-[#4D6FF7] data-[state=on]:text-white data-[state=off]:bg-transparent data-[state=off]:text-gray-700 border-0 rounded text-xs font-semibold flex flex-col items-center justify-center leading-tight">
                          <span>FORWARD</span>
                          <span className="text-[9px] font-normal leading-none">Simulation Trade</span>
                        </ToggleGroupItem>
                        <ToggleGroupItem value="LiveTrading" className="h-6 px-2 data-[state=on]:bg-gradient-to-r data-[state=on]:from-[#5266FC] data-[state=on]:to-[#4D6FF7] data-[state=on]:text-white data-[state=off]:bg-transparent data-[state=off]:text-gray-700 border-0 rounded text-xs font-semibold">
                          LIVE
                        </ToggleGroupItem>
                      </ToggleGroup>
                    )}
                  </div>

                  {/* Deployment Nudges for Customize Mode */}
                  {executionTypeId === "PaperTrading" && (
                    <div className="mt-3 p-4 bg-[#E8EAFF] dark:bg-blue-900/20 border border-[#5266FC] dark:border-blue-500 rounded-lg flex gap-3 animate-in slide-in-from-top-2 duration-300">
                      <Info className="w-5 h-5 text-[#5266FC] dark:text-blue-400 flex-shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <div className="text-sm font-semibold text-[#5266FC] dark:text-blue-400 mb-1">Forward Test Mode</div>
                        <div className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                          <strong>No real money will be used</strong> and <strong>no real trades will be placed on the exchange</strong>. This is a simulation mode to test your strategy performance using historical and live market data without any financial risk.
                        </div>
                      </div>
                    </div>
                  )}

                  {executionTypeId === "LiveTrading" && strategyDetails && (
                    <div className="mt-3 p-4 bg-[#FEF3C7] dark:bg-yellow-900/20 border border-[#F59E0B] dark:border-yellow-500 rounded-lg flex gap-3 animate-in slide-in-from-top-2 duration-300">
                      <AlertTriangle className="w-5 h-5 text-[#F59E0B] dark:text-yellow-400 flex-shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <div className="text-sm font-semibold text-[#92400E] dark:text-yellow-400 mb-1">Capital Requirements Vary</div>
                        <div className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed mb-3">
                          Capital requirements are different for <strong>Expiry Day</strong> and <strong>Non-Expiry Day</strong>. Please ensure you have sufficient capital available.
                        </div>
                        <div className="bg-white dark:bg-gray-800 rounded-md p-3 border border-gray-200 dark:border-gray-700">
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="border-b border-gray-200 dark:border-gray-700">
                                <th className="text-left py-2 text-gray-600 dark:text-gray-400 font-semibold">Day Type</th>
                                <th className="text-left py-2 text-gray-600 dark:text-gray-400 font-semibold">Minimum Capital Required</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr className="border-b border-gray-100 dark:border-gray-700">
                                <td className="py-2 text-gray-700 dark:text-gray-300">Expiry Day</td>
                                <td className="py-2 font-semibold text-[#5266FC] dark:text-blue-400">
                                  {(() => {
                                    const expiryCapital = strategyDetails.minCapital || strategyDetails.requiredCapital || 0
                                    return expiryCapital >= 100000 
                                      ? `₹${(expiryCapital / 100000).toFixed(2)}L`
                                      : expiryCapital >= 1000
                                      ? `₹${(expiryCapital / 1000).toFixed(2)}K`
                                      : `₹${expiryCapital.toLocaleString('en-IN')}`
                                  })()}
                                </td>
                              </tr>
                              <tr>
                                <td className="py-2 text-gray-700 dark:text-gray-300">Non-Expiry Day</td>
                                <td className="py-2 font-semibold text-[#5266FC] dark:text-blue-400">
                                  {(() => {
                                    const expiryCapital = strategyDetails.minCapital || strategyDetails.requiredCapital || 0
                                    const nonExpiryCapital = (strategyDetails as any).nonExpiryCapital || Math.round(expiryCapital * 0.7)
                                    return nonExpiryCapital >= 100000 
                                      ? `₹${(nonExpiryCapital / 100000).toFixed(2)}L`
                                      : nonExpiryCapital >= 1000
                                      ? `₹${(nonExpiryCapital / 1000).toFixed(2)}K`
                                      : `₹${nonExpiryCapital.toLocaleString('en-IN')}`
                                  })()}
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Strategy Type */}
                  {dropdowns?.strategyType && dropdowns.strategyType.length > 0 && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold text-gray-700">Strategy Type</label>
                      <Select value={strategyType} onValueChange={setStrategyType} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {dropdowns.strategyType.map((option) => (
                            <SelectItem key={option.key} value={option.key} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {/* Position Type */}
                  {dropdowns?.positionType && dropdowns.positionType.length > 0 && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold text-gray-700">Position Type</label>
                      <Select value={positionType} onValueChange={setPositionType} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {dropdowns.positionType.map((option) => (
                            <SelectItem key={option.key} value={option.key} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              </div>

              {/* Market Settings Section */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-3 shadow-sm border border-gray-100 dark:border-gray-700 space-y-2.5">
                <div className="flex items-center gap-1.5 pb-1.5 border-b border-gray-100 dark:border-gray-700">
                  <div className="w-6 h-6 rounded-md bg-gradient-to-br from-[#00e8b0] to-[#00d4a3] flex items-center justify-center">
                    <TrendingUp className="w-3 h-3 text-white" />
                  </div>
                  <h3 className="text-xs font-bold text-gray-900">Market Settings</h3>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                
                  {/* Underlying */}
                  {dropdowns?.underlyingMenu && dropdowns.underlyingMenu.length > 0 && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold text-gray-700">Underlying</label>
                      <Select value={String(underlying)} onValueChange={(v) => setUnderlying(parseInt(v))} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {dropdowns.underlyingMenu.map((option) => (
                            <SelectItem key={option.key} value={String(option.key)} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {/* Expiry Type */}
                  {dropdowns?.expiryType && dropdowns.expiryType.length > 0 && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-[#00e8b0]" />
                        Expiry Type
                      </label>
                      <Select value={expiryType} onValueChange={setExpiryType} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {dropdowns.expiryType.map((option) => (
                            <SelectItem key={option.key} value={option.key} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {/* Strike Selection */}
                  {dropdowns?.strikeSelection && dropdowns.strikeSelection.length > 0 && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold text-gray-700">Strike Selection</label>
                      <Select value={strikeSelection} onValueChange={setStrikeSelection} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="max-h-[200px] overflow-y-auto">
                          {dropdowns.strikeSelection.map((option) => (
                            <SelectItem key={option.key} value={option.key} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {/* Segment Type */}
                  {dropdowns?.segmentType && dropdowns.segmentType.length > 0 && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold text-gray-700">Segment Type</label>
                      <Select value={segmentType} onValueChange={setSegmentType} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {dropdowns.segmentType.map((option) => (
                            <SelectItem key={option.key} value={option.key} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {/* Order */}
                  {dropdowns?.order && dropdowns.order.length > 0 && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold text-gray-700">Order</label>
                      <Select value={order} onValueChange={setOrder} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {dropdowns.order.map((option) => (
                            <SelectItem key={option.key} value={option.key} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              </div>

              {/* Entry & Exit Settings Section */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-3 shadow-sm border border-gray-100 dark:border-gray-700 space-y-2.5">
                <div className="flex items-center gap-1.5 pb-1.5 border-b border-gray-100 dark:border-gray-700">
                  <div className="w-6 h-6 rounded-md bg-gradient-to-br from-orange-400 to-orange-500 flex items-center justify-center">
                    <Calendar className="w-3 h-3 text-white" />
                  </div>
                  <h3 className="text-xs font-bold text-gray-900">Entry & Exit Settings</h3>
                </div>
                
                {/* Entry Days */}
                {dropdowns?.daysMenu && dropdowns.daysMenu.length > 0 && (
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-semibold text-gray-700">Entry Days</label>
                    <div className="flex flex-wrap gap-1.5">
                      {dropdowns.daysMenu.map((option) => {
                        const isSelected = entryDays.includes(option.key)
                        return (
                          <button
                            key={option.key}
                            type="button"
                            onClick={() => {
                              if (isSelected) {
                                setEntryDays(entryDays.filter(d => d !== option.key))
                              } else {
                                setEntryDays([...entryDays, option.key])
                              }
                            }}
                            disabled={deployLoading}
                            className={`px-2 py-1 text-xs font-semibold rounded-md border transition-all ${
                              isSelected
                                ? "bg-gradient-to-r from-[#5266FC] to-[#4D6FF7] text-white border-[#5266FC]"
                                : "bg-white text-gray-700 border-gray-200 hover:border-[#5266FC] hover:bg-gray-50"
                            }`}
                          >
                            {option.val.substring(0, 3)}
                          </button>
                        )
                      })}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2.5">
                  {/* Exit After Entry Days */}
                  {dropdowns?.exitAfterEntry && dropdowns.exitAfterEntry.length > 0 && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold text-gray-700">Exit After Entry Days</label>
                      <Select value={String(exitAfterEntry)} onValueChange={(v) => setExitAfterEntry(parseInt(v))} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {dropdowns.exitAfterEntry.map((option) => (
                            <SelectItem key={option.key} value={String(option.key)} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {/* Exit On Expiry */}
                  {dropdowns?.exitOnExpiry && dropdowns.exitOnExpiry.length > 0 && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold text-gray-700">Exit On Expiry</label>
                      <Select value={exitOnExpiry} onValueChange={setExitOnExpiry} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {dropdowns.exitOnExpiry.map((option) => (
                            <SelectItem key={option.key} value={option.key} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              </div>

              {/* Profit & Loss Settings Section */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-3 shadow-sm border border-gray-100 dark:border-gray-700 space-y-2.5">
                <div className="flex items-center gap-1.5 pb-1.5 border-b border-gray-100 dark:border-gray-700">
                  <div className="w-6 h-6 rounded-md bg-gradient-to-br from-green-400 to-green-500 flex items-center justify-center">
                    <Target className="w-3 h-3 text-white" />
                  </div>
                  <h3 className="text-xs font-bold text-gray-900">Profit & Loss Settings</h3>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  {/* Profit MTM */}
                  {dropdowns?.profitMtm && dropdowns.profitMtm.length > 0 && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-1">
                        <DollarSign className="w-3 h-3 text-green-500" />
                        Profit MTM
                      </label>
                      <Select value={profitMtm} onValueChange={setProfitMtm} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {dropdowns.profitMtm.map((option) => (
                            <SelectItem key={option.key} value={option.key} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {/* Target (TGT) */}
                  {dropdowns?.tgt && dropdowns.tgt.length > 0 && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold text-gray-700">Target</label>
                      <Select value={tgt} onValueChange={setTgt} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {dropdowns.tgt.map((option) => (
                            <SelectItem key={option.key} value={option.key} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {/* Trailing (TRL) */}
                  {dropdowns?.trl && dropdowns.trl.length > 0 && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold text-gray-700">Trailing</label>
                      <Select value={trl} onValueChange={setTrl} disabled={deployLoading}>
                        <SelectTrigger className="h-7 text-xs border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 dark:text-gray-100 hover:border-[#5266FC] dark:hover:border-blue-500 transition-colors focus:ring-1 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {dropdowns.trl.map((option) => (
                            <SelectItem key={option.key} value={option.key} className="text-xs">
                              {option.val}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              </div>

              {/* Margin Information */}
              <div className="bg-gradient-to-r from-[#5266FC]/10 via-[#00e8b0]/10 to-[#5266FC]/10 rounded-lg p-3 border border-[#5266FC]/20">
                <div className="flex justify-between items-center">
                  <div className="flex flex-col gap-0.5">
                    <span className="text-xs font-medium text-gray-600">Margin Needed</span>
                    <span className="text-sm font-bold text-gray-900">
                      ₹{new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 }).format(marginNeeded)}
                    </span>
                  </div>
                  <div className="w-px h-8 bg-gray-300"></div>
                  <div className="flex flex-col gap-0.5 items-end">
                    <span className="text-xs font-medium text-gray-600">Margin Available</span>
                    <span className="text-sm font-bold text-green-600">
                      ₹{new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(marginAvailable)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          )}

          {/* Footer Buttons - Right Side */}
          <div className={deployMode === 'normal' ? "px-5 py-3 border-t border-gray-200 dark:border-gray-700 flex justify-end gap-2" : "px-4 py-3 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 flex justify-end gap-2 flex-shrink-0"}>
            <Button
              type="button"
              onClick={() => handleDeployDialogClose(false)}
              disabled={deployLoading}
              className={deployMode === 'normal' ? "px-4 py-1.5 bg-white dark:bg-gray-800 border border-[#5266FC] dark:border-blue-500 text-[#5266FC] dark:text-blue-400 hover:bg-gray-50 dark:hover:bg-gray-700 text-xs font-medium h-8" : "px-4 py-1.5 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 text-xs font-semibold h-8 rounded-md transition-all"}
            >
              {deployMode === 'normal' ? 'CANCEL' : 'Cancel'}
            </Button>
            <Button
              type="button"
              onClick={handleDeploySubmit}
              disabled={deployLoading || !strategyId || multiplier <= 0}
              className={deployMode === 'normal' ? "px-4 py-1.5 bg-gradient-to-r from-[#3B5BD9] via-[#4D6FF7] to-[#00e8b0] dark:from-blue-500 dark:via-blue-600 dark:to-blue-500 text-white hover:opacity-90 text-xs font-medium h-8" : "px-4 py-1.5 bg-gradient-to-r from-[#5266FC] via-[#4D6FF7] to-[#00e8b0] text-white hover:opacity-90 text-xs font-bold h-8 rounded-md transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5"}
            >
              {deployLoading ? (
                <>
                  <Loader2 className={deployMode === 'normal' ? "w-3 h-3 mr-1.5 animate-spin" : "w-3 h-3 animate-spin"} />
                  Deploying...
                </>
              ) : (
                deployMode === 'normal' ? 'Deploy' : (
                  <>
                    <Zap className="w-3 h-3" />
                    Deploy
                  </>
                )
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Undeploy Confirmation Dialog */}
      {undeployDialogOpen && pendingUndeployStrategy && (
        <Dialog open={undeployDialogOpen} onOpenChange={setUndeployDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Undeploy Action</DialogTitle>
              <DialogDescription>
                Are you sure you want to undeploy the strategy <strong>{pendingUndeployStrategy.strategyName}</strong>? 
                This will undeploy the strategy.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <button
                onClick={handleUndeployCancel}
                disabled={undeployLoading}
                className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Cancel
              </button>
              <button
                onClick={handleUndeployConfirm}
                disabled={undeployLoading}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {undeployLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                Confirm
              </button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Share Modal */}
      <Dialog open={shareModalOpen} onOpenChange={setShareModalOpen}>
        <DialogContent className="sm:max-w-md p-6">
          <div className="flex flex-col items-center">
            {/* Share GIF */}
            <div className="mb-4 flex justify-center">
              <img 
                src="/images/share.gif" 
                alt="Share" 
                className="w-16 h-16 object-contain"
              />
            </div>

            {/* Title */}
            <h2 className="text-lg font-bold text-gray-900 mb-2">Share Your Strategy</h2>
            
            {/* Description */}
            <p className="text-sm text-gray-500 text-center mb-4">
              Use the link below to quickly share this strategy anywhere.
            </p>

            {/* Link Input and Copy Button */}
            <div className="flex items-center gap-2 w-full mb-4">
              <input
                type="text"
                value={`https://bigul.co/bigul-algos`}
                readOnly
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-gray-50"
              />
              <Button
                onClick={() => {
                  navigator.clipboard.writeText('https://bigul.co/bigul-algos')
                }}
                className="px-4 py-2 bg-[#5266FC] hover:bg-[#3d4fc7] text-white rounded-lg text-sm font-medium whitespace-nowrap"
              >
                Copy
              </Button>
            </div>

            {/* Also share on */}
            <p className="text-sm text-gray-500 mb-3">Also share on:</p>

            {/* Social Media Icons */}
            <div className="flex items-center gap-2 w-full justify-center">
              {/* Facebook */}
              <button className="w-10 h-10 bg-[#5266FC] rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] transition-colors">
                <span className="text-white font-bold text-sm">f</span>
              </button>
              
              {/* Email */}
              <button className="w-10 h-10 bg-[#5266FC] rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] transition-colors">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </button>
              
              {/* X (Twitter) */}
              <button className="w-10 h-10 bg-[#5266FC] rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </button>
              
              {/* Instagram */}
              <button className="w-10 h-10 bg-[#5266FC] rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </button>
              
              {/* YouTube */}
              <button className="w-10 h-10 bg-[#5266FC] rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                </svg>
              </button>
              
              {/* Telegram */}
              <button className="w-10 h-10 bg-[#5266FC] rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                </svg>
              </button>
              
              {/* WhatsApp */}
              <button className="w-10 h-10 bg-[#5266FC] rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Backtest Consent Dialog */}
      <Dialog open={backtestConsentOpen} onOpenChange={setBacktestConsentOpen}>
        <DialogContent className="sm:max-w-md p-0 gap-0">
          <div className="px-5 pt-5 pb-3">
            <DialogHeader>
              <DialogTitle className="text-base font-semibold text-[#1e293b] dark:text-gray-100 mb-0 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500 dark:text-amber-400" />
                Backtesting: Please note
              </DialogTitle>
            </DialogHeader>
            
            <div className="mt-4 space-y-2.5">
              <div className="flex items-start gap-2.5">
                <span className="text-[#5266FC] dark:text-blue-400 mt-0.5">•</span>
                <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                  Backtesting is based on historical market data and assumes ideal trading conditions.
                </p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="text-[#5266FC] dark:text-blue-400 mt-0.5">•</span>
                <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                  Past performance does not guarantee future results. Actual trading may differ significantly.
                </p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="text-[#5266FC] dark:text-blue-400 mt-0.5">•</span>
                <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                  Market conditions, slippage, and execution delays are not fully reflected in backtest results.
                </p>
              </div>
            </div>
          </div>
          <DialogFooter className="px-5 pb-5 pt-3 flex-row gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setBacktestConsentOpen(false)
                setPendingBacktestStrategy(null)
              }}
              className="flex-1 h-9 text-xs"
            >
              Cancel
            </Button>
            <Button
              onClick={handleBacktestConsent}
              disabled={backtestConsentLoading}
              className="flex-1 h-9 text-xs bg-[#5266FC] hover:bg-[#4255E6] text-white disabled:opacity-50"
            >
              {backtestConsentLoading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                  Loading...
                </>
              ) : (
                "I understand. Backtest Now"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

