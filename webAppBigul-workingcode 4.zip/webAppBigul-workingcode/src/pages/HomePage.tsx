import { useEffect, useRef } from "react"
import { useLocation } from "react-router-dom"
import Header from "@components/Header"
import Homepage from "@components/Homepage"
import { authService } from "@/lib/api/auth.service"
import { useAuthStore } from "@/store/auth.store"
import { getClientIdFromToken, decodeJWT } from "@/lib/utils/jwt"
import { logger } from "@/lib/utils/logger"

export default function HomePage() {
  const { token, isAuthenticated: _isAuthenticated } = useAuthStore()
  const location = useLocation()
  const welcomeApiCalledRef = useRef(false) // Track if welcome API has been called

  useEffect(() => {
    // Show message if redirected from protected route
    const state = location.state as { message?: string } | null
    if (state?.message) {
      // Message handled silently
    }
  }, [location])

  // Track token to prevent re-calling when token object reference changes
  const tokenRef = useRef<string | null>(null)

  useEffect(() => {
    // Only proceed if token actually changed (not just reference)
    if (token === tokenRef.current) {
      return
    }
    tokenRef.current = token

    // Call welcome API ONLY ONCE when token is first received
    // This matches the curl command: POST /ql/auth/welcome with clientId and termsConditions
    const callWelcomeAPI = async () => {
      // Skip if already called or no token
      if (welcomeApiCalledRef.current || !token) {
        if (welcomeApiCalledRef.current) {
          logger.info("Welcome API already called, skipping")
        }
        return
      }

      try {
        // Extract clientId from token with multiple fallback methods (same as strategy.service.ts)
        let clientId = getClientIdFromToken(token)
        
        // If clientId not found, try decoding token directly and checking multiple fields
        if (!clientId) {
          logger.warn("ClientId not found via getClientIdFromToken, attempting direct decode")
          const decoded = decodeJWT(token)
          
          if (decoded) {
            console.log("Decoded token for clientId extraction:", decoded)
            
            // Try multiple possible fields that might contain clientId
            const possibleClientId = 
              (decoded.unique_name as string) || 
              (decoded.LoginId as string) || 
              (decoded.loginId as string) ||
              (decoded["unique_name"] as string) ||
              (decoded["LoginId"] as string) ||
              (decoded.clientId as string) ||
              (decoded["clientId"] as string) ||
              (decoded.client_id as string) ||
              (decoded["client_id"] as string) ||
              null
            
            if (possibleClientId && typeof possibleClientId === "string") {
              clientId = possibleClientId
            }
            
            if (clientId) {
              logger.info("ClientId found via direct token decode:", clientId)
            }
          }
        }
        
        // If still no clientId, try to get it from checkToken response if available
        if (!clientId) {
          logger.warn("ClientId still not found, attempting to get from checkToken response")
          try {
            const xtsToken = useAuthStore.getState().xtsToken
            if (xtsToken) {
              const checkResponse = await authService.checkToken(token, xtsToken)
              if (checkResponse.success && checkResponse.data?.clientId) {
                const responseClientId = checkResponse.data.clientId
                if (typeof responseClientId === "string") {
                  clientId = responseClientId
                  logger.info("ClientId found from checkToken response:", clientId)
                }
              }
            }
          } catch (error) {
            logger.warn("Failed to get clientId from checkToken:", error)
          }
        }
        
        if (clientId) {
          logger.info("Calling welcome API for clientId:", clientId)
          // Mark as called BEFORE making the API call to prevent duplicate calls
          welcomeApiCalledRef.current = true
          
          // Call welcome API with clientId and termsConditions=true as per curl command
          const welcomeResponse = await authService.welcome(clientId, true)
          
          if (welcomeResponse.success) {
            logger.info("Welcome API called successfully")
            // Welcome message is silent - no toastr needed
          } else {
            logger.error("Failed to call welcome API:", welcomeResponse.error?.message)
            // Reset flag on failure so it can be retried if needed
            welcomeApiCalledRef.current = false
          }
        } else {
          logger.warn("ClientId not found after all attempts, skipping welcome API call")
        }
      } catch (error) {
        logger.error("Error calling welcome API:", error)
        // Reset flag on error so it can be retried if needed
        welcomeApiCalledRef.current = false
        // Don't show error toast for network issues to avoid spamming
      }
    }

    // Call only when token is first available
    callWelcomeAPI()
  }, [token]) // Only depend on token, not isAuthenticated, to call as soon as token is available

  return (
    <div className="min-h-screen bg-[#F5F5F5] dark:bg-gray-950">
      <Header />
      <Homepage />
    </div>
  )
}

