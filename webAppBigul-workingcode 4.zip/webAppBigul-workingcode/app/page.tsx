"use client"

import type React from "react"
import { useState } from "react"
import { Calendar, ChevronDown, ChevronUp, ChevronLeft, ChevronRight, Download, Search } from "lucide-react"
import Header from "../components/Header"
import DiscoverStrategy from "../components/DiscoverStrategy"
import Homepage from "../components/Homepage"
import CreateStrategy from "../components/CreateStrategy"

export default function Home() {
  const [activeNav, setActiveNav] = useState("home")
  const [activeToggle, setActiveToggle] = useState("LIVE")
  const [currentPage, setCurrentPage] = useState(1)

  const orderBookData = [
    {
      srNo: 1,
      strategyName: "ABC",
      dateTime: "01/12/2024",
      symbol: "Symbol",
      quantity: 12,
      price: "₹ 0.00",
      status: "Active",
      id: 1245,
    },
    {
      srNo: 2,
      strategyName: "ABC",
      dateTime: "01/12/2024",
      symbol: "Symbol",
      quantity: 12,
      price: "₹ 0.00",
      status: "Active",
      id: 1246,
    },
    {
      srNo: 3,
      strategyName: "ABC",
      dateTime: "01/12/2024",
      symbol: "Symbol",
      quantity: 12,
      price: "₹ 0.00",
      status: "Active",
      id: 1247,
    },
    {
      srNo: 4,
      strategyName: "ABC",
      dateTime: "01/12/2024",
      symbol: "Symbol",
      quantity: 12,
      price: "₹ 0.00",
      status: "Active",
      id: 1248,
    },
    {
      srNo: 5,
      strategyName: "ABC",
      dateTime: "01/12/2024",
      symbol: "Symbol",
      quantity: 12,
      price: "₹ 0.00",
      status: "Active",
      id: 1249,
    },
  ]


  // Conditional rendering based on activeNav
  if (activeNav === "discover") {
    return (
      <div className="min-h-screen" style={{ backgroundColor: "#F5F5F5" }}>
        <Header activeNav={activeNav} onNavChange={setActiveNav} />
        <DiscoverStrategy />
      </div>
    )
  }

  if (activeNav === "create-strategy") {
    return (
      <div className="min-h-screen" style={{ backgroundColor: "#F5F5F5" }}>
        <Header activeNav={activeNav} onNavChange={setActiveNav} />
        <CreateStrategy />
      </div>
    )
  }

  if (activeNav === "home") {
    return (
      <div className="min-h-screen" style={{ backgroundColor: "#F5F5F5" }}>
        <Header activeNav={activeNav} onNavChange={setActiveNav} />
        <Homepage onNavChange={setActiveNav} />
      </div>
    )
  }

  const TableHeader = ({ children }: { children: React.ReactNode }) => (
    <th className="px-3 sm:px-4 py-2 sm:py-3 text-left text-xs sm:text-sm font-medium text-black whitespace-nowrap">
      <div className="flex items-center gap-1">
        {children}
        <div className="flex flex-col -space-y-1">
          <ChevronUp className="w-3 h-3 text-gray-600" />
          <ChevronDown className="w-3 h-3 text-gray-600" />
        </div>
      </div>
    </th>
  )

  const DateFilter = () => (
    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-4">
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
        <span className="text-xs sm:text-sm text-gray-500 whitespace-nowrap">From Date</span>
        <div className="flex items-center gap-2 px-3 py-2 border border-white bg-white rounded-lg">
          <Calendar className="w-4 h-4 text-gray-400 flex-shrink-0" />
          <span className="text-xs sm:text-sm text-gray-700">01/12/2024</span>
        </div>
      </div>
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
        <span className="text-xs sm:text-sm text-gray-500 whitespace-nowrap">To Date</span>
        <div className="flex items-center gap-2 px-3 py-2 border border-white bg-white rounded-lg">
          <Calendar className="w-4 h-4 text-gray-400 flex-shrink-0" />
          <span className="text-xs sm:text-sm text-gray-700">01/12/2024</span>
        </div>
      </div>
      <button className="p-2 text-[#5266FC] bg-white rounded-lg hover:bg-gray-50 transition flex-shrink-0 self-start sm:self-auto">
        <Download className="w-5 h-5" />
      </button>
    </div>
  )

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#F5F5F5" }}>
      <Header activeNav={activeNav} onNavChange={setActiveNav} />
      <main className="pt-24 pb-8">
        <div className="max-w-7xl mx-auto px-8 sm:px-12 lg:px-28">
          {/* Header Section */}
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-gray-900 mb-1">Track & Manage Your Algo</h1>
              <p className="text-sm sm:text-base text-gray-500">
                Get a complete overview of your strategies, performance, positions, and order activity.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <div className="flex items-center p-1 rounded-lg" style={{ backgroundColor: "#E8EAFF" }}>
                <button
                  onClick={() => setActiveToggle("FORWARD")}
                  className={`px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium transition rounded-md ${
                    activeToggle === "FORWARD" ? "bg-[#5266FC] text-white" : "text-gray-600"
                  }`}
                >
                  FORWARD
                </button>
                <button
                  onClick={() => setActiveToggle("LIVE")}
                  className={`px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium transition rounded-md ${
                    activeToggle === "LIVE" ? "bg-[#5266FC] text-white" : "text-gray-600"
                  }`}
                >
                  LIVE
                </button>
              </div>
              <button className="px-4 py-2 border border-red-400 text-red-500 bg-white rounded-md text-xs sm:text-sm font-medium hover:bg-red-50 transition whitespace-nowrap">
                Exit all
              </button>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="p-4 border border-gray-200 rounded-xl flex items-center justify-between bg-white">
              <div>
                <p className="text-xl sm:text-2xl font-bold text-gray-900">05</p>
                <p className="text-xs sm:text-sm text-gray-500">Active Strategy</p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 flex-shrink-0">
                <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="24" cy="24" r="20" fill="#E8EAFF" />
                  <circle cx="24" cy="24" r="8" fill="#5266FC" />
                  <path d="M24 8V16" stroke="#5266FC" strokeWidth="2" strokeLinecap="round" />
                  <path d="M24 32V40" stroke="#5266FC" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </div>
            </div>
            <div className="p-4 border border-gray-200 rounded-xl flex items-center justify-between bg-white">
              <div>
                <p className="text-xl sm:text-2xl font-bold text-gray-900">54.00L</p>
                <p className="text-xs sm:text-sm text-gray-500">Deployed Capital</p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 flex-shrink-0">
                <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="8" y="16" width="32" height="24" rx="4" fill="#E8EAFF" />
                  <rect x="16" y="8" width="16" height="12" rx="2" fill="#C7CCFF" />
                  <circle cx="24" cy="28" r="6" fill="#5266FC" />
                </svg>
              </div>
            </div>
            <div className="p-4 border border-gray-200 rounded-xl flex items-center justify-between bg-white">
              <div>
                <p className="text-xl sm:text-2xl font-bold text-green-500">71.08K</p>
                <p className="text-xs sm:text-sm text-gray-500">Today P&L</p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 flex-shrink-0">
                <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="8" y="12" width="32" height="28" rx="4" fill="#E8EAFF" />
                  <path
                    d="M16 32L22 24L28 28L36 18"
                    stroke="#5266FC"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <circle cx="36" cy="18" r="3" fill="#5266FC" />
                </svg>
              </div>
            </div>
            <div className="p-4 border border-gray-200 rounded-xl flex items-center justify-between bg-white">
              <div>
                <p className="text-xl sm:text-2xl font-bold text-green-500">14.71K</p>
                <p className="text-xs sm:text-sm text-gray-500">Overall P&L</p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 flex-shrink-0">
                <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="8" y="20" width="8" height="20" rx="2" fill="#C7CCFF" />
                  <rect x="20" y="12" width="8" height="28" rx="2" fill="#5266FC" />
                  <rect x="32" y="16" width="8" height="24" rx="2" fill="#E8EAFF" />
                  <path d="M10 16L24 8L38 12" stroke="#5266FC" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </div>
            </div>
          </div>

          {/* Search Section */}
          <div className="flex items-center justify-end mb-6">
            <div className="relative w-full sm:w-auto">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search Deployed Strategies"
                className="pl-10 pr-4 py-2 border border-white bg-white rounded-lg text-sm w-full sm:w-72 focus:outline-none focus:border-[#5266FC]"
              />
            </div>
          </div>

          {/* OrderBook Table */}
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
              <h2 className="text-lg sm:text-xl font-bold text-gray-900">OrderBook</h2>
              <DateFilter />
            </div>
            
            {/* Desktop Table View */}
            <div className="hidden md:block border border-gray-200 overflow-x-auto bg-white rounded-lg">
              <table className="w-full min-w-[800px]">
                <thead style={{ backgroundColor: "#D6D9F6" }}>
                  <tr>
                    <TableHeader>Sr.No</TableHeader>
                    <TableHeader>Strategy Name</TableHeader>
                    <TableHeader>Date & Time</TableHeader>
                    <TableHeader>Symbol</TableHeader>
                    <TableHeader>Quantity</TableHeader>
                    <TableHeader>Price</TableHeader>
                    <TableHeader>Status</TableHeader>
                    <TableHeader>ID</TableHeader>
                  </tr>
                </thead>
                <tbody>
                  {orderBookData.map((row, index) => (
                    <tr key={index} className="border-b border-gray-100 last:border-b-0 hover:bg-gray-50">
                      <td className="px-3 sm:px-4 py-3 sm:py-4 text-xs sm:text-sm text-gray-700">{row.srNo}</td>
                      <td className="px-3 sm:px-4 py-3 sm:py-4 text-xs sm:text-sm text-gray-700">{row.strategyName}</td>
                      <td className="px-3 sm:px-4 py-3 sm:py-4 text-xs sm:text-sm text-gray-700 whitespace-nowrap">{row.dateTime}</td>
                      <td className="px-3 sm:px-4 py-3 sm:py-4 text-xs sm:text-sm text-gray-700">{row.symbol}</td>
                      <td className="px-3 sm:px-4 py-3 sm:py-4 text-xs sm:text-sm text-gray-700">{row.quantity}</td>
                      <td className="px-3 sm:px-4 py-3 sm:py-4 text-xs sm:text-sm text-gray-700">{row.price}</td>
                      <td className="px-3 sm:px-4 py-3 sm:py-4 text-xs sm:text-sm text-gray-700">
                        <span className={`px-2 py-1 rounded text-xs ${
                          row.status === 'Active' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {row.status}
                        </span>
                      </td>
                      <td className="px-3 sm:px-4 py-3 sm:py-4 text-xs sm:text-sm text-gray-700">{row.id}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Card View */}
            <div className="md:hidden space-y-3">
              {orderBookData.map((row) => (
                <div key={row.id} className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-semibold text-gray-900 text-sm">{row.strategyName}</h3>
                      <p className="text-xs text-gray-500 mt-0.5">ID: #{row.id}</p>
                    </div>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      row.status === 'Active' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {row.status}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <span className="text-gray-500 text-xs">Sr. No:</span>
                      <p className="text-gray-900 font-medium">{row.srNo}</p>
                    </div>
                    <div>
                      <span className="text-gray-500 text-xs">Date & Time:</span>
                      <p className="text-gray-900 font-medium">{row.dateTime}</p>
                    </div>
                    <div>
                      <span className="text-gray-500 text-xs">Symbol:</span>
                      <p className="text-gray-900 font-medium">{row.symbol}</p>
                    </div>
                    <div>
                      <span className="text-gray-500 text-xs">Quantity:</span>
                      <p className="text-gray-900 font-medium">{row.quantity}</p>
                    </div>
                    <div className="col-span-2">
                      <span className="text-gray-500 text-xs">Price:</span>
                      <p className="text-gray-900 font-medium">{row.price}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>


          {/* Pagination */}
          <div className="flex items-center justify-center sm:justify-end gap-1 mt-4 overflow-x-auto">
            <button className="p-2 text-gray-400 bg-gray-100 rounded-lg hover:bg-gray-200 transition">
              <ChevronLeft className="w-4 h-4" />
            </button>
            {[1, 2].map((page) => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                className={`w-8 h-8 text-sm font-medium rounded-lg transition ${
                  currentPage === page ? "border border-[#5266FC] text-[#5266FC]" : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                {page}
              </button>
            ))}
            <span className="px-2 text-gray-400">...</span>
            {[9, 10].map((page) => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                className={`w-8 h-8 text-sm font-medium rounded-lg transition ${
                  currentPage === page ? "border border-[#5266FC] text-[#5266FC]" : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                {page}
              </button>
            ))}
            <button className="p-2 text-gray-400 hover:bg-gray-100 rounded-lg transition">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </main>
    </div>
  )
}
