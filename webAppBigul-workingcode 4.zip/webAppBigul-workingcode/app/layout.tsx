import type React from "react"
// Note: This file is not currently used - the app uses React Router in src/
// import type { Metadata } from "next"
// import { Poppins } from "next/font/google"
// import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

// const _poppins = Poppins({ weight: ["400", "500", "600", "700"], subsets: ["latin"] })

// export const metadata: Metadata = {
//   title: "Bigul Frontend - Professional Trading Strategies",
//   description: "Discover, create and manage professional trading strategies on the Bigul platform",
//   generator: "v0.app",
//   icons: {
//     icon: [
//       {
//         url: "/icon-light-32x32.png",
//         media: "(prefers-color-scheme: light)",
//       },
//       {
//         url: "/icon-dark-32x32.png",
//         media: "(prefers-color-scheme: dark)",
//       },
//       {
//         url: "/icon.svg",
//         type: "image/svg+xml",
//       },
//     ],
//     apple: "/apple-icon.png",
//   },
// }

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`font-sans antialiased bg-white dark:bg-gray-900`}>
        {children}
        {/* <Analytics /> */}
      </body>
    </html>
  )
}
