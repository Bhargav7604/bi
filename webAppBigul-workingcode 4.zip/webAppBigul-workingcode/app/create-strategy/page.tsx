"use client"

import Header from "@components/Header"
import CreateStrategy from "@components/CreateStrategy"

export default function CreateStrategyPage() {
  return (
    <div className="min-h-screen" style={{ backgroundColor: "#F5F5F5" }}>
      <Header />
      <CreateStrategy />
    </div>
  )
}

