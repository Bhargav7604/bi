"use client"

interface StrategyTemplateCardProps {
  name: string
  type: string
}

export function StrategyTemplateCard({ name, type: _type }: StrategyTemplateCardProps) {
  const getChartPath = () => {
    const nameLower = name.toLowerCase()
    
    // Protective Put - downward sloping line
    if (nameLower.includes("protective put")) {
      return (
        <svg viewBox="0 0 80 50" className="w-full h-12">
          <path
            d="M5 10 L25 25 L40 30 L55 35 L75 45"
            stroke="#6366F1"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )
    }
    
    // Bull Call Spread - upward sloping with two lines
    if (nameLower.includes("bull call") || nameLower.includes("call spread")) {
      return (
        <svg viewBox="0 0 80 50" className="w-full h-12">
          <path
            d="M5 40 L25 30 L40 25 L55 20 L75 10"
            stroke="#22C55E"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M5 45 L25 35 L40 30 L55 25 L75 15"
            stroke="#EF4444"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray="4 4"
          />
        </svg>
      )
    }
    
    // Covered Put - upward line
    if (nameLower.includes("covered put")) {
      return (
        <svg viewBox="0 0 80 50" className="w-full h-12">
          <path
            d="M5 40 L25 30 L40 25 L55 20 L75 10"
            stroke="#6366F1"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )
    }
    
    // Long Straddle - V shape
    if (nameLower.includes("straddle")) {
      return (
        <svg viewBox="0 0 80 50" className="w-full h-12">
          <path
            d="M5 40 L40 15 L75 40"
            stroke="#6366F1"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )
    }
    
    // Long Put Ladder - stepped downward
    if (nameLower.includes("put ladder") || nameLower.includes("ladder")) {
      return (
        <svg viewBox="0 0 80 50" className="w-full h-12">
          <path
            d="M5 15 L20 15 L20 25 L35 25 L35 35 L50 35 L50 40 L65 40 L65 45 L75 45"
            stroke="#6366F1"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )
    }
    
    // Strap - upward V with emphasis
    if (nameLower.includes("strap")) {
      return (
        <svg viewBox="0 0 80 50" className="w-full h-12">
          <path
            d="M5 40 L40 10 L75 40"
            stroke="#22C55E"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M40 10 L40 5"
            stroke="#22C55E"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
          />
        </svg>
      )
    }
    
    // Default - Buy Put - downward sloping line
    return (
      <svg viewBox="0 0 80 50" className="w-full h-12">
        <path
          d="M5 10 L25 25 L40 30 L55 35 L75 45"
          stroke="#6366F1"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    )
  }

  return (
    <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-3.5 hover:border-indigo-500 dark:hover:border-blue-500 hover:shadow-md cursor-pointer transition-all bg-white dark:bg-gray-800 h-full flex flex-col group">
      <div className="mb-3 flex items-center justify-center h-12 flex-shrink-0 bg-gray-50 dark:bg-gray-700 rounded-md p-2 group-hover:bg-indigo-50/30 dark:group-hover:bg-blue-900/30 transition-colors">
        {getChartPath()}
      </div>
      <p className="text-xs font-medium text-center text-gray-800 dark:text-gray-200 line-clamp-2 min-h-[2.5rem] flex items-center justify-center leading-tight group-hover:text-indigo-600 dark:group-hover:text-blue-400 transition-colors">
        {name}
      </p>
    </div>
  )
}

