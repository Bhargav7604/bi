import React, { useState, useEffect, useMemo, useCallback } from "react"
import { Link, useLocation, useSearchParams } from "react-router-dom"
import { Search, User, Menu, X } from "lucide-react"
import { Input } from "@components/ui/input"
import { ThemeToggle } from "@components/ThemeToggle"

interface HeaderProps {
  activeNav?: string
  onNavChange?: (nav: string) => void
}

function Header({ activeNav: propActiveNav, onNavChange }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [showSearch, setShowSearch] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const location = useLocation()
  const [searchParams] = useSearchParams()

  // Keep header completely stable - prevent any shifts
  useEffect(() => {
    const header = document.querySelector('header[class*="fixed"]') as HTMLElement
    if (!header) return
    
    // Force header to stay at viewport edges
    const enforceStability = () => {
      header.style.position = 'fixed'
      header.style.top = '0'
      header.style.left = '0'
      header.style.right = '0'
      header.style.width = '100%'
      header.style.marginLeft = '0'
      header.style.marginRight = '0'
      header.style.paddingLeft = '0'
      header.style.paddingRight = '0'
      header.style.transform = 'translateX(0)'
      header.style.boxSizing = 'border-box'
    }
    
    // Enforce on mount
    enforceStability()
    
    // Monitor for any changes that might affect header position
    const observer = new MutationObserver(() => {
      enforceStability()
    })
    
    // Observe body for padding/style changes
    observer.observe(document.body, {
      attributes: true,
      attributeFilter: ['style', 'class'],
      attributeOldValue: true
    })
    
    // Observe header itself to prevent unwanted changes
    observer.observe(header, {
      attributes: true,
      attributeFilter: ['style'],
      attributeOldValue: true
    })
    
    // Also monitor window resize
    const handleResize = () => {
      enforceStability()
    }
    window.addEventListener('resize', handleResize)
    
    // Periodic check to ensure stability (fallback)
    const stabilityCheck = setInterval(enforceStability, 100)
    
    return () => {
      observer.disconnect()
      window.removeEventListener('resize', handleResize)
      clearInterval(stabilityCheck)
    }
  }, [])

  // Memoize active nav calculation
  const activeNav = useMemo(() => {
    if (propActiveNav) return propActiveNav
    const path = location.pathname
    
    // If on performance page, check the 'from' parameter to determine active tab
    if (path === "/performance") {
      const fromParam = searchParams.get("from")
      if (fromParam === "discover") return "discover"
      if (fromParam === "home") return "home"
      if (fromParam === "my-strategy") return "my-strategy"
      if (fromParam === "create-strategy") return "create-strategy"
    }
    
    // Check pathname for other pages
    if (path === "/" || path === "/home") return "home"
    if (path === "/discover") return "discover"
    if (path === "/create-strategy") return "create-strategy"
    if (path === "/my-strategy") return "my-strategy"
    return "home"
  }, [propActiveNav, location.pathname, searchParams])

  // Memoize nav items - static data
  const navItems = useMemo(() => [
    { id: "home", label: "Home", path: "/" },
    { id: "discover", label: "Discover Strategy", path: "/discover" },
    { id: "create-strategy", label: "Create Strategy", path: "/create-strategy" },
    { id: "my-strategy", label: "My Strategy", path: "/my-strategy" },
  ], [])

  // Memoize search handler
  const handleSearch = useCallback((query: string) => {
    const currentPath = location.pathname
    
    // Store search query in sessionStorage for the current page to use
    sessionStorage.setItem('globalSearchQuery', query)
    sessionStorage.setItem('globalSearchPath', currentPath)
    
    // Trigger search event that pages can listen to
    window.dispatchEvent(new CustomEvent('globalSearch', { detail: { query, path: currentPath } }))
  }, [location.pathname])

  // Memoize search input change handler
  const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value
    setSearchQuery(query)
    handleSearch(query)
  }, [handleSearch])

  // Handle keyboard shortcut (Ctrl/Cmd + K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault()
        setShowSearch(true)
      }
      if (e.key === 'Escape' && showSearch) {
        setShowSearch(false)
        setSearchQuery("")
        handleSearch("")
      }
    }
    
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [showSearch])

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 shadow-sm">
      <div className="max-w-[1600px] mx-auto px-8 sm:px-12 lg:px-28 py-2 flex items-center justify-between relative">
        {/* Logo */}
        <div className="flex items-center flex-shrink-0">
          <img src="/images/bigullogo.png" alt="Bigul Logo" className="h-6 w-auto dark:brightness-0 dark:invert dark:contrast-200" />
        </div>

        {/* Desktop Navigation - Centered */}
        <nav className="hidden md:flex items-center gap-5 absolute left-1/2 -translate-x-1/2">
          {navItems.map((item) => (
            <Link
              key={item.id}
              to={item.path}
              onClick={() => {
                onNavChange?.(item.id)
                setIsOpen(false)
              }}
              className="font-medium text-xs transition border-b-2 hover:text-[#5266FC] dark:hover:text-blue-400 group cursor-pointer dark:text-gray-300"
              style={{
                color: activeNav === item.id ? (document.documentElement.classList.contains('dark') ? "#60A5FA" : "#5266FC") : undefined,
                borderColor: activeNav === item.id ? (document.documentElement.classList.contains('dark') ? "#60A5FA" : "#5266FC") : "transparent",
                paddingBottom: "4px",
                textDecoration: "none",
              }}
              onMouseEnter={(e) => {
                if (activeNav !== item.id) {
                  const isDark = document.documentElement.classList.contains('dark')
                  e.currentTarget.style.color = isDark ? "#60A5FA" : "#5266FC"
                  e.currentTarget.style.borderColor = isDark ? "#60A5FA" : "#5266FC"
                }
              }}
              onMouseLeave={(e) => {
                if (activeNav !== item.id) {
                  e.currentTarget.style.color = ""
                  e.currentTarget.style.borderColor = "transparent"
                }
              }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Right Icons */}
        <div className="flex items-center gap-2 md:gap-4 ml-auto">
          {showSearch ? (
            <div className="flex items-center gap-2 hidden sm:flex">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500" />
                <Input
                  type="text"
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={handleSearchChange}
                  onBlur={() => {
                    if (!searchQuery.trim()) {
                      setShowSearch(false)
                    }
                  }}
                  className="pl-8 pr-3 py-1.5 w-48 text-sm border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white focus:border-[#5266FC] dark:focus:border-[#7C8AFF] focus:ring-[#5266FC] dark:focus:ring-[#7C8AFF]"
                  autoFocus
                />
              </div>
              <button
                onClick={() => {
                  setShowSearch(false)
                  setSearchQuery("")
                  handleSearch("")
                }}
                className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-800 rounded transition"
                aria-label="Close search"
              >
                <X size={16} className="text-gray-600 dark:text-blue-400" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowSearch(true)}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition hidden sm:flex items-center justify-center bg-[#E8EAFF] dark:bg-gray-800"
              aria-label="Search"
            >
              <Search size={18} className="text-gray-600 dark:text-blue-400" />
            </button>
          )}
          <ThemeToggle />
          <Link
            to="/profile"
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition hidden sm:flex items-center justify-center bg-[#E8EAFF] dark:bg-gray-800"
            aria-label="User account"
          >
            <User size={18} className="text-gray-600 dark:text-blue-400" />
          </Link>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition"
            aria-label="Toggle menu"
          >
            {isOpen ? <X size={20} className="text-gray-600 dark:text-blue-400" /> : <Menu size={20} className="text-gray-600 dark:text-blue-400" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800">
          <nav className="flex flex-col gap-2 px-8 sm:px-12 py-4">
            {navItems.map((item) => (
              <Link
                key={item.id}
                to={item.path}
                onClick={() => {
                  onNavChange?.(item.id)
                  setIsOpen(false)
                }}
                className="font-medium py-2 border-b-2 transition cursor-pointer dark:text-gray-300"
                style={{
                  color: activeNav === item.id ? (document.documentElement.classList.contains('dark') ? "#60A5FA" : "#5266FC") : undefined,
                  borderColor: activeNav === item.id ? (document.documentElement.classList.contains('dark') ? "#60A5FA" : "#5266FC") : "transparent",
                  textDecoration: "none",
                }}
              >
                {item.label}
              </Link>
            ))}
            <div className="flex gap-4 pt-4 border-t border-gray-200 dark:border-gray-800">
              {showSearch ? (
                <div className="flex-1 flex items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500" />
                    <Input
                      type="text"
                      placeholder="Search..."
                      value={searchQuery}
                      onChange={handleSearchChange}
                      className="pl-9 pr-3 py-2 w-full text-sm border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white focus:border-[#5266FC] dark:focus:border-[#7C8AFF] focus:ring-[#5266FC] dark:focus:ring-[#7C8AFF]"
                      autoFocus
                    />
                  </div>
                  <button
                    onClick={() => {
                      setShowSearch(false)
                      setSearchQuery("")
                      handleSearch("")
                    }}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded transition"
                  >
                    <X size={18} className="text-gray-600 dark:text-blue-400" />
                  </button>
                </div>
              ) : (
                <>
                  <button 
                    onClick={() => {
                      setShowSearch(true)
                      setIsOpen(false)
                    }}
                    className="flex-1 px-4 py-2 rounded-lg transition bg-[#E8EAFF] dark:bg-gray-800" 
                  >
                    <Search size={18} className="text-gray-600 dark:text-blue-400" />
                  </button>
                  <div className="flex-1">
                    <ThemeToggle />
                  </div>
                </>
              )}
              <Link to="/profile" className="flex-1 px-4 py-2 rounded-lg transition flex items-center justify-center bg-[#E8EAFF] dark:bg-gray-800">
                <User size={18} className="text-gray-600 dark:text-blue-400" />
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}

// Memoize Header to prevent unnecessary re-renders
export default React.memo(Header)
