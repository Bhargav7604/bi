"use client"

import { useState, useMemo, useEffect } from "react"
import { X, TrendingUp, TrendingDown, Calendar as CalendarIcon } from "lucide-react"
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@components/ui/dialog"
import { Calendar } from "@components/ui/calendar"
import { Button } from "@components/ui/button"

interface ReportsLegDto {
  legId: number
  signalId: number | null
  date: number
  exchange: string
  underlying: number | null
  quantity: number
  price: number
  sequentialPNL: number | null
  instrument: number
}

interface ReportsSignalDTO {
  signalId: number | null
  pnl: number
  pnlChange: number
  sequentialPNL: number
  orderCount: number | null
  reportsLegDtoList: ReportsLegDto[]
  date: string
}

interface BacktestReportData {
  strategyName: string
  strategyID: number
  reportsSignalDTOs: ReportsSignalDTO[]
  totalOrders: number | null
  totalPNL: number
}

interface BacktestResultsModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  data: BacktestReportData | null
  loading: boolean
}

// Format date from "DD-MM-YYYY" to Date object
const parseDateString = (dateStr: string): Date | null => {
  try {
    const [day, month, year] = dateStr.split("-").map(Number)
    return new Date(year, month - 1, day)
  } catch {
    return null
  }
}

// Format currency
const formatCurrency = (value: number | null | undefined): string => {
  if (value == null) return "₹0"
  const formatted = value.toLocaleString("en-IN", { maximumFractionDigits: 2 })
  return `₹${formatted}`
}

// Format timestamp to readable time
// Timestamp appears to be in seconds with fractional nanoseconds (e.g., 1765512901.839365000)
const formatTimestamp = (timestamp: number): string => {
  try {
    // Convert seconds to milliseconds
    const date = new Date(timestamp * 1000)
    const hours = String(date.getHours()).padStart(2, '0')
    const minutes = String(date.getMinutes()).padStart(2, '0')
    const seconds = String(date.getSeconds()).padStart(2, '0')
    return `${hours}:${minutes}:${seconds}`
  } catch {
    return "--"
  }
}

export function BacktestResultsModal({ open, onOpenChange, data, loading }: BacktestResultsModalProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined)

  // Reset selected date when modal closes
  useEffect(() => {
    if (!open) {
      setSelectedDate(undefined)
    }
  }, [open])

  // Parse dates and create date-to-signal mapping
  const dateToSignalMap = useMemo(() => {
    if (!data?.reportsSignalDTOs) return new Map<string, ReportsSignalDTO>()
    
    const map = new Map<string, ReportsSignalDTO>()
    data.reportsSignalDTOs.forEach((signal) => {
      const date = parseDateString(signal.date)
      if (date) {
        const dateKey = date.toISOString().split('T')[0]
        map.set(dateKey, signal)
      }
    })
    return map
  }, [data])

  // Get dates with signals for calendar highlighting
  const datesWithSignals = useMemo(() => {
    return Array.from(dateToSignalMap.keys()).map(key => {
      const date = new Date(key)
      return date
    })
  }, [dateToSignalMap])

  // Get selected signal
  const selectedSignal = useMemo(() => {
    if (!selectedDate) return null
    const dateKey = selectedDate.toISOString().split('T')[0]
    return dateToSignalMap.get(dateKey) || null
  }, [selectedDate, dateToSignalMap])

  // Set first date as selected by default
  useEffect(() => {
    if (datesWithSignals.length > 0 && !selectedDate) {
      setSelectedDate(datesWithSignals[0])
    }
  }, [datesWithSignals, selectedDate])

  // Custom day modifier for calendar
  const modifiers = {
    hasSignal: (date: Date) => {
      const dateKey = date.toISOString().split('T')[0]
      return dateToSignalMap.has(dateKey)
    },
    positivePNL: (date: Date) => {
      const dateKey = date.toISOString().split('T')[0]
      const signal = dateToSignalMap.get(dateKey)
      return signal ? signal.pnl > 0 : false
    },
    negativePNL: (date: Date) => {
      const dateKey = date.toISOString().split('T')[0]
      const signal = dateToSignalMap.get(dateKey)
      return signal ? signal.pnl < 0 : false
    },
  }

  const modifiersClassNames = {
    hasSignal: "border-2 border-[#5266FC]",
    positivePNL: "bg-green-50 dark:bg-green-900/20",
    negativePNL: "bg-red-50 dark:bg-red-900/20",
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col p-0">
        <DialogTitle className="px-6 pt-5 pb-3 border-b border-gray-200 bg-gray-50 dark:bg-gray-800">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Backtest Results</h2>
              {data && (
                <DialogDescription className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  {data.strategyName} (ID: {data.strategyID})
                </DialogDescription>
              )}
            </div>
            {data && (
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-xs text-gray-500 dark:text-gray-400">Total P&L</p>
                  <p className={`text-lg font-bold ${data.totalPNL >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                    {formatCurrency(data.totalPNL)}
                  </p>
                </div>
              </div>
            )}
          </div>
        </DialogTitle>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-10 h-10 border-4 border-[#5266FC] border-t-transparent rounded-full animate-spin mb-4" />
            <span className="text-base text-gray-600 dark:text-gray-400">Loading backtest results...</span>
          </div>
        ) : data ? (
          <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
            {/* Left Side - Calendar View */}
            <div className="w-full md:w-1/3 border-r border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 p-4 overflow-y-auto">
              <div className="flex items-center gap-2 mb-4">
                <CalendarIcon className="w-5 h-5 text-[#5266FC]" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Performance Snapshot</h3>
              </div>
              
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                modifiers={modifiers}
                modifiersClassNames={modifiersClassNames}
                className="rounded-md border"
              />

              {/* Legend */}
              <div className="mt-4 space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-green-50 dark:bg-green-900/20 border border-green-300 dark:border-green-700 rounded"></div>
                  <span className="text-gray-600 dark:text-gray-400">Positive P&L</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-red-50 dark:bg-red-900/20 border border-red-300 dark:border-red-700 rounded"></div>
                  <span className="text-gray-600 dark:text-gray-400">Negative P&L</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-[#5266FC] rounded"></div>
                  <span className="text-gray-600 dark:text-gray-400">Has Trading Signals</span>
                </div>
              </div>
            </div>

            {/* Right Side - Trading Signals */}
            <div className="w-full md:w-2/3 bg-gray-50 dark:bg-gray-800 p-6 overflow-y-auto">
              {selectedSignal ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                      Trading Signals - {selectedSignal.date}
                    </h3>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-xs text-gray-500 dark:text-gray-400">Daily P&L</p>
                        <p className={`text-base font-bold ${selectedSignal.pnl >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                          {selectedSignal.pnl >= 0 ? <TrendingUp className="w-4 h-4 inline mr-1" /> : <TrendingDown className="w-4 h-4 inline mr-1" />}
                          {formatCurrency(selectedSignal.pnl)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-500 dark:text-gray-400">Cumulative P&L</p>
                        <p className={`text-base font-bold ${selectedSignal.sequentialPNL >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                          {formatCurrency(selectedSignal.sequentialPNL)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Legs Table */}
                  <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead className="bg-gray-100 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                          <tr>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase">Time</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase">Instrument</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase">Quantity</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase">Price</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase">Leg ID</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                          {selectedSignal.reportsLegDtoList.map((leg, index) => (
                            <tr key={leg.legId || index} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                              <td className="px-4 py-3 text-sm text-gray-900 dark:text-gray-100">
                                {formatTimestamp(leg.date)}
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-900 dark:text-gray-100 font-mono">
                                {leg.instrument}
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-900 dark:text-gray-100">
                                {leg.quantity}
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-900 dark:text-gray-100">
                                {formatCurrency(leg.price)}
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-500 dark:text-gray-400 font-mono">
                                {leg.legId}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-16 text-gray-400">
                  <CalendarIcon className="w-16 h-16 mb-4 opacity-40" />
                  <p className="text-base font-medium text-gray-600 dark:text-gray-400">Select a date to view trading signals</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <CalendarIcon className="w-16 h-16 mb-4 opacity-40" />
            <p className="text-base font-medium text-gray-600 dark:text-gray-400">No backtest data available</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

