"use client"

import { Input } from "@components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@components/ui/select"
import { Switch } from "@components/ui/switch"
import { X } from "lucide-react"
import type { StrategyLegState } from "@/lib/api/types"

interface StrategyLegProps {
  legNumber: number
  leg: StrategyLegState
  onChange: (leg: StrategyLegState) => void
  onRemove?: () => void
  dropdownList?: {
    expiry?: Array<{ key: string; val: string }>
    strikeSelection?: Array<{ key: string; val: string }>
    strikeType?: Array<{ key: string; val: string }>
    [key: string]: unknown
  }
}

export function StrategyLeg({ 
  legNumber, 
  leg, 
  onChange, 
  onRemove,
  dropdownList 
}: StrategyLegProps) {
  const isOption = leg.derivativeType === "OPTION"
  const isFuture = leg.derivativeType === "FUTURE"

  const updateLeg = (updates: Partial<StrategyLegState>) => {
    onChange({ ...leg, ...updates })
  }

  return (
    <div className="mb-3 bg-white dark:bg-gray-800 rounded-sm p-4 relative">
      {onRemove && (
        <button
          onClick={onRemove}
          className="absolute top-2 right-2 text-gray-400 dark:text-gray-500 hover:text-red-600 dark:hover:text-red-400 transition-colors"
        >
          <X className="h-4 w-4" />
        </button>
      )}
      <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-3 text-sm">Leg #{legNumber}</h3>

      {/* Row 1 - Main Fields */}
      <div className={`grid ${isOption ? 'grid-cols-7' : 'grid-cols-5'} gap-x-3 gap-y-3 mb-3`}>
        <div>
          <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Strategy Type</label>
          <div className="inline-flex rounded-sm border border-[#BFC5FF] dark:border-gray-600 overflow-hidden w-full">
            <button
              onClick={() => updateLeg({ derivativeType: "OPTION", optionType: leg.optionType || "Ce" })}
              className={`py-1.5 px-3 text-xs font-medium transition-colors flex-1 ${
                isOption ? "bg-indigo-600 dark:bg-blue-500 text-white" : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
              }`}
            >
              OPTIONS
            </button>
            <button
              onClick={() => updateLeg({ derivativeType: "FUTURE", optionType: null })}
              className={`py-1.5 px-3 text-xs font-medium transition-colors flex-1 ${
                isFuture ? "bg-indigo-600 dark:bg-blue-500 text-white" : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
              }`}
            >
              FUTURES
            </button>
          </div>
        </div>

        <div>
          <label className="text-xs text-gray-500 mb-1 block">Position</label>
          <div className="inline-flex rounded-sm border border-[#BFC5FF] dark:border-gray-600 overflow-hidden w-full">
            <button
              onClick={() => updateLeg({ position: "Buy" })}
              className={`py-1.5 px-3 text-xs font-medium transition-colors flex-1 ${
                leg.position === "Buy" ? "bg-[#019900] dark:bg-green-500 text-white" : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
              }`}
            >
              BUY
            </button>
            <button
              onClick={() => updateLeg({ position: "Sell" })}
              className={`py-1.5 px-3 text-xs font-medium transition-colors flex-1 ${
                leg.position === "Sell" ? "bg-emerald-500 dark:bg-emerald-400 text-white" : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
              }`}
            >
              SELL
            </button>
          </div>
        </div>

        {isOption && (
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Option Type</label>
            <div className="inline-flex rounded-sm border border-[#BFC5FF] dark:border-gray-600 overflow-hidden w-full">
              <button
                onClick={() => updateLeg({ optionType: "Ce" })}
                className={`py-1.5 px-3 text-xs font-medium transition-colors flex-1 ${
                  leg.optionType === "Ce" ? "bg-indigo-600 dark:bg-blue-500 text-white" : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                }`}
              >
                CALL
              </button>
              <button
                onClick={() => updateLeg({ optionType: "Pe" })}
                className={`py-1.5 px-3 text-xs font-medium transition-colors flex-1 ${
                  leg.optionType === "Pe" ? "bg-indigo-600 dark:bg-blue-500 text-white" : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                }`}
              >
                PUT
              </button>
            </div>
          </div>
        )}

        <div>
          <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Lots</label>
          <Select value={leg.lots} onValueChange={(val) => updateLeg({ lots: val })}>
            <SelectTrigger className="h-9 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-blue-400 text-[#5266FC] text-sm w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => (
                <SelectItem key={n} value={n.toString()}>
                  {n}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Expiry</label>
          <Select 
            value={leg.expiry} 
            onValueChange={(val) => updateLeg({ expiry: val })}
          >
            <SelectTrigger className="h-9 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-blue-400 text-[#5266FC] text-sm w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {dropdownList?.expiry?.map((item) => (
                <SelectItem key={item.key} value={item.key}>
                  {item.val}
                </SelectItem>
              )) || (
                <>
                  <SelectItem value="CurrentWeek">Current Week</SelectItem>
                  <SelectItem value="NextWeek">Next Week</SelectItem>
                  <SelectItem value="CurrentMonth">Current Month</SelectItem>
                  <SelectItem value="NextMonth">Next Month</SelectItem>
                </>
              )}
            </SelectContent>
          </Select>
        </div>

        {isOption ? (
          <>
            <div>
              <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Strike Selection</label>
              <Select 
                value={leg.strikeSelection || ""} 
                onValueChange={(val) => {
                  updateLeg({ 
                    strikeSelection: val,
                    strikeSelectionValue: val ? "null" : ""
                  })
                }}
              >
                <SelectTrigger className="h-9 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-blue-400 text-[#5266FC] text-sm w-full">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  {dropdownList?.strikeSelection?.map((item) => (
                    <SelectItem key={item.key} value={item.key}>
                      {item.val}
                    </SelectItem>
                  )) || (
                    <>
                      <SelectItem value="SpotAtm">Spot ATM</SelectItem>
                      <SelectItem value="FutureAtm">Future ATM</SelectItem>
                      <SelectItem value="SyntheticAtm">Synthetic ATM</SelectItem>
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Strike Type</label>
              <Select 
                value={leg.strikeType || ""} 
                onValueChange={(val) => updateLeg({ strikeType: val || null })}
              >
                <SelectTrigger className="h-9 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-blue-400 text-[#5266FC] text-sm w-full">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  {dropdownList?.strikeType?.map((item) => (
                    <SelectItem key={item.key} value={item.key}>
                      {item.val}
                    </SelectItem>
                  )) || (
                    <>
                      <SelectItem value="ATM">ATM</SelectItem>
                      <SelectItem value="ITM">ITM</SelectItem>
                      <SelectItem value="OTM">OTM</SelectItem>
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>
          </>
        ) : null}
      </div>

      {/* Row 2 - Target, Stoploss, TSL, Trailing Distance */}
      <div className="grid grid-cols-4 gap-x-3 items-end">
        {/* Target */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Switch
              checked={leg.tgtToogle === "true"}
              onCheckedChange={(checked) => updateLeg({ tgtToogle: checked ? "true" : "false" })}
            />
            <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">Target</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Select
              value={leg.tgtType}
              onValueChange={(val) => updateLeg({ tgtType: val })}
              disabled={leg.tgtToogle !== "true"}
            >
              <SelectTrigger className="h-9 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-blue-400 text-[#5266FC] text-sm flex-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Amount">Amount</SelectItem>
                <SelectItem value="Percent">Percent</SelectItem>
              </SelectContent>
            </Select>
            <Input
              type="number"
              value={leg.tgtValue}
              onChange={(e) => updateLeg({ tgtValue: Number(e.target.value) || 0 })}
              className="h-9 w-16 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-blue-400 text-center text-[#5266FC] text-sm"
              disabled={leg.tgtToogle !== "true"}
            />
          </div>
        </div>

        {/* Stoploss */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Switch
              checked={leg.stopLossToggle === "true"}
              onCheckedChange={(checked) => updateLeg({ stopLossToggle: checked ? "true" : "false" })}
            />
            <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">Stoploss</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Select
              value={leg.stopLossType}
              onValueChange={(val) => updateLeg({ stopLossType: val })}
              disabled={leg.stopLossToggle !== "true"}
            >
              <SelectTrigger className="h-9 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-blue-400 text-[#5266FC] text-sm flex-1">
                <SelectValue placeholder="Select" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Percent">Percent</SelectItem>
                <SelectItem value="Amount">Amount</SelectItem>
              </SelectContent>
            </Select>
            <Input
              type="number"
              value={leg.stopLossValue}
              onChange={(e) => updateLeg({ stopLossValue: Number(e.target.value) || 0 })}
              className="h-9 w-16 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-blue-400 text-center text-[#5266FC] text-sm"
              disabled={leg.stopLossToggle !== "true"}
            />
          </div>
        </div>

        {/* TSL */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Switch
              checked={leg.tslToggle}
              onCheckedChange={(checked) => updateLeg({ tslToggle: checked })}
            />
            <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">TSL</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Select
              value={leg.tslType || ""}
              onValueChange={(val) => updateLeg({ tslType: val })}
              disabled={!leg.tslToggle}
            >
              <SelectTrigger className="h-9 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-blue-400 text-[#5266FC] text-sm flex-1">
                <SelectValue placeholder="Select" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Percent">Percent</SelectItem>
                <SelectItem value="Amount">Amount</SelectItem>
              </SelectContent>
            </Select>
            <Input
              type="number"
              value={leg.tslValue}
              onChange={(e) => updateLeg({ tslValue: Number(e.target.value) || 0 })}
              className="h-9 w-16 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-blue-400 text-center text-[#5266FC] text-sm"
              disabled={!leg.tslToggle}
            />
          </div>
        </div>

        {/* Trailing Distance */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs text-gray-500 whitespace-nowrap">Trailing Distance</span>
          </div>
          <Input
            type="number"
            value={leg.tdValue}
            onChange={(e) => updateLeg({ tdValue: Number(e.target.value) || 0 })}
            className="h-9 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-blue-400 text-center text-[#5266FC] text-sm w-20"
          />
        </div>
      </div>
    </div>
  )
}
