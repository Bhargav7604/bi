"use client"

import { useState, useEffect, useCallback, useMemo } from "react"
import { X, Download, Search, Loader2, TrendingUp, TrendingDown } from "lucide-react"
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@components/ui/dialog"
import { Input } from "@components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@components/ui/select"
import { Button } from "@components/ui/button"
import { reportsService } from "@/lib/api/reports.service"

// Date formatting helper
const formatDateString = (date: string | number | Date | null): string => {
  if (!date) return "--"
  try {
    let d: Date

    if (typeof date === "string" && date.includes("-")) {
      const parts = date.split(" ")
      const datePart = parts[0]
      const timePart = parts[1] || "00:00:00"

      const [day, month, year] = datePart.split("-").map(Number)
      const [hours, minutes] = timePart.split(":").map(Number)

      d = new Date(year, month - 1, day, hours || 0, minutes || 0, 0)
    } else {
      d = new Date(date)
    }

    if (isNaN(d.getTime())) return "--"
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const day = d.getDate().toString().padStart(2, "0")
    const month = months[d.getMonth()]
    const year = d.getFullYear()
    const hours = d.getHours().toString().padStart(2, "0")
    const minutes = d.getMinutes().toString().padStart(2, "0")
    return `${day} ${month} ${year} ${hours}:${minutes}`
  } catch {
    return "--"
  }
}

const formatDateOnly = (date: string | number | Date | null): string => {
  if (!date) return "--"
  try {
    const d = new Date(date)
    if (isNaN(d.getTime())) return "--"
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const day = d.getDate().toString().padStart(2, "0")
    const month = months[d.getMonth()]
    const year = d.getFullYear()
    return `${day} ${month} ${year}`
  } catch {
    return "--"
  }
}

const formatCurrency = (value: number | null | undefined): string => {
  if (value == null) return "₹0"
  return `₹${value.toLocaleString("en-IN")}`
}

export interface TradeRow {
  symbol: string
  status: string
  qty: number | string
  ltp: string
  entryPrice: string
  entryTime: string
  exitPrice: string
  exitTime: string
  indexEntry: string
  indexNowExit: string
  baseIV: string
  liveIV: string
  baseDelta: string
  liveDelta: string
  pnl: string
}

export interface StrategyData {
  name?: string
  status?: string
  execution?: string
  deployedOn?: string | Date
  capital?: number
  multiplier?: string
  strategyMtm?: number
}

export interface StrategyDetails {
  status?: string
  execution?: string
  deployedOn?: string | Date
  capital?: number
  multiplier?: string
  strategyLegTableDTO?: {
    totalOrders?: number
    openOrders?: number
    closedOrders?: number
    strategyMTM?: number
    data?: any[]
  }
}

interface TradeDetailsModalProps {
  open: boolean
  onClose: () => void
  strategyId: number
  strategyName: string
  strategyData: any
}

export default function TradeDetailsModal({
  open,
  onClose,
  strategyId,
  strategyName,
  strategyData,
}: TradeDetailsModalProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [tableData, setTableData] = useState<TradeRow[]>([])
  const [searchSymbol, setSearchSymbol] = useState("")
  const [statusFilter, setStatusFilter] = useState("All")
  const [strategyDetails, setStrategyDetails] = useState<StrategyDetails | null>(null)
  const [downloading, setDownloading] = useState(false)

  const fetchTradeDetails = useCallback(async () => {
    if (!strategyId) return
    
    setIsLoading(true)
    try {
      const response = await reportsService.getStrategyDetails({ strategyId })
      const data = response?.data
      
      const strategy = Array.isArray(data) 
        ? data[0] 
        : (data as any)?.detailedStrategyResponse || (data as any)?.data || data
      
      if (strategy) {
        setStrategyDetails(strategy as StrategyDetails)
        
        if (strategy.strategyLegTableDTO?.data) {
          const mappedData: TradeRow[] = strategy.strategyLegTableDTO.data.map((row: any) => {
            // Check if we have quantity data - use legQuantity if available and > 0, otherwise use lots
            let qtyValue: number | string = "--"
            if (row.legQuantity != null && row.legQuantity !== undefined && row.legQuantity > 0) {
              qtyValue = row.legQuantity
            } else if (row.lots != null && row.lots !== undefined && row.lots > 0) {
              qtyValue = row.lots
            } else if (row.legQuantity === 0 || row.lots === 0) {
              qtyValue = 0
            }
            
            return {
              symbol: row.name || "--",
              status: row.exitPrice != null && row.exitPrice !== "" ? "Closed" : "Open",
              qty: qtyValue,
              ltp: row.legLTP != null && row.legLTP !== undefined ? row.legLTP.toFixed(2) : "--",
              entryPrice: row.executedPrice != null && row.executedPrice !== undefined ? row.executedPrice.toFixed(2) : "--",
              entryTime: row.deployedTimeStamp ? formatDateString(row.deployedTimeStamp) : "--",
              exitPrice: row.exitPrice != null && row.exitPrice !== undefined && row.exitPrice !== "" ? row.exitPrice.toFixed(2) : "--",
              exitTime: row.exitTime != null && row.exitTime !== undefined && row.exitTime !== "" ? formatDateString(row.exitTime) : "--",
              indexEntry: row.indexBasePrice != null && row.indexBasePrice !== undefined ? row.indexBasePrice.toFixed(2) : "--",
              indexNowExit: row.indexCurrentPrice != null && row.indexCurrentPrice !== undefined ? row.indexCurrentPrice.toFixed(2) : "--",
              baseIV: row.constantIV != null && row.constantIV !== undefined ? row.constantIV.toFixed(2) : "--",
              liveIV: row.currentIV != null && row.currentIV !== undefined ? row.currentIV.toFixed(2) : "--",
              baseDelta: row.constantDelta != null && row.constantDelta !== undefined ? row.constantDelta.toFixed(2) : "--",
              liveDelta: row.currentDelta != null && row.currentDelta !== undefined ? row.currentDelta.toFixed(2) : "--",
              pnl: row.pandL != null && row.pandL !== undefined ? parseFloat(row.pandL.toString()).toFixed(2) : "0.00",
            }
          })
          setTableData(mappedData)
        }
      }
    } catch (error) {
      console.error("Error fetching trade details:", error)
    } finally {
      setIsLoading(false)
    }
  }, [strategyId])

  useEffect(() => {
    if (open && strategyId) {
      fetchTradeDetails()
    } else if (!open) {
      setSearchSymbol("")
      setStatusFilter("All")
      setTableData([])
      setStrategyDetails(null)
    }
  }, [open, strategyId, fetchTradeDetails])

  const filteredData = useMemo(() => {
    let filtered = tableData

    if (searchSymbol) {
      filtered = filtered.filter((row) => row.symbol?.toLowerCase().includes(searchSymbol.toLowerCase()))
    }

    if (statusFilter !== "All") {
      filtered = filtered.filter((row) => row.status === statusFilter)
    }

    return filtered
  }, [tableData, searchSymbol, statusFilter])

  const handleDownload = async () => {
    if (downloading || tableData.length === 0) return
    setDownloading(true)
    try {
      const headers = [
        "Symbol",
        "Status",
        "Qty",
        "LTP",
        "Entry Price",
        "Entry Time",
        "Exit Price",
        "Exit Time",
        "Index Entry",
        "Index Now/Exit",
        "Base IV",
        "Live IV",
        "Base Delta",
        "Live Delta",
        "P&L",
      ]
      const csvRows = [
        headers.join(","),
        ...filteredData.map((row) =>
          [
            row.symbol || "--",
            row.status || "--",
            row.qty || "--",
            row.ltp || "--",
            row.entryPrice || "--",
            row.entryTime || "--",
            row.exitPrice || "--",
            row.exitTime || "--",
            row.indexEntry || "--",
            row.indexNowExit || "--",
            row.baseIV || "--",
            row.liveIV || "--",
            row.baseDelta || "--",
            row.liveDelta || "--",
            row.pnl || "0.00",
          ].join(","),
        ),
      ]

      const csvContent = csvRows.join("\n")
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
      const link = document.createElement("a")
      const url = URL.createObjectURL(blob)
      link.setAttribute("href", url)
      link.setAttribute("download", `${strategyName || "Strategy"} ${new Date().toISOString().split("T")[0]}.csv`)
      link.style.visibility = "hidden"
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } catch (error) {
      console.error("Error downloading trade details:", error)
    } finally {
      setDownloading(false)
    }
  }

  // Calculate orders - use API data if available, otherwise calculate from tableData
  const totalOrdersFromAPI = strategyDetails?.strategyLegTableDTO?.totalOrders
  const dataArrayLength = (strategyDetails?.strategyLegTableDTO as any)?.data?.length
  const totalOrders = totalOrdersFromAPI != null && totalOrdersFromAPI !== undefined 
    ? totalOrdersFromAPI 
    : (dataArrayLength != null ? dataArrayLength : tableData.length)
  
  const openOrdersFromAPI = strategyDetails?.strategyLegTableDTO?.openOrders
  const openOrders = openOrdersFromAPI != null && openOrdersFromAPI !== undefined
    ? openOrdersFromAPI
    : tableData.filter((r) => r.status === "Open").length
  
  const closedOrdersFromAPI = strategyDetails?.strategyLegTableDTO?.closedOrders
  const closedOrders = closedOrdersFromAPI != null && closedOrdersFromAPI !== undefined
    ? closedOrdersFromAPI
    : tableData.filter((r) => r.status === "Closed").length
  
  const strategyMTM = strategyDetails?.strategyLegTableDTO?.strategyMTM ?? strategyData?.strategyMtm
  
  // Check if we have quantity data to show Qty column
  const hasQuantityData = tableData.some((row) => row.qty !== "--" && row.qty !== null && row.qty !== undefined)

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent 
        showCloseButton={false} 
        className="!max-w-[98vw] !w-[98vw] !h-[96vh] p-0 flex flex-col gap-0 overflow-hidden !rounded-xl border-2 border-gray-200 dark:border-gray-700 shadow-2xl bg-white dark:bg-gray-900"
      >
        <DialogTitle className="sr-only">Trade Details</DialogTitle>
        <DialogDescription className="sr-only">
          Detailed trade information for {strategyName || "the selected strategy"}
        </DialogDescription>
        
        {/* Header with gradient */}
        <div className="flex justify-between items-center p-4 bg-gradient-to-r from-blue-600 to-blue-500 dark:from-blue-700 dark:to-blue-600 text-white shrink-0">
          <div>
            <h2 className="text-xl font-bold text-white">Trade Details</h2>
            <p className="text-sm text-blue-100 dark:text-blue-200 mt-0.5">{strategyName || "Strategy Overview"}</p>
          </div>
          <div className="flex gap-2 items-center">
            {tableData.length > 0 && (
              <Button
                onClick={handleDownload}
                disabled={downloading}
                size="small"
                className="h-9 px-4 text-sm font-semibold bg-white hover:bg-blue-50 dark:bg-gray-800 dark:hover:bg-gray-700 text-blue-600 dark:text-blue-400 shadow-md"
              >
                {downloading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Downloading...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    Export CSV
                  </>
                )}
              </Button>
            )}
            <button 
              onClick={onClose} 
              className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Strategy Info Cards - Compact Grid */}
        <div className="grid grid-cols-5 gap-1.5 p-1.5 bg-gray-50 dark:bg-gray-800/50 border-b border-gray-200 dark:border-gray-700 shrink-0">
          <div className="bg-white dark:bg-gray-800 rounded p-1.5 border border-gray-200 dark:border-gray-700">
            <span className="text-[8px] font-medium text-gray-500 dark:text-gray-400 uppercase">Status</span>
            <p className="text-[9px] font-semibold text-gray-900 dark:text-gray-100 mt-0.5">
              {strategyData?.status || strategyDetails?.status || "--"}
            </p>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded p-1.5 border border-gray-200 dark:border-gray-700">
            <span className="text-[8px] font-medium text-gray-500 dark:text-gray-400 uppercase">Execution</span>
            <p className="text-[9px] font-semibold text-gray-900 dark:text-gray-100 mt-0.5">
              {(() => {
                const execution = strategyData?.execution || strategyDetails?.execution || "--"
                if (execution === "PaperTrading") return "Forward Test"
                if (execution === "LiveTrading") return "Live Trading"
                return execution
              })()}
            </p>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded p-1.5 border border-gray-200 dark:border-gray-700">
            <span className="text-[8px] font-medium text-gray-500 dark:text-gray-400 uppercase">Deployed</span>
            <p className="text-[9px] font-semibold text-gray-900 dark:text-gray-100 mt-0.5">
              {formatDateOnly(strategyData?.deployedOn || strategyDetails?.deployedOn)}
            </p>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded p-1.5 border border-gray-200 dark:border-gray-700">
            <span className="text-[8px] font-medium text-gray-500 dark:text-gray-400 uppercase">Capital</span>
            <p className="text-[9px] font-semibold text-gray-900 dark:text-gray-100 mt-0.5">
              {formatCurrency(strategyData?.capital || strategyDetails?.capital)}
            </p>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded p-1.5 border border-gray-200 dark:border-gray-700">
            <span className="text-[8px] font-medium text-gray-500 dark:text-gray-400 uppercase">Multiplier</span>
            <p className="text-[9px] font-semibold text-gray-900 dark:text-gray-100 mt-0.5">
              {strategyData?.multiplier || strategyDetails?.multiplier || "--"}
            </p>
          </div>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-4 gap-1.5 px-1.5 py-1.5 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 shrink-0">
          <div className="flex items-center gap-1.5 bg-blue-50 dark:bg-blue-900/20 rounded p-1.5 border border-blue-200 dark:border-blue-800">
            <div className="bg-blue-600 dark:bg-blue-500 rounded p-1">
              <div className="w-3 h-3 text-white font-bold flex items-center justify-center text-[8px]">T</div>
            </div>
            <div>
              <p className="text-[8px] text-gray-600 dark:text-gray-400 font-medium">Total</p>
              <p className="text-[10px] font-bold text-gray-900 dark:text-gray-100">{totalOrders != null ? totalOrders : 0}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 bg-green-50 dark:bg-green-900/20 rounded p-1.5 border border-green-200 dark:border-green-800">
            <div className="bg-green-600 dark:bg-green-500 rounded p-1">
              <div className="w-3 h-3 text-white font-bold flex items-center justify-center text-[8px]">O</div>
            </div>
            <div>
              <p className="text-[8px] text-gray-600 dark:text-gray-400 font-medium">Open</p>
              <p className="text-[10px] font-bold text-gray-900 dark:text-gray-100">{openOrders != null ? openOrders : 0}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 bg-gray-50 dark:bg-gray-800 rounded p-1.5 border border-gray-200 dark:border-gray-700">
            <div className="bg-gray-600 dark:bg-gray-500 rounded p-1">
              <div className="w-3 h-3 text-white font-bold flex items-center justify-center text-[8px]">C</div>
            </div>
            <div>
              <p className="text-[8px] text-gray-600 dark:text-gray-400 font-medium">Closed</p>
              <p className="text-[10px] font-bold text-gray-900 dark:text-gray-100">{closedOrders != null ? closedOrders : 0}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded p-1.5 border border-purple-200 dark:border-purple-800">
            <div className={`${(strategyMTM ?? 0) >= 0 ? 'bg-green-600 dark:bg-green-500' : 'bg-red-600 dark:bg-red-500'} rounded p-1`}>
              {(strategyMTM ?? 0) >= 0 ? 
                <TrendingUp className="w-3 h-3 text-white" /> : 
                <TrendingDown className="w-3 h-3 text-white" />
              }
            </div>
            <div>
              <p className="text-[8px] text-gray-600 dark:text-gray-400 font-medium">MTM</p>
              <p className={`text-[10px] font-bold ${(strategyMTM ?? 0) >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                {formatCurrency(strategyMTM)}
              </p>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-3 items-center px-4 py-3 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 shrink-0">
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500" />
            <Input
              placeholder="Search symbol..."
              value={searchSymbol}
              onChange={(e) => setSearchSymbol(e.target.value)}
              className="pl-10 h-10 text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100 focus:border-blue-500 dark:focus:border-blue-400 focus:ring-blue-500 dark:focus:ring-blue-400"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-10 w-36 text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
              <SelectItem value="All" className="dark:text-gray-100 dark:hover:bg-gray-700">All Status</SelectItem>
              <SelectItem value="Open" className="dark:text-gray-100 dark:hover:bg-gray-700">Open</SelectItem>
              <SelectItem value="Closed" className="dark:text-gray-100 dark:hover:bg-gray-700">Closed</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Table - Scrollable */}
        <div className="flex-1 overflow-auto px-4 pb-4">
          <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden shadow-sm bg-white dark:bg-gray-800">
            <table className="w-full text-[9px]">
              <thead className="bg-gray-100 dark:bg-gray-700 sticky top-0 z-10 border-b border-gray-200 dark:border-gray-600">
                <tr>
                  <th className="px-1.5 py-1.5 text-left font-semibold text-gray-700 dark:text-gray-300">Symbol</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">Status</th>
                  {hasQuantityData && (
                    <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">Qty</th>
                  )}
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">LTP</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">Entry</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">Entry Time</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">Exit</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">Exit Time</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">Index Entry</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">Index Exit</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">Base IV</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">Live IV</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">Base Δ</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">Live Δ</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold text-gray-700 dark:text-gray-300">P&L</th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800">
                {isLoading ? (
                  <tr>
                    <td colSpan={hasQuantityData ? 15 : 14} className="px-4 py-12 text-center">
                      <div className="flex flex-col items-center gap-2">
                        <Loader2 className="w-6 h-6 animate-spin text-blue-600 dark:text-blue-400" />
                        <span className="text-[9px] text-gray-600 dark:text-gray-400 font-medium">Loading trade details...</span>
                      </div>
                    </td>
                  </tr>
                ) : filteredData.length === 0 ? (
                  <tr>
                    <td colSpan={hasQuantityData ? 15 : 14} className="px-4 py-12 text-center text-gray-500 dark:text-gray-400">
                      <div className="flex flex-col items-center gap-1">
                        <div className="text-2xl">📊</div>
                        <p className="text-[9px] font-medium">No trades found</p>
                        <p className="text-[8px]">Try adjusting your filters</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  filteredData.map((row, index) => {
                    const pnlValue = Number.parseFloat(row.pnl || "0")
                    const pnlColor = pnlValue >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"
                    const pnlBg = pnlValue >= 0 ? "bg-green-50 dark:bg-green-900/20" : "bg-red-50 dark:bg-red-900/20"
                    return (
                      <tr key={index} className="border-b border-gray-100 dark:border-gray-700 hover:bg-blue-50/30 dark:hover:bg-gray-700/50 transition-colors">
                        <td className="px-1.5 py-1.5 text-left font-medium text-gray-900 dark:text-gray-100 truncate max-w-[120px]" title={row.symbol || "--"}>{row.symbol || "--"}</td>
                        <td className="px-1.5 py-1.5 text-center">
                          <span
                            className={`inline-flex items-center px-1.5 py-0.5 rounded-full text-[8px] font-semibold ${
                              row.status === "Open" 
                                ? "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 border border-green-300 dark:border-green-700" 
                                : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600"
                            }`}
                          >
                            {row.status || "--"}
                          </span>
                        </td>
                        {hasQuantityData && (
                          <td className="px-1.5 py-1.5 text-center font-medium text-gray-700 dark:text-gray-300 tabular-nums">
                            {row.qty !== undefined && row.qty !== null && row.qty !== "--" ? row.qty : "--"}
                          </td>
                        )}
                        <td className="px-1.5 py-1.5 text-center font-medium text-gray-900 dark:text-gray-100 tabular-nums">{row.ltp || "--"}</td>
                        <td className="px-1.5 py-1.5 text-center font-medium text-gray-900 dark:text-gray-100 tabular-nums">{row.entryPrice || "--"}</td>
                        <td className="px-1.5 py-1.5 text-center text-gray-600 dark:text-gray-400 tabular-nums text-[8px]">{row.entryTime || "--"}</td>
                        <td className="px-1.5 py-1.5 text-center font-medium text-gray-900 dark:text-gray-100 tabular-nums">{row.exitPrice || "--"}</td>
                        <td className="px-1.5 py-1.5 text-center text-gray-600 dark:text-gray-400 tabular-nums text-[8px]">{row.exitTime || "--"}</td>
                        <td className="px-1.5 py-1.5 text-center text-gray-700 dark:text-gray-300 tabular-nums">{row.indexEntry || "--"}</td>
                        <td className="px-1.5 py-1.5 text-center text-gray-700 dark:text-gray-300 tabular-nums">{row.indexNowExit || "--"}</td>
                        <td className="px-1.5 py-1.5 text-center text-gray-700 dark:text-gray-300 tabular-nums">{row.baseIV || "--"}</td>
                        <td className="px-1.5 py-1.5 text-center text-gray-700 dark:text-gray-300 tabular-nums">{row.liveIV || "--"}</td>
                        <td className="px-1.5 py-1.5 text-center text-gray-700 dark:text-gray-300 tabular-nums">{row.baseDelta || "--"}</td>
                        <td className="px-1.5 py-1.5 text-center text-gray-700 dark:text-gray-300 tabular-nums">{row.liveDelta || "--"}</td>
                        <td className={`px-1.5 py-1.5 text-center font-semibold tabular-nums ${pnlColor}`}>
                          <span className={`inline-block px-1.5 py-0.5 rounded ${pnlBg}`}>
                            ₹{row.pnl || "0.00"}
                          </span>
                        </td>
                      </tr>
                    )
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}