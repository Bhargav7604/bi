"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@components/ui/button"
import { Input } from "@components/ui/input"
import { Checkbox } from "@components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@components/ui/select"
import { Switch } from "@components/ui/switch"
import { Loader2, Menu } from "lucide-react"
import { StrategyTemplateCard } from "@components/strategy-template-card"
import { StrategyLeg } from "@components/strategy-leg"
import { strategyService } from "@/lib/api/strategy.service"
import { useAuthStore } from "@/store/auth.store"
import type { ReadyToDeployStrategy, StrategyLegState, StrategyLegRequest } from "@/lib/api/types"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@components/ui/sheet"
import CustomDatePicker from "@components/ui/custom-datepicker"

// Module-level cache to persist across StrictMode remounts
// This ensures API calls are only made once even if component remounts
const createStrategyApiCache = {
  prebuilt: new Map<string, boolean>(),
  saved: new Map<string, boolean>(),
  isFetching: {
    prebuilt: false,
    saved: false,
  }
}

export default function CreateStrategy() {
  const [activeTab, setActiveTab] = useState<"templates" | "saved">("templates")
  const [selectedStrategy, setSelectedStrategy] = useState<ReadyToDeployStrategy | null>(null)
  const [saving, setSaving] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  
  // Form state
  const [strategyName, setStrategyName] = useState("")
  const [index, setIndex] = useState("1")
  const [capital, setCapital] = useState(600000)
  const [entryHours, setEntryHours] = useState(9)
  const [entryMinutes, setEntryMinutes] = useState(45)
  const [strategyType, setStrategyType] = useState("Intraday")
  const [executionType, setExecutionType] = useState("LiveTrading")
  const [entryDays, setEntryDays] = useState({ Mon: true, Tue: false, Wed: false, Thu: false, Fri: false })
  const [exitHours, setExitHours] = useState(14)
  const [exitMinutes, setExitMinutes] = useState(55)
  const [exitOnExpiry, setExitOnExpiry] = useState("Yes")
  const [exitAfterEntryDays, setExitAfterEntryDays] = useState(4)
  const [profitMtmEnabled, setProfitMtmEnabled] = useState(true)
  const [profitMtmType, setProfitMtmType] = useState("PercentOfCapital")
  const [profitMtmValue, setProfitMtmValue] = useState(50)
  const [stoplossMtmEnabled, setStoplossMtmEnabled] = useState(true)
  const [stoplossMtmType, setStoplossMtmType] = useState("PercentOfCapital")
  const [stoplossMtmValue, setStoplossMtmValue] = useState(50)
  
  // Strategy legs state
  const [legs, setLegs] = useState<StrategyLegState[]>([
    {
      position: "Buy",
      optionType: null,
      expiry: "CurrentMonth",
      lots: "1",
      strikeSelection: "",
      strikeType: null,
      strikeSelectionValue: "",
      tgtToogle: "true",
      tgtType: "Amount",
      tgtValue: 250,
      stopLossToggle: "true",
      stopLossType: "Percent",
      stopLossValue: 15,
      tslType: "",
      tslValue: 0,
      tslToggle: false,
      tdValue: 0,
      derivativeType: "FUTURE"
    },
    {
      position: "Buy",
      optionType: "Pe",
      expiry: "NextWeek",
      lots: "1",
      strikeSelection: "SpotAtm",
      strikeType: "ATM",
      strikeSelectionValue: "null",
      tgtToogle: "true",
      tgtType: "Amount",
      tgtValue: 1200,
      stopLossToggle: "true",
      stopLossType: "Percent",
      stopLossValue: 10,
      tslType: "",
      tslValue: 0,
      tslToggle: false,
      tdValue: 0,
      derivativeType: "OPTION"
    }
  ])
  
  // Prebuilt strategies state
  const [prebuiltStrategies, setPrebuiltStrategies] = useState<ReadyToDeployStrategy[]>([])
  const [loadingPrebuilt, setLoadingPrebuilt] = useState(false)
  const [dropdownList, setDropdownList] = useState<any>(null)
  
  // Saved DIY strategies state
  const [savedStrategies, setSavedStrategies] = useState<ReadyToDeployStrategy[]>([])
  const [loadingSaved, setLoadingSaved] = useState(false)
  
  const { token, isAuthenticated } = useAuthStore()
  
  // Refs to prevent duplicate API calls
  const prebuiltFetchedRef = useRef(false)
  const isFetchingPrebuiltRef = useRef(false)
  const savedFetchedRef = useRef<string | null>(null)
  const isFetchingSavedRef = useRef(false)
  
  // Fetch prebuilt strategies - only once on mount
  const fetchPrebuiltStrategies = useCallback(async () => {
    const cacheKey = `prebuilt-${token ? 'authenticated' : 'unauthenticated'}`
    
    // Prevent duplicate calls - check module-level cache first (works with StrictMode)
    if (createStrategyApiCache.prebuilt.has(cacheKey) || createStrategyApiCache.isFetching.prebuilt) {
      return
    }
    
    if (!token || !isAuthenticated) {
      return
    }
    
    // Set fetching flag in both ref and cache
    isFetchingPrebuiltRef.current = true
    createStrategyApiCache.isFetching.prebuilt = true
    setLoadingPrebuilt(true)
    
    try {
      const response = await strategyService.getReadyToDeployStrategies("prebuilt")
      
      if (response.success && response.data) {
        const responseData = response.data as any
        const strategiesObj = responseData.strategies || responseData.data?.strategies || {}
        const dropdowns = responseData.dropdownList || responseData.data?.dropdownList || null
        
        setDropdownList(dropdowns)
        
        if (strategiesObj["preBuilt"] && Array.isArray(strategiesObj["preBuilt"])) {
          setPrebuiltStrategies(strategiesObj["preBuilt"])
        } else if (strategiesObj["prebuilt"] && Array.isArray(strategiesObj["prebuilt"])) {
          setPrebuiltStrategies(strategiesObj["prebuilt"])
        } else {
          setPrebuiltStrategies([])
        }
        
        prebuiltFetchedRef.current = true
        createStrategyApiCache.prebuilt.set(cacheKey, true)
      }
    } catch (error) {
      console.error("❌ CreateStrategy: Error fetching prebuilt strategies:", error)
    } finally {
      setLoadingPrebuilt(false)
      isFetchingPrebuiltRef.current = false
      createStrategyApiCache.isFetching.prebuilt = false
    }
  }, [token, isAuthenticated])
  
  // Fetch prebuilt strategies only once on mount - no useEffect dependency on callback
  useEffect(() => {
    if (token && isAuthenticated && !prebuiltFetchedRef.current) {
      fetchPrebuiltStrategies()
    }
  }, [token, isAuthenticated]) // Removed fetchPrebuiltStrategies dependency

  // Fetch saved DIY strategies - only when tab changes to saved
  const fetchSavedStrategies = useCallback(async () => {
    const fetchKey = `saved-${token ? 'authenticated' : 'unauthenticated'}`
    const cacheKey = `saved-${token ? 'authenticated' : 'unauthenticated'}`
    
    // Prevent duplicate calls - check module-level cache first (works with StrictMode)
    if (createStrategyApiCache.saved.has(cacheKey) || createStrategyApiCache.isFetching.saved) {
      return
    }
    
    if (!token || !isAuthenticated) {
      return
    }
    
    // Set fetching flag in both ref and cache
    isFetchingSavedRef.current = true
    createStrategyApiCache.isFetching.saved = true
    setLoadingSaved(true)
    
    try {
      const response = await strategyService.getReadyToDeployStrategies("diy")
      
      if (response.success && response.data) {
        const responseData = response.data as any
        const strategiesObj = responseData.strategies || responseData.data?.strategies || {}
        
        // Check for diy, DIY, or any case variation
        const diyStrategies = 
          (strategiesObj["diy"] && Array.isArray(strategiesObj["diy"]) ? strategiesObj["diy"] : null) ||
          (strategiesObj["DIY"] && Array.isArray(strategiesObj["DIY"]) ? strategiesObj["DIY"] : null) ||
          (strategiesObj["Diy"] && Array.isArray(strategiesObj["Diy"]) ? strategiesObj["Diy"] : null) ||
          []
        
        setSavedStrategies(diyStrategies.length > 0 ? diyStrategies : [])
        savedFetchedRef.current = fetchKey
        createStrategyApiCache.saved.set(cacheKey, true)
      } else {
        setSavedStrategies([])
      }
    } catch (error) {
      console.error("❌ CreateStrategy: Error fetching saved DIY strategies:", error)
      setSavedStrategies([])
    } finally {
      setLoadingSaved(false)
      isFetchingSavedRef.current = false
      createStrategyApiCache.isFetching.saved = false
    }
  }, [token, isAuthenticated])

  // Fetch saved strategies only when tab changes to saved - no dependency on callback
  useEffect(() => {
    if (activeTab === "saved" && token && isAuthenticated) {
      fetchSavedStrategies()
    } else if (activeTab !== "saved") {
      // Reset when switching away from saved tab
      savedFetchedRef.current = null
    }
  }, [activeTab, token, isAuthenticated]) // Removed fetchSavedStrategies dependency

  // Handle prebuilt strategy selection
  const handleStrategySelect = (strategy: ReadyToDeployStrategy) => {
    setSelectedStrategy(strategy)
    setSidebarOpen(false) // Close sidebar on mobile after selection
    
    // Populate form with strategy data
    setStrategyName(strategy.name || "")
    setIndex(String(strategy.underlying || "1"))
    setCapital(strategy.minCapital || 600000)
    setStrategyType(strategy.positionType || "Intraday")
    setExecutionType(strategy.executionType || "LiveTrading")
    
    // Entry details
    if (strategy.entryDetails) {
      const entry = strategy.entryDetails
      if (entry.entryHourTime !== undefined) setEntryHours(entry.entryHourTime)
      if (entry.entryMinsTime !== undefined) setEntryMinutes(entry.entryMinsTime)
      
      // Map entry days
      if (entry.entryDaysList && Array.isArray(entry.entryDaysList)) {
        const daysMap: { Mon: boolean; Tue: boolean; Wed: boolean; Thu: boolean; Fri: boolean } = {
          Mon: entry.entryDaysList.includes(1),
          Tue: entry.entryDaysList.includes(2),
          Wed: entry.entryDaysList.includes(3),
          Thu: entry.entryDaysList.includes(4),
          Fri: entry.entryDaysList.includes(5),
        }
        setEntryDays(daysMap)
      }
    }
    
    // Exit details
    if (strategy.exitDetails) {
      const exit = strategy.exitDetails
      if (exit.exitHourTime !== undefined) setExitHours(exit.exitHourTime)
      if (exit.exitMinsTime !== undefined) setExitMinutes(exit.exitMinsTime)
      if (exit.exitOnExpiryFlag) setExitOnExpiry(exit.exitOnExpiryFlag)
      if (exit.exitAfterEntryDays !== undefined) setExitAfterEntryDays(exit.exitAfterEntryDays)
      
      if (exit.targetUnitToggle === "true") {
        setProfitMtmEnabled(true)
        if (exit.targetUnitType) setProfitMtmType(exit.targetUnitType)
        if (exit.targetUnitValue !== undefined) setProfitMtmValue(exit.targetUnitValue)
      } else {
        setProfitMtmEnabled(false)
      }
      
      if (exit.stopLossUnitToggle === "true") {
        setStoplossMtmEnabled(true)
        if (exit.stopLossUnitType) setStoplossMtmType(exit.stopLossUnitType)
        if (exit.stopLossUnitValue !== undefined) setStoplossMtmValue(exit.stopLossUnitValue)
      } else {
        setStoplossMtmEnabled(false)
      }
    }
  }

  // Handle add leg
  const handleAddLeg = () => {
    const newLeg: StrategyLegState = {
      position: "Buy",
      optionType: "Ce",
      expiry: "CurrentWeek",
      lots: "1",
      strikeSelection: "SpotAtm",
      strikeType: "ATM",
      strikeSelectionValue: "null",
      tgtToogle: "true",
      tgtType: "Amount",
      tgtValue: 0,
      stopLossToggle: "false",
      stopLossType: "Percent",
      stopLossValue: 0,
      tslType: "",
      tslValue: 0,
      tslToggle: false,
      tdValue: 0,
      derivativeType: "OPTION"
    }
    setLegs([...legs, newLeg])
  }

  // Handle remove leg
  const handleRemoveLeg = (index: number) => {
    if (legs.length > 1) {
      setLegs(legs.filter((_, i) => i !== index))
    }
  }

  // Handle leg update
  const handleLegUpdate = (index: number, updatedLeg: StrategyLegState) => {
    const newLegs = [...legs]
    newLegs[index] = updatedLeg
    setLegs(newLegs)
  }

  // Handle save strategy
  const handleSaveStrategy = async () => {
    if (!strategyName.trim()) {
      return
    }

    if (legs.length === 0) {
      return
    }

    if (!token || !isAuthenticated) {
      return
    }

    setSaving(true)
    try {
      // Convert entry days to array format [1,2,3,4,5]
      const entryDaysArray: number[] = []
      if (entryDays.Mon) entryDaysArray.push(1)
      if (entryDays.Tue) entryDaysArray.push(2)
      if (entryDays.Wed) entryDaysArray.push(3)
      if (entryDays.Thu) entryDaysArray.push(4)
      if (entryDays.Fri) entryDaysArray.push(5)

      if (entryDaysArray.length === 0) {
        setSaving(false)
        return
      }

      // Convert legs to API format
      const legsRequest: StrategyLegRequest[] = legs.map(leg => ({
        position: leg.position,
        optionType: leg.optionType,
        expiry: leg.expiry,
        lots: leg.lots,
        strikeSelection: leg.strikeSelection,
        strikeType: leg.strikeType,
        strikeSelectionValue: leg.strikeSelectionValue || (leg.strikeSelection ? "null" : ""),
        tgtToogle: leg.tgtToogle,
        tgtType: leg.tgtType,
        tgtValue: leg.tgtValue,
        stopLossToggle: leg.stopLossToggle,
        stopLossType: leg.stopLossType,
        stopLossValue: leg.stopLossValue,
        tslType: leg.tslType || "",
        tslValue: leg.tslValue,
        tslToggle: leg.tslToggle,
        tdValue: leg.tdValue,
        derivativeType: leg.derivativeType,
      }))

      const request = {
        strategyId: selectedStrategy?.id || null,
        strategyName: strategyName.trim(),
        index: index,
        executionTypeId: executionType,
        capital: capital,
        strategyType: strategyType,
        entryHours: entryHours,
        entryMinutes: entryMinutes,
        entryOnDays: entryDaysArray,
        exitHours: exitHours,
        exitMinutes: exitMinutes,
        exitOnExpiry: exitOnExpiry,
        exitAfterEntryDays: exitAfterEntryDays,
        targetMtmToggle: profitMtmEnabled ? "true" : "false",
        targetMtmType: profitMtmType,
        targetMtmValue: profitMtmValue,
        stopLossMtmToggle: stoplossMtmEnabled ? "true" : "false",
        stopLossMtmType: stoplossMtmType,
        stopLossMtmValue: stoplossMtmValue,
        legs: legsRequest,
      }

      console.log("📡 CreateStrategy: Saving strategy:", request)
      const response = await strategyService.saveDIYStrategy(request)

      if (response.success) {
        // Reset form
        setSelectedStrategy(null)
        setStrategyName("")
        setLegs([
          {
            position: "Buy",
            optionType: null,
            expiry: "CurrentMonth",
            lots: "1",
            strikeSelection: "",
            strikeType: null,
            strikeSelectionValue: "",
            tgtToogle: "true",
            tgtType: "Amount",
            tgtValue: 250,
            stopLossToggle: "true",
            stopLossType: "Percent",
            stopLossValue: 15,
            tslType: "",
            tslValue: 0,
            tslToggle: false,
            tdValue: 0,
            derivativeType: "FUTURE"
          }
        ])
      }
    } catch (error) {
      console.error("❌ CreateStrategy: Error saving strategy:", error)
    } finally {
      setSaving(false)
    }
  }

  // Helper to format time
  const formatTime = (hours: number, minutes: number) => {
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`
  }

  // Sidebar content component
  const SidebarContent = () => {
    if (activeTab === "saved") {
      return (
        <div className="w-full bg-white dark:bg-gray-800 rounded-sm p-4">
          <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-3 text-sm">My Saved Strategies</h3>
          <div className="grid grid-cols-2 gap-2">
            {loadingSaved ? (
              <div className="col-span-2 flex items-center justify-center py-4">
                <Loader2 className="w-5 h-5 animate-spin text-[#5266FC] dark:text-blue-400" />
                <span className="ml-2 text-sm text-gray-600 dark:text-gray-400">Loading saved strategies...</span>
              </div>
            ) : savedStrategies.length > 0 ? (
              savedStrategies.map((strategy, index) => (
                <div
                  key={strategy.id || index}
                  onClick={() => handleStrategySelect(strategy)}
                  className={`cursor-pointer transition-opacity rounded-sm h-full ${
                    selectedStrategy?.id === strategy.id ? "opacity-100 ring-2 ring-indigo-600" : "opacity-90 hover:opacity-100"
                  }`}
                >
                  <StrategyTemplateCard 
                    name={strategy.name || "Strategy"} 
                    type="buy-put" 
                  />
                </div>
              ))
            ) : (
              <div className="col-span-2 text-sm text-gray-500 dark:text-gray-400 text-center py-4">
                No saved strategies available
              </div>
            )}
          </div>
        </div>
      )
    }

    return (
      <div className="w-full bg-white dark:bg-gray-800 rounded-sm p-4">
        <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-3 text-sm">Easy Strategy Templates</h3>
        <div className="grid grid-cols-2 gap-2">
          {loadingPrebuilt ? (
            <div className="col-span-2 flex items-center justify-center py-4">
              <Loader2 className="w-5 h-5 animate-spin text-[#5266FC]" />
              <span className="ml-2 text-sm text-gray-600 dark:text-gray-400">Loading templates...</span>
            </div>
          ) : prebuiltStrategies.length > 0 ? (
            prebuiltStrategies.map((strategy, index) => (
              <div
                key={strategy.id || index}
                onClick={() => handleStrategySelect(strategy)}
                className={`cursor-pointer transition-opacity rounded-sm h-full ${
                  selectedStrategy?.id === strategy.id ? "opacity-100 ring-2 ring-indigo-600" : "opacity-90 hover:opacity-100"
                }`}
              >
                <StrategyTemplateCard 
                  name={strategy.name || "Strategy"} 
                  type="buy-put" 
                />
              </div>
            ))
          ) : (
            <div className="col-span-2 text-sm text-gray-500 dark:text-gray-400 text-center py-4">
              No templates available
            </div>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#F5F5F5] dark:bg-gray-950 pt-16 sm:pt-20 md:pt-24 pb-12 font-sans">
      <div className="max-w-[1600px] mx-auto px-8 sm:px-12 lg:px-28">
      {/* Header */}
      <div className="mb-4">
        <h1 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-gray-100">Build Custom Strategy</h1>
        <p className="text-gray-500 dark:text-gray-400 mt-0.5 text-xs sm:text-sm">
          Customize entry logic, legs, and exit conditions for complete algorithmic control.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-between mb-4">
        <div className="bg-white dark:bg-gray-800 rounded-sm p-1 flex items-center gap-1 flex-1 sm:flex-initial overflow-x-auto">
          <button
            onClick={() => setActiveTab("templates")}
            className={`px-3 sm:px-4 py-2 text-xs sm:text-sm font-medium rounded-sm transition whitespace-nowrap ${
              activeTab === "templates" ? "bg-[#5266FC] dark:bg-blue-500 text-white" : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
            }`}
          >
            Easy Strategy Templates
          </button>
          <button
            onClick={() => setActiveTab("saved")}
            className={`px-3 sm:px-4 py-2 text-xs sm:text-sm font-medium rounded-sm transition whitespace-nowrap ${
              activeTab === "saved" ? "bg-[#5266FC] dark:bg-blue-500 text-white" : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
            }`}
          >
            My Saved Strategies
          </button>
        </div>
        {/* Mobile menu button */}
        <button
          onClick={() => setSidebarOpen(true)}
          className="md:hidden ml-2 p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-sm"
        >
          <Menu className="h-5 w-5" />
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        {/* Left Sidebar - Templates (Desktop) */}
        <div className="hidden md:block w-56 shrink-0">
          <SidebarContent />
        </div>

        {/* Mobile Sidebar Sheet */}
        <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
          <SheetContent side="left" className="w-[280px] sm:w-[320px]">
            <SheetHeader>
              <SheetTitle>{activeTab === "saved" ? "My Saved Strategies" : "Strategy Templates"}</SheetTitle>
            </SheetHeader>
            <div className="mt-4">
              <SidebarContent />
            </div>
          </SheetContent>
        </Sheet>

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {/* Step 1: Entry Settings */}
          <div className="mb-4">
            <h2 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-3">Step 1: Entry Settings</h2>
            <div className="bg-white dark:bg-gray-800 rounded-sm p-3 sm:p-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-3">
                <div>
                  <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Strategy Name</label>
                  <Input
                    value={strategyName}
                    onChange={(e) => setStrategyName(e.target.value)}
                    placeholder="Protective Put"
                    className="h-9 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100 placeholder:text-[#5266FC] dark:placeholder:text-blue-400 text-[#5266FC] dark:text-blue-400 text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Index</label>
                  <Select value={index} onValueChange={setIndex}>
                    <SelectTrigger className="h-9 border-[#BFC5FF] dark:border-gray-600 dark:bg-gray-800 dark:text-blue-400 text-[#5266FC] text-sm">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      {dropdownList?.underlying?.map((item: any) => (
                        <SelectItem key={item.key} value={String(item.key)}>
                          {item.val}
                        </SelectItem>
                      )) || (
                        <>
                          <SelectItem value="1">NIFTY</SelectItem>
                          <SelectItem value="2">BANKNIFTY</SelectItem>
                          <SelectItem value="3">FINNIFTY</SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Capital</label>
                  <Input
                    type="number"
                    value={capital}
                    onChange={(e) => setCapital(Number(e.target.value))}
                    className="h-9 border-[#BFC5FF] text-[#5266FC] text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Entry Time (HH:MM)</label>
                  <CustomDatePicker
                    type="time"
                    value={formatTime(entryHours, entryMinutes)}
                    onChange={(e) => {
                      const timeValue = e.target.value
                      if (timeValue) {
                        const [hours, minutes] = timeValue.split(':').map(Number)
                        setEntryHours(hours || 9)
                        setEntryMinutes(minutes || 45)
                      }
                    }}
                    className="h-9 w-full border border-[#BFC5FF] dark:border-gray-600 rounded-sm text-[#5266FC] dark:text-blue-400 text-sm focus:outline-none focus:ring-2 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20 dark:bg-gray-800"
                    text_font_size="7"
                    text_color="#5266FC"
                    fill_background_color="#ffffff"
                    border_border="1 solid #BFC5FF"
                    border_border_radius="3px"
                    padding="0.5rem,0.75rem"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 items-start">
                <div>
                  <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Strategy Type</label>
                  <div className="inline-flex rounded-sm border border-[#BFC5FF] overflow-hidden w-full sm:w-auto">
                    <button
                      onClick={() => setStrategyType("Intraday")}
                      className={`py-1.5 px-2 sm:px-3 text-xs font-medium transition-colors flex-1 ${
                        strategyType === "Intraday"
                          ? "bg-indigo-600 dark:bg-blue-500 text-white"
                          : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                      }`}
                    >
                      INTRADAY
                    </button>
                    <button
                      onClick={() => setStrategyType("Positional")}
                      className={`py-1.5 px-2 sm:px-3 text-xs font-medium transition-colors flex-1 ${
                        strategyType === "Positional"
                          ? "bg-indigo-600 dark:bg-blue-500 text-white"
                          : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                      }`}
                    >
                      POSITIONAL
                    </button>
                  </div>
                </div>
                <div>
                  <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Execution Type</label>
                  <div className="inline-flex rounded-sm border border-[#BFC5FF] overflow-hidden w-full sm:w-auto">
                    <button
                      onClick={() => setExecutionType("LiveTrading")}
                      className={`py-1.5 px-2 sm:px-3 text-xs font-medium transition-colors flex-1 whitespace-nowrap ${
                        executionType === "LiveTrading"
                          ? "bg-indigo-600 dark:bg-blue-500 text-white"
                          : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                      }`}
                    >
                      LIVE TRADING
                    </button>
                    <button
                      onClick={() => setExecutionType("PaperTrading")}
                      className={`py-1.5 px-2 sm:px-3 text-xs font-medium transition-colors flex-1 whitespace-nowrap ${
                        executionType === "PaperTrading"
                          ? "bg-indigo-600 dark:bg-blue-500 text-white"
                          : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                      }`}
                    >
                      FORWARD TEST
                    </button>
                  </div>
                </div>
                <div>
                  <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Enter on Days</label>
                  <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                    {Object.entries(entryDays).map(([day, checked]) => (
                      <label key={day} className="flex items-center gap-1 cursor-pointer">
                        <Checkbox
                          checked={checked}
                          onCheckedChange={(val) => setEntryDays((prev) => ({ ...prev, [day]: !!val }))}
                          className="h-4 w-4 border-gray-300 dark:border-gray-600 dark:bg-gray-800 data-[state=checked]:bg-indigo-600 dark:data-[state=checked]:bg-blue-500 data-[state=checked]:border-indigo-600 dark:data-[state=checked]:border-blue-500"
                        />
                        <span className="text-xs sm:text-sm text-gray-700 dark:text-gray-300">{day}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Step 2: Strategy Legs */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-gray-900 dark:text-gray-100">Step 2: Strategy Legs</h2>
              <button 
                onClick={handleAddLeg}
                className="text-indigo-600 dark:text-blue-400 font-medium hover:underline text-xs"
              >
                +Add Leg
              </button>
            </div>

            {legs.map((leg, index) => (
              <StrategyLeg
                key={index}
                legNumber={index + 1}
                leg={leg}
                onChange={(updatedLeg) => handleLegUpdate(index, updatedLeg)}
                onRemove={legs.length > 1 ? () => handleRemoveLeg(index) : undefined}
                dropdownList={dropdownList}
              />
            ))}
          </div>

          {/* Step 3: Exit Settings */}
          <div className="mb-4 bg-white dark:bg-gray-800 rounded-sm p-3 sm:p-4">
            <h2 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-3">Step 3: Exit Settings</h2>

            {/* Responsive Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
              <div className="min-w-0">
                <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Exit Time (HH:MM)</label>
                <CustomDatePicker
                  type="time"
                  value={formatTime(exitHours, exitMinutes)}
                  onChange={(e) => {
                    const timeValue = e.target.value
                    if (timeValue) {
                      const [hours, minutes] = timeValue.split(':').map(Number)
                      setExitHours(hours || 14)
                      setExitMinutes(minutes || 55)
                    }
                  }}
                  className="h-9 w-full border border-[#BFC5FF] dark:border-gray-600 rounded-sm text-[#5266FC] dark:text-blue-400 text-sm focus:outline-none focus:ring-2 focus:ring-[#5266FC]/20 dark:focus:ring-blue-500/20 dark:bg-gray-800"
                  text_font_size="7"
                  text_color="#5266FC"
                  fill_background_color="#ffffff"
                  border_border="1 solid #BFC5FF"
                  border_border_radius="3px"
                  padding="0.5rem,0.75rem"
                />
              </div>
              <div className="min-w-0">
                <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Exit On Expiry</label>
                <Select value={exitOnExpiry} onValueChange={setExitOnExpiry}>
                  <SelectTrigger className="h-9 border-[#BFC5FF] text-[#5266FC] text-sm w-full">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Yes">Yes</SelectItem>
                    <SelectItem value="No">No</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="min-w-0">
                <label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">Exit After Entry +Days</label>
                <Select value={String(exitAfterEntryDays)} onValueChange={(val) => setExitAfterEntryDays(Number(val))}>
                  <SelectTrigger className="h-9 border-[#BFC5FF] text-[#5266FC] text-sm w-full">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4, 5].map((n) => (
                      <SelectItem key={n} value={n.toString()}>
                        {n}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Profit MTM */}
              <div className="min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <Switch
                    checked={profitMtmEnabled}
                    onCheckedChange={setProfitMtmEnabled}
                  />
                  <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">Profit MTM</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Select
                    value={profitMtmType}
                    onValueChange={setProfitMtmType}
                    disabled={!profitMtmEnabled}
                  >
                    <SelectTrigger className="h-9 border-[#BFC5FF] text-[#5266FC] text-sm min-w-0 flex-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PercentOfCapital">% of Capital</SelectItem>
                      <SelectItem value="Amount">Amount</SelectItem>
                    </SelectContent>
                  </Select>
                  <Input
                    type="number"
                    value={profitMtmValue}
                    onChange={(e) => setProfitMtmValue(Number(e.target.value))}
                    className="h-9 w-14 border-[#BFC5FF] text-center text-[#5266FC] text-sm flex-shrink-0"
                    disabled={!profitMtmEnabled}
                  />
                </div>
              </div>

              {/* Stoploss MTM */}
              <div className="min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <Switch
                    checked={stoplossMtmEnabled}
                    onCheckedChange={setStoplossMtmEnabled}
                  />
                  <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">Stoploss MTM</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Select
                    value={stoplossMtmType}
                    onValueChange={setStoplossMtmType}
                    disabled={!stoplossMtmEnabled}
                  >
                    <SelectTrigger className="h-9 border-[#BFC5FF] text-[#5266FC] text-sm min-w-0 flex-1">
                      <SelectValue placeholder="Select here" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PercentOfCapital">% of Capital</SelectItem>
                      <SelectItem value="Amount">Amount</SelectItem>
                    </SelectContent>
                  </Select>
                  <Input
                    type="number"
                    value={stoplossMtmValue}
                    onChange={(e) => setStoplossMtmValue(Number(e.target.value))}
                    className="h-9 w-14 border-[#BFC5FF] text-center text-[#5266FC] text-sm flex-shrink-0"
                    disabled={!stoplossMtmEnabled}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row justify-end gap-2 mb-6">
            <Button
              variant="outline"
              onClick={() => {
                setSelectedStrategy(null)
                setStrategyName("")
              }}
              className="w-full sm:w-auto px-6 h-9 bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 font-medium text-sm"
            >
              CANCEL
            </Button>
            <Button
              onClick={handleSaveStrategy}
              disabled={saving}
              className="w-full sm:w-auto bg-indigo-600 dark:bg-blue-500 hover:bg-indigo-700 dark:hover:bg-blue-600 text-white px-5 h-9 font-medium text-sm disabled:opacity-50"
            >
              {saving ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin inline" />
                  SAVING...
                </>
              ) : (
                "SAVE STRATEGY"
              )}
            </Button>
          </div>
        </div>
      </div>
      </div>
    </div>
  )
}
