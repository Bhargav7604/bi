import React, { useState, useMemo, useRef, useCallback } from "react"
import { Search, HelpCircle, ChevronLeft, ChevronRight, Minus, Plus } from "lucide-react"
import { Slider } from "@components/ui/slider"
import { logger } from "@/lib/utils/logger"

interface TooltipData {
  x: number
  y: number
  price: number
  pnlTargetDate: number
  pnlExpiry: number
  percentChange: number
  pointChange: number
}

interface PayoffChartProps {
  strategyDetails?: any
  strategyLegs?: any[]
  strategyReports?: any
  currentPrice?: number
  basePrice?: number
}

function PayoffChart({ 
  strategyDetails, 
  strategyLegs, 
  strategyReports,
  currentPrice: propCurrentPrice,
  basePrice: propBasePrice 
}: PayoffChartProps = {}) {
  // Extract data from strategyReports if available (from API)
  const reportsData = useMemo(() => {
    if (!strategyReports?.reportsSignalDTOs || !Array.isArray(strategyReports.reportsSignalDTOs) || strategyReports.reportsSignalDTOs.length === 0) {
      return null
    }
    
    const signals = strategyReports.reportsSignalDTOs
    const latestSignal = signals[0] // Most recent signal
    const oldestSignal = signals[signals.length - 1] // Oldest signal
    
    const latestLegs = latestSignal?.reportsLegDtoList || []
    const oldestLegs = oldestSignal?.reportsLegDtoList || []
    
    // Calculate premium per unit from price/quantity
    const calculatePremiumPerUnit = (leg: any): number => {
      if (!leg || !leg.price || !leg.quantity || leg.quantity === 0) return 0
      // Price appears to be total contract value, so divide by quantity to get per-unit premium
      return Number(leg.price) / Number(leg.quantity)
    }
    
    // Calculate average premium from all legs
    const getAvgPremium = (legs: any[]): number => {
      if (!legs || legs.length === 0) return 0
      const premiums = legs.map(calculatePremiumPerUnit).filter(p => p > 0)
      if (premiums.length === 0) return 0
      const sum = premiums.reduce((a, b) => a + b, 0)
      return sum / premiums.length
    }
    
    const currentAvgPremium = getAvgPremium(latestLegs)
    const baseAvgPremium = getAvgPremium(oldestLegs) || currentAvgPremium
    
    // Estimate index price from option premiums
    // For Nifty options, typical premium range is 50-5000
    // Premium of 100 typically corresponds to underlying around 20000-25000
    // We'll use a multiplier based on premium range
    const estimateIndexPrice = (premium: number): number | null => {
      if (premium <= 0) return null
      // If premium is very high (>5000), it might be total contract value
      if (premium > 5000) {
        // Likely total value, estimate underlying
        return premium / 50 // Rough lot size adjustment
      }
      // For typical option premiums, estimate underlying
      // Conservative multiplier: premium * 200-250
      return premium * 220
    }
    
    const estimatedCurrentIndex = estimateIndexPrice(currentAvgPremium)
    const estimatedBaseIndex = estimateIndexPrice(baseAvgPremium) || estimatedCurrentIndex
    
    return {
      currentPrice: estimatedCurrentIndex,
      basePrice: estimatedBaseIndex || estimatedCurrentIndex,
      legs: latestLegs.map((leg: any) => ({
        ...leg,
        premium: calculatePremiumPerUnit(leg),
        pricePerUnit: calculatePremiumPerUnit(leg),
      }))
    }
  }, [strategyReports])
  
  // Use real data from props, then strategyDetails, then extracted from reports API
  // Priority: 1. Props, 2. strategyDetails API, 3. strategyReports API
  const currentPrice = propCurrentPrice 
    || strategyDetails?.indexCurrentPrice 
    || strategyDetails?.currentPrice
    || reportsData?.currentPrice
    
  const basePrice = propBasePrice 
    || strategyDetails?.indexBasePrice 
    || strategyDetails?.basePrice
    || reportsData?.basePrice
    
  // Use legs from strategyDetails API, or from strategyReports API if available
  const availableLegs = (strategyLegs && strategyLegs.length > 0) 
    ? strategyLegs 
    : (reportsData?.legs || [])
  
  
  // Extract strike prices and premiums from strategy legs if available
  // Try multiple possible field names from the API response
  const extractStrikeFromLeg = (leg: any): number | null => {
    if (!leg) return null
    // Try different possible field names
    if (leg.strike != null && leg.strike !== undefined) return Number(leg.strike)
    if (leg.strikePrice != null && leg.strikePrice !== undefined) return Number(leg.strikePrice)
    // Try to extract from name/tradedInstrument if it contains strike info
    if (leg.name) {
      const match = leg.name.match(/(\d+)/)
      if (match) return Number(match[1])
    }
    if (leg.tradedInstrument) {
      const match = leg.tradedInstrument.match(/(\d+)/)
      if (match) return Number(match[1])
    }
    return null
  }
  
  const extractPremiumFromLeg = (leg: any): number => {
    if (!leg) return 0
    // Try different possible field names for premium/entry price
    if (leg.premium != null && leg.premium !== undefined) return Number(leg.premium)
    if (leg.pricePerUnit != null && leg.pricePerUnit !== undefined) return Number(leg.pricePerUnit)
    if (leg.executedPrice != null && leg.executedPrice !== undefined) return Number(leg.executedPrice)
    if (leg.entryPrice != null && leg.entryPrice !== undefined) return Number(leg.entryPrice)
    if (leg.legLTP != null && leg.legLTP !== undefined) return Number(leg.legLTP)
    // For reports data, calculate from price/quantity
    if (leg.price != null && leg.quantity != null && leg.quantity > 0) {
      return Number(leg.price) / Number(leg.quantity)
    }
    return 0
  }
  
  // Get strike from first leg or strategy details
  const strikePrice = availableLegs && availableLegs.length > 0 
    ? extractStrikeFromLeg(availableLegs[0]) 
    : (strategyDetails?.strikePrice || strategyDetails?.strike || null)
  
  // Calculate total premium from all legs
  const premium = availableLegs && availableLegs.length > 0
    ? availableLegs.reduce((sum, leg) => {
        const legPremium = extractPremiumFromLeg(leg)
        const quantity = leg.legQuantity || leg.lots || leg.quantity || 1
        return sum + (legPremium * quantity)
      }, 0)
    : (strategyDetails?.premium || strategyDetails?.totalPremium || 0)
  
  // Initialize niftyTarget with currentPrice if available, otherwise will show no data message
  const [niftyTarget, setNiftyTarget] = useState(currentPrice || 0)
  const [targetPercent, setTargetPercent] = useState(0)
  const [dateSliderValue, setDateSliderValue] = useState([50])
  const [tooltip, setTooltip] = useState<TooltipData | null>(null)
  const [isZoomedOut, setIsZoomedOut] = useState(false)
  const chartRef = useRef<SVGSVGElement>(null)

  // Check if we have required data to render the chart
  // Priority: Use data from strategyReports API first, then strategyDetails API
  // We need at least currentPrice and basePrice, strike and premium can be estimated if missing
  const hasRequiredData = (currentPrice && basePrice && (currentPrice > 0) && (basePrice > 0)) 
    || (strategyReports?.reportsSignalDTOs && strategyReports.reportsSignalDTOs.length > 0 && reportsData)
  
  
  // Use basePrice as strike if strike is not available (for ATM strategies)
  const effectiveStrike = strikePrice || basePrice || currentPrice
  // Use a default premium estimate if not available (1% of base price as rough estimate)
  const effectivePremium = premium > 0 ? premium : (basePrice * 0.01)

  // Generate price range for x-axis based on real data
  const priceRange = useMemo(() => {
    if (!basePrice || !currentPrice) return []
    
    // Calculate range based on base price and current price
    const range = Math.max(Math.abs(basePrice - currentPrice) * 2, 2000) // At least 2000 point range
    const start = Math.max(0, Math.floor((basePrice - range) / 100) * 100)
    const end = Math.ceil((basePrice + range) / 100) * 100
    const step = 100
    const prices: number[] = []
    for (let i = start; i <= end; i += step) {
      prices.push(i)
    }
    return prices
  }, [isZoomedOut, basePrice, currentPrice])

  // Calculate P&L for expiry line (the angular red/green line)
  const calculateExpiryPnL = useCallback((price: number) => {
    // Use effective strike and premium
    if (!effectiveStrike || !effectivePremium) return 0
    
    const actualStrike = effectiveStrike
    const actualPremium = effectivePremium
    const lotSize = strategyDetails?.lotSize || 50

    if (price <= actualStrike) {
      return -actualPremium
    } else {
      const profit = (price - actualStrike) * lotSize - actualPremium
      return Math.min(profit, 50000)
    }
  }, [effectiveStrike, effectivePremium, strategyDetails?.lotSize])

  // Calculate P&L for target date line (smoother curve)
  const calculateTargetDatePnL = useCallback((price: number) => {
    if (!effectiveStrike || !effectivePremium) return 0
    
    const actualStrike = effectiveStrike
    const timeValue = strategyDetails?.timeValue || (effectivePremium * 0.2) // Estimate time value if not available
    const lotSize = strategyDetails?.lotSize || 50
    const actualPremium = effectivePremium * 0.8 // Approximate for target date

    // Smooth curve with some theta decay
    const intrinsicValue = Math.max(0, price - actualStrike) * lotSize
    const extrinsicValue = timeValue * Math.exp(-Math.pow((price - actualStrike) / 500, 2) * 0.5)

    const result = intrinsicValue + extrinsicValue - actualPremium
    // Cap at 50,000 to prevent going above
    return Math.min(result, 50000)
  }, [effectiveStrike, effectivePremium, strategyDetails?.timeValue, strategyDetails?.lotSize])

  // Generate OI data for bars - using real data from strategyDetails if available
  const oiData = useMemo(() => {
    if (!basePrice) return []
    
    return priceRange.map((price) => {
      // Use OI data from API if available, otherwise show minimal bars
      const callOI = strategyDetails?.callOI || strategyDetails?.openInterest?.call || 0
      const putOI = strategyDetails?.putOI || strategyDetails?.openInterest?.put || 0
      
      // If no OI data, show empty bars
      const distanceFromBase = Math.abs(price - basePrice)
      const normalizedCallOI = callOI > 0 ? callOI * (1 - distanceFromBase / 1500) : 0
      const normalizedPutOI = putOI > 0 ? putOI * (1 - distanceFromBase / 1500) : 0

      return {
        price,
        callOI: Math.max(0, normalizedCallOI),
        putOI: Math.max(0, normalizedPutOI),
      }
    })
  }, [priceRange, basePrice, strategyDetails])

  // Chart dimensions - responsive to container
  const chartWidth = 900
  const chartHeight = 400
  const padding = { top: 60, right: 80, bottom: 50, left: 80 }
  const plotWidth = chartWidth - padding.left - padding.right
  const plotHeight = chartHeight - padding.top - padding.bottom

  // Scales
  const minPrice = priceRange[0]
  const maxPrice = priceRange[priceRange.length - 1]
  const minPnL = -15000
  const maxPnL = 50000 // Cap at 50,000 to prevent going above
  const maxOI = 150

  const xScale = (price: number) => padding.left + ((price - minPrice) / (maxPrice - minPrice)) * plotWidth

  const yScale = (pnl: number) => padding.top + plotHeight - ((pnl - minPnL) / (maxPnL - minPnL)) * plotHeight

  const oiScale = (oi: number) => (oi / maxOI) * plotHeight

  // Generate path for expiry line
  const expiryPath = useMemo(() => {
    const minPrice = priceRange[0]
    const maxPrice = priceRange[priceRange.length - 1]
    const xScale = (price: number) => padding.left + ((price - minPrice) / (maxPrice - minPrice)) * plotWidth
    const yScale = (pnl: number) => padding.top + plotHeight - ((pnl - minPnL) / (maxPnL - minPnL)) * plotHeight
    
    const points = priceRange.map((price) => ({
      x: xScale(price),
      y: yScale(calculateExpiryPnL(price)),
    }))
    return points.map((p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `L ${p.x} ${p.y}`)).join(" ")
  }, [priceRange, calculateExpiryPnL])

  // Generate path for target date line
  const targetDatePath = useMemo(() => {
    const minPrice = priceRange[0]
    const maxPrice = priceRange[priceRange.length - 1]
    const xScale = (price: number) => padding.left + ((price - minPrice) / (maxPrice - minPrice)) * plotWidth
    const yScale = (pnl: number) => padding.top + plotHeight - ((pnl - minPnL) / (maxPnL - minPnL)) * plotHeight
    
    const points = priceRange.map((price) => ({
      x: xScale(price),
      y: yScale(calculateTargetDatePnL(price)),
    }))
    return points.map((p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `L ${p.x} ${p.y}`)).join(" ")
  }, [priceRange, calculateTargetDatePnL])

  // Generate area paths for profit/loss zones
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _lossAreaPath = useMemo(() => {
    const minPrice = priceRange[0]
    const maxPrice = priceRange[priceRange.length - 1]
    const xScale = (price: number) => padding.left + ((price - minPrice) / (maxPrice - minPrice)) * plotWidth
    const yScale = (pnl: number) => padding.top + plotHeight - ((pnl - minPnL) / (maxPnL - minPnL)) * plotHeight
    const zeroY = yScale(0)
    const points: string[] = []

    priceRange.forEach((price, i) => {
      const pnl = calculateExpiryPnL(price)
      const x = xScale(price)
      const y = yScale(pnl)

      if (pnl < 0) {
        if (i === 0 || calculateExpiryPnL(priceRange[i - 1]) >= 0) {
          points.push(`M ${x} ${zeroY}`)
        }
        points.push(`L ${x} ${y}`)
      } else if (i > 0 && calculateExpiryPnL(priceRange[i - 1]) < 0) {
        points.push(`L ${x} ${zeroY} Z`)
      }
    })

    return points.join(" ")
  }, [priceRange, calculateExpiryPnL])

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _profitAreaPath = useMemo(() => {
    const minPrice = priceRange[0]
    const maxPrice = priceRange[priceRange.length - 1]
    const xScale = (price: number) => padding.left + ((price - minPrice) / (maxPrice - minPrice)) * plotWidth
    const yScale = (pnl: number) => padding.top + plotHeight - ((pnl - minPnL) / (maxPnL - minPnL)) * plotHeight
    const zeroY = yScale(0)
    const points: string[] = []
    let started = false

    priceRange.forEach((price) => {
      const pnl = calculateExpiryPnL(price)
      const x = xScale(price)
      const y = yScale(pnl)

      if (pnl > 0) {
        if (!started) {
          points.push(`M ${x} ${zeroY}`)
          started = true
        }
        points.push(`L ${x} ${y}`)
      } else if (started && pnl <= 0) {
        points.push(`L ${x} ${zeroY} Z`)
        started = false
      }
    })

    if (started) {
      const lastX = xScale(priceRange[priceRange.length - 1])
      points.push(`L ${lastX} ${zeroY} Z`)
    }

    return points.join(" ")
  }, [priceRange, calculateExpiryPnL])

  // Handle mouse move for tooltip
  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!chartRef.current || !currentPrice || priceRange.length === 0) return

    const rect = chartRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const _y = e.clientY - rect.top

    // Convert x position to price
    const price = minPrice + ((x - padding.left) / plotWidth) * (maxPrice - minPrice)

    if (price >= minPrice && price <= maxPrice && x >= padding.left && x <= chartWidth - padding.right) {
      const pnlTarget = calculateTargetDatePnL(price)
      const pnlExpiry = calculateExpiryPnL(price)
      const percentChange = ((price - currentPrice) / currentPrice) * 100
      const pointChange = price - currentPrice

      setTooltip({
        x,
        y: yScale(pnlTarget),
        price: Math.round(price),
        pnlTargetDate: Math.round(pnlTarget),
        pnlExpiry: Math.round(pnlExpiry),
        percentChange,
        pointChange: Math.round(pointChange),
      })
    } else {
      setTooltip(null)
    }
  }

  const handleMouseLeave = () => {
    setTooltip(null)
  }

  // Calculate days to expiry from slider
  const daysToExpiry = Math.round(5 - (dateSliderValue[0] / 100) * 5)

  // Handle target adjustment
  const adjustTarget = (delta: number) => {
    if (!currentPrice) return
    const newTarget = niftyTarget + delta
    setNiftyTarget(newTarget)
    setTargetPercent(((newTarget - currentPrice) / currentPrice) * 100)
  }

  // Projected P&L - use callback
  const projectedPnL = useMemo(() => {
    if (!niftyTarget || niftyTarget === 0) return 0
    return calculateTargetDatePnL(niftyTarget)
  }, [niftyTarget, calculateTargetDatePnL])
  const projectedPercent = useMemo(() => {
    if (!effectivePremium || effectivePremium === 0) return "0.00"
    return ((projectedPnL / (effectivePremium * 2)) * 100).toFixed(2)
  }, [projectedPnL, effectivePremium])

  // Show message if required data is missing
  if (!hasRequiredData) {
    const hasReportsData = strategyReports?.reportsSignalDTOs && strategyReports.reportsSignalDTOs.length > 0
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full">
        <div className="flex flex-col items-center justify-center py-12">
          <div className="text-gray-400 dark:text-gray-500 mb-4">
            <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </div>
          <p className="text-gray-500 dark:text-gray-300 text-lg font-medium mb-2">Payoff Chart Data Not Available</p>
          <p className="text-gray-400 dark:text-gray-400 text-sm text-center max-w-md px-4">
            {hasReportsData 
              ? "Unable to extract sufficient data from strategy reports to render the payoff chart. Please ensure the strategy has valid trading data."
              : "The payoff chart requires strategy details including current price and base price. Please ensure the strategy is deployed and has trading activity."}
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 md:p-6 w-full overflow-hidden">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-3 py-2 rounded mb-4 bg-gray-50 dark:bg-gray-900">
        <div className="flex items-center gap-6">
          <span className="text-xs md:text-sm text-gray-600 dark:text-gray-400">OI data at {basePrice?.toLocaleString() || "N/A"}</span>
          {strategyDetails?.callOI || strategyDetails?.openInterest?.call ? (
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: "rgba(239, 68, 68, 0.5)" }} />
              <span className="text-xs md:text-sm text-gray-600 dark:text-gray-400">
                Call OI {strategyDetails?.callOI ? `${(strategyDetails.callOI / 100000).toFixed(1)}L` : 
                  strategyDetails?.openInterest?.call ? `${(strategyDetails.openInterest.call / 100000).toFixed(1)}L` : "N/A"}
              </span>
            </div>
          ) : null}
          {strategyDetails?.putOI || strategyDetails?.openInterest?.put ? (
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: "rgba(34, 197, 94, 0.3)" }} />
              <span className="text-xs md:text-sm text-gray-600 dark:text-gray-400">
                Put OI {strategyDetails?.putOI ? `${(strategyDetails.putOI / 10000000).toFixed(2)}Cr` : 
                  strategyDetails?.openInterest?.put ? `${(strategyDetails.openInterest.put / 10000000).toFixed(2)}Cr` : "N/A"}
              </span>
            </div>
          ) : null}
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-0.5 bg-red-500" />
            <span className="text-xs md:text-sm text-gray-600 dark:text-gray-400">On Expiry</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-0.5 bg-blue-500" />
            <span className="text-xs md:text-sm text-gray-600 dark:text-gray-400">On Target Date</span>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="relative w-full overflow-x-auto">
        {/* Current Price at top center of chart */}
        {currentPrice && (
          <div className="absolute top-2 left-1/2 transform -translate-x-1/2 z-10">
            <div className="bg-gray-100 px-3 py-1 rounded text-sm">
              Current price: <span className="font-semibold">{currentPrice.toFixed(2)}</span>
            </div>
          </div>
        )}
        
        {/* Zoom button */}
        <div className="absolute top-2 right-2 z-10">
          <button
            onClick={() => setIsZoomedOut(!isZoomedOut)}
            className="flex items-center gap-2 px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 bg-white"
          >
            <Search className="w-4 h-4" />
            <span className="text-sm">{isZoomedOut ? "Zoom In" : "Zoom Out"}</span>
          </button>
        </div>
        <svg
          ref={chartRef}
          width="100%"
          height={chartHeight}
          viewBox={`0 0 ${chartWidth} ${chartHeight}`}
          className="overflow-visible min-w-full"
          preserveAspectRatio="xMidYMid meet"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
        >
          {/* SD Labels */}
          <text
            x={xScale(minPrice + (maxPrice - minPrice) * 0.1)}
            y={padding.top - 30}
            className="text-xs fill-gray-500"
            textAnchor="middle"
          >
            -2SD
          </text>
          <text
            x={xScale(minPrice + (maxPrice - minPrice) * 0.25)}
            y={padding.top - 30}
            className="text-xs fill-gray-500"
            textAnchor="middle"
          >
            -1SD
          </text>
          <text
            x={xScale(minPrice + (maxPrice - minPrice) * 0.65)}
            y={padding.top - 30}
            className="text-xs fill-gray-500"
            textAnchor="middle"
          >
            1SD
          </text>
          <text
            x={xScale(minPrice + (maxPrice - minPrice) * 0.85)}
            y={padding.top - 30}
            className="text-xs fill-gray-500"
            textAnchor="middle"
          >
            2SD
          </text>

          {/* Grid lines */}
          {[0, 10000, 20000, 30000, 40000, 50000].map((pnl) => (
            <line
              key={pnl}
              x1={padding.left}
              y1={yScale(pnl)}
              x2={chartWidth - padding.right}
              y2={yScale(pnl)}
              stroke="#E5E7EB"
              strokeWidth="1"
              strokeDasharray="3 3"
            />
          ))}

          {/* Zero line */}
          <line
            x1={padding.left}
            y1={yScale(0)}
            x2={chartWidth - padding.right}
            y2={yScale(0)}
            stroke="#9CA3AF"
            strokeWidth="1"
          />

          {/* OI Bars */}
          {oiData.map((d, i) => {
            const x = xScale(d.price)
            const barWidth = (plotWidth / priceRange.length) * 0.6

            return (
              <g key={i}>
                {/* Call OI (red) */}
                <rect
                  x={x - barWidth / 2}
                  y={padding.top + plotHeight - oiScale(d.callOI)}
                  width={barWidth / 2 - 1}
                  height={oiScale(d.callOI)}
                  fill="rgba(239, 68, 68, 0.4)"
                />
                {/* Put OI (green) */}
                <rect
                  x={x}
                  y={padding.top + plotHeight - oiScale(d.putOI)}
                  width={barWidth / 2 - 1}
                  height={oiScale(d.putOI)}
                  fill="rgba(34, 197, 94, 0.3)"
                />
              </g>
            )
          })}

          {/* Loss area (red shaded) */}
          <path
            d={`M ${padding.left} ${yScale(0)} 
                ${priceRange
                  .filter((p) => calculateExpiryPnL(p) < 0)
                  .map((p) => `L ${xScale(p)} ${yScale(calculateExpiryPnL(p))}`)
                  .join(" ")} 
                L ${xScale(basePrice)} ${yScale(0)} Z`}
            fill="rgba(239, 68, 68, 0.15)"
          />

          {/* Profit area (green shaded) */}
          <path
            d={`M ${xScale(basePrice)} ${yScale(0)} 
                ${priceRange
                  .filter((p) => calculateExpiryPnL(p) >= 0 && p >= basePrice)
                  .map((p) => `L ${xScale(p)} ${yScale(Math.max(0, calculateExpiryPnL(p)))}`)
                  .join(" ")} 
                L ${xScale(maxPrice)} ${yScale(0)} Z`}
            fill="rgba(34, 197, 94, 0.15)"
          />

          {/* Expiry line */}
          <path d={expiryPath} fill="none" stroke="url(#expiryGradient)" strokeWidth="2" />
          <defs>
            <linearGradient id="expiryGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#EF4444" />
              <stop offset="50%" stopColor="#EF4444" />
              <stop offset="50%" stopColor="#22C55E" />
              <stop offset="100%" stopColor="#22C55E" />
            </linearGradient>
          </defs>

          {/* Target date line (blue) */}
          <path d={targetDatePath} fill="none" stroke="#3B82F6" strokeWidth="2" />

          {/* Current price vertical line */}
          {currentPrice && (
            <>
              <line
                x1={xScale(currentPrice)}
                y1={padding.top}
                x2={xScale(currentPrice)}
                y2={padding.top + plotHeight}
                stroke="#9CA3AF"
                strokeWidth="1"
                strokeDasharray="4 4"
              />

              {/* Current price circle */}
              <circle
                cx={xScale(currentPrice)}
                cy={yScale(calculateTargetDatePnL(currentPrice))}
                r="6"
                fill="white"
                stroke="#EF4444"
                strokeWidth="2"
              />
            </>
          )}

          {/* Projected P&L horizontal line at bottom */}
          {(() => {
            const projectedPnLValue = calculateTargetDatePnL(niftyTarget)
            // Price points starting from 25,900
            // Generate price points based on actual price range
            const priceStep = 200
            const startPrice = Math.floor((basePrice || currentPrice || 0) / priceStep) * priceStep
            const pricePoints: number[] = []
            for (let i = 0; i < 7; i++) {
              const price = startPrice + (i * priceStep)
              if (price >= minPrice && price <= maxPrice) {
                pricePoints.push(price)
              }
            }
            const validPrices = pricePoints.filter(p => p >= minPrice && p <= maxPrice)
            
            if (validPrices.length > 0) {
              const startX = xScale(validPrices[0])
              const endX = xScale(validPrices[validPrices.length - 1])
              // Position at the y-coordinate corresponding to the projected loss value
              const yPos = yScale(projectedPnLValue)
              
              return (
                <line
                  x1={startX}
                  y1={yPos}
                  x2={endX}
                  y2={yPos}
                  stroke={projectedPnLValue < 0 ? "#EF4444" : "#22C55E"}
                  strokeWidth="2"
                  strokeDasharray="4 4"
                  opacity={0.8}
                />
              )
            }
            return null
          })()}

          {/* Y-axis labels (left - Profit/Loss) */}
          <text
            x={padding.left - 80}
            y={padding.top + plotHeight / 2}
            className="text-xs fill-gray-500"
            textAnchor="middle"
            transform={`rotate(-90, ${padding.left - 80}, ${padding.top + plotHeight / 2})`}
          >
            Profit / loss
          </text>
          {[-10000, 0, 10000, 20000, 30000, 40000, 50000].map((pnl) => (
            <text
              key={pnl}
              x={padding.left - 10}
              y={yScale(pnl) + 4}
              className="text-xs fill-gray-500"
              textAnchor="end"
            >
              {pnl >= 0 ? pnl.toLocaleString() : pnl.toLocaleString()}
            </text>
          ))}

          {/* Y-axis labels (right - Open Interest) */}
          <text
            x={chartWidth - padding.right + 40}
            y={padding.top + plotHeight / 2}
            className="text-xs fill-gray-500"
            textAnchor="start"
            transform={`rotate(90, ${chartWidth - padding.right + 50}, ${padding.top + plotHeight / 2})`}
          >
            Open Interest
          </text>
          {["1.5Cr", "1Cr", "50L", "0"].map((label, i) => (
            <text
              key={label}
              x={chartWidth - padding.right + 10}
              y={padding.top + (plotHeight / 3) * i + 4}
              className="text-xs fill-gray-500"
              textAnchor="start"
            >
              {label}
            </text>
          ))}

          {/* X-axis labels */}
          {priceRange
            .filter((_, i) => i % 2 === 0)
            .map((price) => (
              <text
                key={price}
                x={xScale(price)}
                y={chartHeight - 10}
                className="text-xs fill-gray-500"
                textAnchor="middle"
              >
                {price.toLocaleString()}
              </text>
            ))}

          {/* Tooltip */}
          {tooltip && (
            <g>
              {/* Vertical line at tooltip position */}
              <line
                x1={tooltip.x}
                y1={padding.top}
                x2={tooltip.x}
                y2={padding.top + plotHeight}
                stroke="#6B7280"
                strokeWidth="1"
                strokeDasharray="3 3"
              />

              {/* Tooltip box - Compact */}
              <foreignObject x={tooltip.x - 90} y={tooltip.y - 90} width="180" height="100">
                <div className="bg-gray-800 text-white p-2 rounded text-xs shadow-lg">
                  <div className="flex items-center gap-1 mb-1">
                    <span className="font-semibold text-sm">{tooltip.price.toLocaleString()}</span>
                    <span className={`text-xs ${tooltip.percentChange < 0 ? "text-red-400" : "text-green-400"}`}>
                      {tooltip.percentChange.toFixed(2)}% ({tooltip.pointChange > 0 ? "+" : ""}
                      {tooltip.pointChange})
                    </span>
                  </div>
                  <div className="flex justify-between text-xs mb-0.5">
                    <span className="text-gray-400">Thu, 13 Nov:</span>
                    <span className={tooltip.pnlTargetDate < 0 ? "text-red-400" : "text-green-400"}>
                      {tooltip.pnlTargetDate.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400">Expiry:</span>
                    <span className={tooltip.pnlExpiry < 0 ? "text-red-400" : "text-green-400"}>
                      {tooltip.pnlExpiry.toLocaleString()}
                    </span>
                  </div>
                </div>
              </foreignObject>
            </g>
          )}
        </svg>
      </div>

      {/* Projected Loss Badge - Outside chart at bottom */}
      <div className="flex justify-center mt-4">
        <div
          className={`flex items-center gap-1 px-3 py-1 rounded text-sm ${projectedPnL < 0 ? "bg-red-500 text-white" : "bg-green-500 text-white"}`}
        >
          <span>
            Projected {projectedPnL < 0 ? "loss" : "profit"}: {Math.round(projectedPnL).toLocaleString()} (
            {projectedPercent}%)
          </span>
          <HelpCircle className="w-4 h-4" />
        </div>
      </div>

      {/* Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mt-6 md:mt-8 border-t border-gray-200 dark:border-gray-700 pt-4 md:pt-6">
        {/* NIFTY Target */}
        <div>
          <div className="flex items-center gap-4 mb-2">
            <span className="text-xs md:text-sm font-medium text-gray-700 dark:text-gray-300">NIFTY Target</span>
            <div className="flex items-center gap-2 ml-auto">
              <span className="text-sm text-gray-600">{targetPercent.toFixed(1)}%</span>
              <div className="flex items-center border border-gray-300 rounded bg-white">
                <button 
                  onClick={() => adjustTarget(-10)} 
                  disabled={!currentPrice}
                  className="p-1 hover:opacity-80 text-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <input
                  type="number"
                  value={niftyTarget > 0 ? niftyTarget.toFixed(1) : ""}
                  onChange={(e) => {
                    const val = Number.parseFloat(e.target.value)
                    if (!isNaN(val) && currentPrice) {
                      setNiftyTarget(val)
                      setTargetPercent(((val - currentPrice) / currentPrice) * 100)
                    }
                  }}
                  disabled={!currentPrice}
                  className="w-20 text-center text-sm border-x border-gray-300 py-1 bg-white disabled:bg-gray-100 disabled:cursor-not-allowed"
                />
                <button 
                  onClick={() => adjustTarget(10)} 
                  disabled={!currentPrice}
                  className="p-1 hover:opacity-80 text-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
          <button className="text-sm mb-3" style={{ color: "#006CE6" }}>Reset</button>
          <div className="w-full">
              <Slider
                value={[50 + targetPercent * 10]}
                onValueChange={(val) => {
                  if (!currentPrice) return
                  const pct = (val[0] - 50) / 10
                  setTargetPercent(pct)
                  setNiftyTarget(currentPrice * (1 + pct / 100))
                }}
                max={100}
                step={1}
                disabled={!currentPrice}
                className="w-full [&_[data-slot=slider-track]]:bg-gray-300 [&_[data-slot=slider-range]]:bg-gray-300 [&_[data-slot=slider-thumb]]:ring-gray-400 [&_[data-slot=slider-thumb]]:border-gray-400 [&_[data-slot=slider-thumb]]:bg-[#006CE6] [&_[data-slot=slider-thumb]]:hover:ring-gray-400 [&_[data-slot=slider-thumb]]:focus-visible:ring-gray-400 disabled:opacity-50"
              />
          </div>
        </div>

        {/* Date Slider */}
        <div>
          <div className="flex items-center gap-4 mb-2">
            <span className="text-xs md:text-sm font-medium text-gray-700 dark:text-gray-300">Date: {daysToExpiry}D to expiry</span>
            <HelpCircle className="w-4 h-4 text-gray-400" />
            <div className="flex items-center gap-2 ml-auto">
              <button className="p-1 border border-gray-300 rounded hover:bg-gray-100">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-sm">Thu, 13 Nov 2:31 PM</span>
              <button className="p-1 border border-gray-300 rounded hover:bg-gray-100">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
          <button className="text-sm mb-3" style={{ color: "#006CE6" }}>Reset</button>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <Slider
                value={dateSliderValue}
                onValueChange={setDateSliderValue}
                max={100}
                step={1}
                className="w-full [&_[data-slot=slider-track]]:bg-gray-300 [&_[data-slot=slider-range]]:bg-gray-300 [&_[data-slot=slider-thumb]]:ring-gray-400 [&_[data-slot=slider-thumb]]:border-gray-400 [&_[data-slot=slider-thumb]]:bg-[#006CE6] [&_[data-slot=slider-thumb]]:hover:ring-gray-400 [&_[data-slot=slider-thumb]]:focus-visible:ring-gray-400"
              />
            </div>
          </div>
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>13 Nov</span>
            <span>18 Nov</span>
          </div>
        </div>
      </div>
    </div>
  )
}

// Memoize component to prevent unnecessary re-renders
export default React.memo(PayoffChart, (prevProps, nextProps) => {
  // Custom comparison function for better performance
  return (
    prevProps.strategyDetails === nextProps.strategyDetails &&
    prevProps.strategyLegs === nextProps.strategyLegs &&
    prevProps.strategyReports === nextProps.strategyReports &&
    prevProps.currentPrice === nextProps.currentPrice &&
    prevProps.basePrice === nextProps.basePrice
  )
})

