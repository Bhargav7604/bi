"use client"

import React, { useState, useEffect, useCallback, useRef, useMemo } from "react"
import { Link, useNavigate } from "react-router-dom"
import { Bookmark, Share2, ArrowUpRight, Loader2, AlertTriangle, Info } from "lucide-react"
import { strategyService } from "@/lib/api/strategy.service"
import type { ReadyToDeployStrategy } from "@/lib/api/types"
import { useActiveStrategies } from "@/hooks/useActiveStrategies"
import { toastr } from "@/lib/utils/toastr"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@components/ui/dialog"
import { Button } from "@components/ui/button"
import { ToggleGroup, ToggleGroupItem } from "@components/ui/toggle-group"
import { Minus, Plus } from "lucide-react"

function FeaturedStrategies() {
  const navigate = useNavigate()
  const [strategies, setStrategies] = useState<ReadyToDeployStrategy[]>([])
  const [filteredStrategies, setFilteredStrategies] = useState<ReadyToDeployStrategy[]>([])
  const [loading, setLoading] = useState(false)
  const { activeStrategies, refetch: refetchActiveStrategies } = useActiveStrategies()
  const [_undeployLoading, setUndeployLoading] = useState<number | null>(null)
  const hasFetchedReadyToDeployRef = useRef(false)
  const [bookmarkedStrategies, setBookmarkedStrategies] = useState<number[]>([])
  const [searchQuery, setSearchQuery] = useState<string>("")
  
  // Deploy dialog state
  const [deployDialogOpen, setDeployDialogOpen] = useState(false)
  const [selectedStrategy, setSelectedStrategy] = useState<ReadyToDeployStrategy | null>(null)
  
  // Share modal state
  const [shareModalOpen, setShareModalOpen] = useState(false)
  const [_shareStrategyId, setShareStrategyId] = useState<number | null>(null)
  const [multiplier, setMultiplier] = useState<number>(1)
  const [executionTypeId, setExecutionTypeId] = useState<string>("LiveTrading")
  const [deployLoading, setDeployLoading] = useState(false)
  const [deployError, setDeployError] = useState<string | null>(null)
  const [marginNeeded, setMarginNeeded] = useState<number>(0)
  const [marginAvailable, _setMarginAvailable] = useState<number>(15425.10)
  const [backtestConsentOpen, setBacktestConsentOpen] = useState(false)
  const [pendingBacktestStrategy, setPendingBacktestStrategy] = useState<string | null>(null)
  const [backtestLoading, setBacktestLoading] = useState(false)

  // Generate tags from strategy data
  const generateTags = useCallback((strategy: ReadyToDeployStrategy): string[] => {
    const tags: string[] = []
    if (strategy.underlying) {
      const underlyingMap: Record<string | number, string> = {
        1: "Nifty",
        2: "Bank Nifty",
        3: "FinNifty",
        4: "Sensex",
        5: "Bankex",
      }
      tags.push(underlyingMap[strategy.underlying as string | number] || `Underlying ${strategy.underlying}`)
    }
    if (strategy.positionType) {
      tags.push(strategy.positionType)
    }
    // Add risk level as a tag
    if (strategy.riskLevel && typeof strategy.riskLevel === "string") {
      tags.push(strategy.riskLevel)
    }
    return tags
  }, [])


  // Fetch inhouse strategies from API
  const fetchPopularStrategies = useCallback(async () => {
    // Prevent duplicate calls
    if (hasFetchedReadyToDeployRef.current) {
      return
    }
    
    hasFetchedReadyToDeployRef.current = true
    setLoading(true)
    
    try {
      const response = await strategyService.getReadyToDeployStrategies("inhouse")
      if (response.success && response.data) {
        const responseData = response.data as any
        let strategiesData: ReadyToDeployStrategy[] = []
        
        if (responseData.strategies?.inHouse && Array.isArray(responseData.strategies.inHouse)) {
          strategiesData = responseData.strategies.inHouse
        } else if (responseData.data?.strategies?.inHouse && Array.isArray(responseData.data.strategies.inHouse)) {
          strategiesData = responseData.data.strategies.inHouse
        }
        
        // Transform to match component structure (no limit - show all strategies)
        const transformedStrategies = strategiesData.map((strategy) => {
          const baseTags = generateTags(strategy)
          // Add hardcoded "Medium" tag with blue styling
          baseTags.push("Medium")
          return {
            ...strategy,
            id: strategy.id,
            title: strategy.name || "Untitled Strategy",
            tags: baseTags,
            description: strategy.description || "",
            minCapital: strategy.minCapital || 0,
            avgReturn: "Backtest",
            riskLevel: "Medium",
          }
        })
        
        setStrategies(transformedStrategies)
        setFilteredStrategies(transformedStrategies)
      }
    } catch (err) {
      console.error("Error fetching inhouse strategies:", err)
    } finally {
      setLoading(false)
      // Reset after a delay to allow manual refresh
      setTimeout(() => {
        hasFetchedReadyToDeployRef.current = false
      }, 1000)
    }
  }, [generateTags])

  // Listen for global search events from header
  useEffect(() => {
    const handleGlobalSearch = (event: CustomEvent) => {
      const { query, path } = event.detail
      // Only apply search if we're on the home page
      if (path === "/" || path === "/home") {
        setSearchQuery(query)
      }
    }

    // Check for search query from sessionStorage on mount
    const storedQuery = sessionStorage.getItem('globalSearchQuery')
    const storedPath = sessionStorage.getItem('globalSearchPath')
    if (storedQuery && (storedPath === "/" || storedPath === "/home")) {
      setSearchQuery(storedQuery)
      // Clear after using
      sessionStorage.removeItem('globalSearchQuery')
      sessionStorage.removeItem('globalSearchPath')
    }

    window.addEventListener('globalSearch', handleGlobalSearch as EventListener)
    return () => window.removeEventListener('globalSearch', handleGlobalSearch as EventListener)
  }, [])

  // Memoize filtered strategies to prevent recalculation
  const memoizedFilteredStrategies = useMemo(() => {
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase()
      return strategies.filter((strategy) => {
        const title = String(strategy.title || strategy.name || "").toLowerCase()
        const description = String(strategy.description || "").toLowerCase()
        return title.includes(query) || description.includes(query)
      })
    }
    return strategies
  }, [searchQuery, strategies])

  // Update state only when memoized value changes
  useEffect(() => {
    setFilteredStrategies(memoizedFilteredStrategies)
  }, [memoizedFilteredStrategies])

  // Check if a strategy is deployed
  const isStrategyDeployed = useCallback((strategyId: number): boolean => {
    return activeStrategies.some((active) => active.sid === strategyId)
  }, [activeStrategies])

  // Get deployed timestamp for a strategy
  const getDeployedTimestamp = (strategyId: number): string | null => {
    const activeStrategy = activeStrategies.find((s) => s.sid === strategyId)
    return activeStrategy?.deployedOn || null
  }

  // Format time difference (e.g., "15 minutes ago")
  const formatTimeAgo = (timestamp: string): string => {
    try {
      const deployedDate = new Date(timestamp)
      const now = new Date()
      const diffMs = now.getTime() - deployedDate.getTime()
      const diffMins = Math.floor(diffMs / 60000)
      const diffHours = Math.floor(diffMs / 3600000)
      const diffDays = Math.floor(diffMs / 86400000)

      if (diffMins < 1) {
        return "just now"
      } else if (diffMins < 60) {
        return `${diffMins} minute${diffMins !== 1 ? "s" : ""} ago`
      } else if (diffHours < 24) {
        return `${diffHours} hour${diffHours !== 1 ? "s" : ""} ago`
      } else {
        return `${diffDays} day${diffDays !== 1 ? "s" : ""} ago`
      }
    } catch (error) {
      console.error("Error formatting time:", error)
      return ""
    }
  }

  // Format title to replace abbreviations and control line breaks
  const formatTitle = (title: string): string => {
    let formatted = title
    
    // Keep "Delta Neutral" together, allow "Hedge" to wrap to next line
    formatted = formatted.replace(/(Delta)\s+(Neutral)\s+(Hedge)/gi, '$1\u00A0$2 $3')
    
    return formatted
  }

  // Format capital
  const formatCapital = (capital: number | string | undefined): string => {
    if (typeof capital === "string") return capital
    if (!capital || capital === 0) return "₹0"
    if (capital >= 100000) {
      return `₹${(capital / 100000).toFixed(2)}L`
    }
    if (capital >= 1000) {
      return `₹${(capital / 1000).toFixed(2)}K`
    }
    return `₹${capital}`
  }

  // Get strategy initials for icon
  const getStrategyInitials = (name: string): string => {
    const words = name.split(/\s+/)
    if (words.length >= 2) {
      return (words[0][0] + words[1][0]).toUpperCase()
    }
    return name.substring(0, 2).toUpperCase()
  }

  // Calculate margin needed
  const calculateMarginNeeded = useCallback((mult: number, strategy: ReadyToDeployStrategy | null): number => {
    if (!strategy) return 0
    const baseMargin = strategy.minCapital || 0
    return baseMargin * mult
  }, [])

  // Handle multiplier change
  const handleMultiplierChange = (delta: number) => {
    setMultiplier((prev) => {
      const newMultiplier = Math.max(0, Math.min(100, prev + delta))
      if (selectedStrategy) {
        const newMargin = calculateMarginNeeded(newMultiplier, selectedStrategy)
        setMarginNeeded(newMargin)
      }
      return newMultiplier
    })
  }

  // Handle deploy button click
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _handleDeployClick = (strategy: ReadyToDeployStrategy) => {
    setSelectedStrategy(strategy)
    setMultiplier(1)
    setExecutionTypeId("LiveTrading")
    setDeployError(null)
    setDeployDialogOpen(true)
  }

  // Handle deploy submission
  const handleDeploySubmit = async () => {
    if (!selectedStrategy) return

    setDeployLoading(true)
    setDeployError(null)

    try {
      const response = await strategyService.oneClickDeploy({
        strategyId: selectedStrategy.id,
        multiplier: multiplier,
        executionTypeId: executionTypeId,
      })

      if (response.success) {
        setDeployDialogOpen(false)
        setSelectedStrategy(null)
        hasFetchedReadyToDeployRef.current = false // Allow refresh
        await refetchActiveStrategies()
        await fetchPopularStrategies()
      } else {
        const errorMsg = response.error?.message || "Failed to deploy strategy"
        setDeployError(errorMsg)
      }
    } catch (err) {
      console.error("Error deploying strategy:", err)
      const errorMsg = err instanceof Error ? err.message : "An error occurred while deploying"
      setDeployError(errorMsg)
    } finally {
      setDeployLoading(false)
    }
  }

  // Handle undeploy
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _handleUndeploy = async (strategyId: number) => {
    setUndeployLoading(strategyId)
    const strategy = strategies.find(s => s.id === strategyId)
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const _strategyName = strategy?.name || "Strategy"
    
    try {
      const response = await strategyService.undeployStrategy(strategyId)
      if (response.success) {
        hasFetchedReadyToDeployRef.current = false // Allow refresh
        await refetchActiveStrategies()
        await fetchPopularStrategies()
      }
    } catch (err) {
      console.error("Error undeploying strategy:", err)
    } finally {
      setUndeployLoading(null)
    }
  }

  // Close deploy dialog
  const handleDeployDialogClose = (open: boolean) => {
    if (!deployLoading && !open) {
      setDeployDialogOpen(false)
      setSelectedStrategy(null)
      setDeployError(null)
    }
  }

  // Handle backtest click - show consent dialog first
  const handleBacktestClick = (strategy: ReadyToDeployStrategy, e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    
    const strategyName = (strategy.name || strategy.title || "") as string
    if (!strategyName) {
      toastr.error("Error", "Strategy name not found")
      return
    }

    // Show consent dialog
    setPendingBacktestStrategy(strategyName)
    setBacktestConsentOpen(true)
  }

  // Handle consent confirmation
  const handleBacktestConsent = () => {
    if (pendingBacktestStrategy) {
      setBacktestConsentOpen(false)
      setBacktestLoading(true)
      // Navigate immediately - the page will handle loading
      navigate(`/backtest-results?strategyName=${encodeURIComponent(pendingBacktestStrategy)}`)
      setPendingBacktestStrategy(null)
    }
  }

  // Get status badge style - matching DiscoverStrategy
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _getStatusStyle = (status: string | undefined): string => {
    if (!status) return "bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300"
    const statusLower = status.toLowerCase()
    if (statusLower === "active") {
      return "bg-green-100 text-green-700"
    }
    if (statusLower === "deployed" || statusLower === "running") {
      return "bg-green-100 text-green-700"
    }
    if (statusLower === "available") {
      return "bg-blue-100 text-blue-700"
    }
    if (statusLower === "paused" || statusLower === "stopped") {
      return "bg-yellow-100 text-yellow-700"
    }
    if (statusLower === "error" || statusLower === "failed") {
      return "bg-red-100 text-red-700"
    }
    return "bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300"
  }

  // Format status text - show "Deployed" when status is "Active" - matching DiscoverStrategy
  const formatStatus = (status: string | undefined): string => {
    if (!status) return "Unknown"
    const statusLower = status.toLowerCase()
    if (statusLower === "active") {
      return "Deployed"
    }
    return status.charAt(0).toUpperCase() + status.slice(1).toLowerCase()
  }

  // Fetch data on mount - only once
  useEffect(() => {
    fetchPopularStrategies()
    // activeStrategies are fetched by the hook automatically
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []) // Empty deps - only run once on mount

  // Update margin when multiplier or strategy changes
  useEffect(() => {
    if (selectedStrategy && deployDialogOpen) {
      const calculatedMargin = calculateMarginNeeded(multiplier, selectedStrategy)
      setMarginNeeded(calculatedMargin)
    }
  }, [multiplier, selectedStrategy, deployDialogOpen, calculateMarginNeeded])

  const getTagStyle = (_tag: string) => {
    // All tags use the same blue color - matching DiscoverStrategy
    return "bg-blue-100 text-blue-700"
  }

  const toggleBookmark = (strategyId: number) => {
    setBookmarkedStrategies((prev) =>
      prev.includes(strategyId) ? prev.filter((id) => id !== strategyId) : [...prev, strategyId]
    )
  }

  return (
    <section className="w-full bg-[#F5F5F5] dark:bg-gray-950 py-3 sm:py-3.5 lg:py-4">
      <div className="w-full max-w-[1440px] mx-auto px-8 sm:px-12 lg:px-28">
        <div className="flex flex-col gap-2.5 sm:gap-3 lg:gap-3 justify-start items-start w-full">
          {/* Header */}
          <div className="flex flex-row justify-between items-center w-full">
            <p className="text-lg sm:text-xl font-medium leading-tight text-left text-gray-900 dark:text-gray-100">
              Featured Strategy
            </p>
            <Link 
              to="/discover?tab=in-house"
              className="text-sm font-medium leading-5 text-left text-[#5266FC] dark:text-blue-400 underline cursor-pointer hover:opacity-80"
            >
              View More
            </Link>
          </div>

          {/* Strategies Slider */}
          <div 
            className="w-full overflow-x-auto pb-2 hide-scrollbar"
            style={{
              scrollbarWidth: 'none',
              msOverflowStyle: 'none',
            }}
          >
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-8 h-8 animate-spin text-[#5266FC]" />
                <span className="ml-3 text-gray-600 dark:text-gray-400">Loading strategies...</span>
              </div>
            ) : (
              <div className="flex flex-row gap-2 sm:gap-2.5 lg:gap-3 w-full">
                {filteredStrategies?.map((strategy) => (
                  <div key={strategy?.id} className="flex flex-col gap-2 sm:gap-2.5 lg:gap-2.5 justify-start items-start w-[240px] sm:w-[260px] lg:w-[280px] flex-shrink-0 border border-gray-200 dark:border-gray-700 rounded-sm p-4 sm:p-5 lg:p-5 bg-white dark:bg-gray-800 shadow-sm hover:shadow-md transition-shadow overflow-hidden min-w-0">
                    {/* Line 1: Strategy Name */}
                    <div className="flex flex-row justify-between items-start w-full min-w-0 gap-2">
                      <div className="flex flex-col gap-1 sm:gap-1 lg:gap-1 justify-start items-start flex-1 pr-2 min-w-0">
                        <p className="text-xs sm:text-sm font-medium leading-4 sm:leading-5 text-left text-gray-900 dark:text-gray-100 break-words w-full line-clamp-1">
                          {formatTitle(String(strategy?.title || strategy?.name || ""))}
                        </p>
                      </div>
                      <div className="flex flex-col justify-start items-end gap-1 flex-shrink-0">
                        <div className="flex flex-row justify-end items-start gap-1.5 sm:gap-2">
                          <button
                            onClick={() => toggleBookmark(strategy.id)}
                            className={`transition ${
                              bookmarkedStrategies.includes(strategy.id)
                                ? "text-[#5266FC]"
                                : "text-gray-400 hover:text-[#5266FC]"
                            }`}
                          >
                            <Bookmark
                              className="w-4 h-4 cursor-pointer"
                              fill={bookmarkedStrategies.includes(strategy.id) ? (document.documentElement.classList.contains('dark') ? "#60A5FA" : "#5266FC") : "none"}
                            />
                          </button>
                          <button 
                            onClick={() => {
                              setShareStrategyId(strategy.id)
                              setShareModalOpen(true)
                            }}
                            className="text-gray-400 dark:text-gray-500 hover:text-[#5266FC] dark:hover:text-blue-400 transition-colors cursor-pointer"
                          >
                            <Share2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Line 2: Last Deployed - Always reserve space */}
                    <div className="flex justify-end w-full min-h-[1rem] items-center -mt-1">
                      {isStrategyDeployed(strategy.id) && getDeployedTimestamp(strategy.id) ? (
                        <div className="border border-gray-200 dark:border-gray-700 rounded px-1 py-0.5">
                          <p className="text-[7px] sm:text-[8px] font-normal leading-none bg-gradient-to-r from-[#4d6ff7] via-[#3b9fd8] to-[#00e8b0] bg-clip-text text-transparent whitespace-nowrap" style={{ WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundSize: '100%' }}>
                            Last deployed {formatTimeAgo(getDeployedTimestamp(strategy.id)!)}
                          </p>
                        </div>
                      ) : null}
                    </div>

                    {/* Line 3: Tags Row */}
                    <div className="flex flex-row flex-wrap justify-start items-center w-full gap-1 sm:gap-1.5 lg:gap-1.5 overflow-hidden">
                      {Array.isArray(strategy?.tags) && strategy.tags.map((tag: string, index: number) => {
                        // Check if this is a risk level tag (but not the hardcoded "Medium" at the end)
                        // The hardcoded "Medium" should be the last tag, so check if it's the last occurrence
                        const tagArray = Array.isArray(strategy?.tags) ? strategy.tags : []
                        const isLastMedium = tag === "Medium" && index === tagArray.length - 1
                        const isRiskLevel = (tag === "Low" || tag === "Medium" || tag === "High") && !isLastMedium
                        return (
                          <span 
                            key={index} 
                            className={`text-[9px] sm:text-[10px] font-normal leading-3 text-left rounded px-1.5 sm:px-2 py-0.5 whitespace-nowrap ${
                              isRiskLevel 
                                ? "bg-amber-100 text-amber-700" 
                                : getTagStyle(tag)
                            }`}
                          >
                            {tag}
                          </span>
                        )
                      })}
                    </div>

                    {/* Lines 4-5: Description with Read more */}
                    <div className="w-full">
                      <p className="text-[10px] sm:text-xs font-normal leading-4 sm:leading-5 text-left text-gray-500 dark:text-gray-400 w-full line-clamp-2 overflow-hidden min-h-[2.5rem]">
                        {strategy?.description}
                      </p>
                      {strategy?.description && strategy.description.length > 80 && (
                        <button
                          onClick={() => {
                            const title = String(strategy?.title || strategy?.name || "")
                            const description = String(strategy?.description || "")
                            navigate(`/performance?strategyId=${strategy.id}&tab=performance&from=home`, { state: { from: "Home", strategyTitle: formatTitle(title), strategyDescription: description } })
                          }}
                          className="text-[10px] sm:text-xs font-medium text-[#5266FC] hover:underline mt-1 cursor-pointer"
                        >
                          Read more
                        </button>
                      )}
                    </div>

                    {/* Bottom Row */}
                    <div className="flex flex-row justify-between items-end w-full mt-auto gap-3 sm:gap-4 min-w-0">
                      <div className="flex flex-col justify-start items-start min-w-0 flex-1 basis-0">
                        <p className="text-[8px] sm:text-[9px] font-normal leading-3 text-left text-gray-500 dark:text-gray-400 whitespace-nowrap">
                          Min Capital
                        </p>
                        <p className="text-[11px] sm:text-xs font-medium leading-4 text-left text-gray-900 dark:text-gray-100 whitespace-nowrap truncate w-full">
                          {formatCapital(strategy?.minCapital)}
                        </p>
                      </div>
                      <div className="flex flex-col justify-start items-center min-w-0 flex-1 basis-0">
                        <p className="text-[8px] sm:text-[9px] font-normal leading-3 text-center text-gray-500 dark:text-gray-400 whitespace-nowrap">
                          Avg Return
                        </p>
                        <button
                          onClick={(e) => handleBacktestClick(strategy, e)}
                          className="text-[11px] sm:text-xs font-semibold leading-4 text-center whitespace-nowrap truncate w-full cursor-pointer hover:opacity-80 transition-opacity relative"
                          type="button"
                        >
                          <span className="relative inline-block">
                            <span 
                              className="inline-block bg-gradient-to-r from-[#4d6ff7] to-[#00e8b0] bg-clip-text text-transparent"
                              style={{
                                backgroundImage: 'linear-gradient(to right, #4d6ff7, #00e8b0)',
                                WebkitBackgroundClip: 'text',
                                WebkitTextFillColor: 'transparent',
                                backgroundClip: 'text',
                              }}
                            >
                              {String(strategy?.avgReturn || "Backtest")}
                            </span>
                            <span 
                              className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[85%] h-[1.5px] bg-gradient-to-r from-[#4d6ff7] to-[#00e8b0]"
                            />
                          </span>
                        </button>
                      </div>
                      <div className="flex flex-col justify-start items-start min-w-0 flex-1 basis-0">
                        <p className="text-[8px] sm:text-[9px] font-normal leading-3 text-left text-gray-500 dark:text-gray-400 whitespace-nowrap">
                          Status
                        </p>
                        {(() => {
                          const statusText = isStrategyDeployed(strategy.id) 
                            ? "Deployed" 
                            : formatStatus(strategy.status || (strategy as any).strategyStatus || "Available")
                          const statusLower = statusText.toLowerCase()
                          const statusColor = statusLower === "deployed" 
                            ? "text-green-600 dark:text-green-400" 
                            : statusLower === "error" 
                            ? "text-red-600 dark:text-red-400" 
                            : "text-amber-600 dark:text-amber-400"
                          return (
                            <p className={`text-[11px] sm:text-xs font-medium leading-4 text-left ${statusColor} whitespace-nowrap truncate w-full`}>
                              {statusText}
                            </p>
                          )
                        })()}
                      </div>
                      <button 
                        onClick={() => {
                          const title = String(strategy?.title || strategy?.name || "")
                          const description = String(strategy?.description || "")
                          navigate(`/performance?strategyId=${strategy.id}&tab=performance&from=home`, { state: { from: "Home", strategyTitle: formatTitle(title), strategyDescription: description } })
                        }}
                        className="w-7 h-7 sm:w-8 sm:h-8 p-1.5 bg-gradient-to-br from-[#5367fc] via-[#4d6ff7] to-[#00e8b0] rounded-sm hover:opacity-90 transition-opacity flex items-center justify-center flex-shrink-0 cursor-pointer ml-2"
                        title="View Performance"
                      >
                        <ArrowUpRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Deploy Strategy Dialog */}
      <Dialog open={deployDialogOpen} onOpenChange={handleDeployDialogClose}>
        <DialogContent className="sm:max-w-md p-0 gap-0 max-h-[90vh]">
          {deployError && (
            <div className="bg-red-50 border-b border-red-200 px-6 py-3">
              <p className="text-red-800 text-sm">{deployError}</p>
            </div>
          )}

          <div className="px-5 pt-5 pb-3">
            {/* Header with Icon and Title */}
            {selectedStrategy && (
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-full bg-[#5266FC] dark:bg-blue-500 flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-semibold text-xs">
                    {getStrategyInitials(selectedStrategy.name)}
                  </span>
                </div>
                <div>
                  <DialogTitle className="text-base font-semibold text-[#1e293b] mb-0">
                    {selectedStrategy.name} ({selectedStrategy.id})
                  </DialogTitle>
                </div>
              </div>
            )}

            <div className="space-y-3">
              {/* Multiplier and Execution Type - Labels on left, controls on right */}
              <div className="space-y-3">
                {/* Multiplier */}
                <div className="flex items-center justify-between gap-3">
                  <label className="text-xs font-medium text-gray-700 dark:text-gray-300">
                    Multiplier
                  </label>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleMultiplierChange(-1)}
                      disabled={deployLoading || multiplier <= 0}
                      className="w-8 h-8 flex items-center justify-center rounded border-0 bg-[#4D6FF7] text-white hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={multiplier}
                      onChange={(e) => {
                        const val = parseInt(e.target.value) || 0
                        setMultiplier(Math.max(0, Math.min(100, val)))
                        if (selectedStrategy) {
                          setMarginNeeded(calculateMarginNeeded(val, selectedStrategy))
                        }
                      }}
                      className="w-12 h-8 px-1 text-center text-sm font-medium border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100 rounded focus:outline-none focus:ring-1 focus:ring-[#5266FC] dark:focus:ring-blue-500 focus:border-transparent"
                      disabled={deployLoading}
                    />
                    <button
                      type="button"
                      onClick={() => handleMultiplierChange(1)}
                      disabled={deployLoading || multiplier >= 100}
                      className="w-8 h-8 flex items-center justify-center rounded border-0 bg-[#4D6FF7] text-white hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Divider Line */}
                <div className="border-t border-gray-200 dark:border-gray-700"></div>

                {/* Execution Type */}
                <div className="flex items-center justify-between gap-3">
                  <label className="text-xs font-medium text-gray-700 dark:text-gray-300">
                    Execution Type
                  </label>
                  <ToggleGroup
                    type="single"
                    value={executionTypeId === "PaperTrading" ? "PaperTrading" : "LiveTrading"}
                    onValueChange={(value) => {
                      if (value) {
                        setExecutionTypeId(value === "PaperTrading" ? "PaperTrading" : "LiveTrading")
                      }
                    }}
                    disabled={deployLoading}
                    className="bg-[#E8EAFF] rounded border-0 overflow-hidden w-auto"
                  >
                    <ToggleGroupItem
                      value="PaperTrading"
                      className="h-7 px-3 data-[state=on]:bg-[#5266FC] dark:data-[state=on]:bg-blue-500 data-[state=on]:text-white data-[state=off]:bg-transparent data-[state=off]:text-[#5266FC] dark:data-[state=off]:text-blue-400 border-0 rounded-none text-xs font-medium py-0 flex flex-col items-center justify-center"
                    >
                      <span>FORWARD</span>
                      <span className="text-[9px] font-normal leading-none">Simulation Trade</span>
                    </ToggleGroupItem>
                    <ToggleGroupItem
                      value="LiveTrading"
                      className="h-7 px-3 data-[state=on]:bg-[#5266FC] dark:data-[state=on]:bg-blue-500 data-[state=on]:text-white data-[state=off]:bg-transparent data-[state=off]:text-[#5266FC] dark:data-[state=off]:text-blue-400 border-0 rounded-none text-xs font-medium py-0"
                    >
                      LIVE
                    </ToggleGroupItem>
                  </ToggleGroup>
                </div>
              </div>

              {/* Deployment Nudges */}
              {executionTypeId === "PaperTrading" && (
                <div className="mt-4 p-4 bg-[#E8EAFF] dark:bg-blue-900/20 border border-[#5266FC] dark:border-blue-500 rounded-lg flex gap-3 animate-in slide-in-from-top-2 duration-300">
                  <Info className="w-5 h-5 text-[#5266FC] dark:text-blue-400 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-[#5266FC] dark:text-blue-400 mb-1">Forward Test Mode</div>
                    <div className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                      <strong>No real money will be used</strong> and <strong>no real trades will be placed on the exchange</strong>. This is a simulation mode to test your strategy performance using historical and live market data without any financial risk.
                    </div>
                  </div>
                </div>
              )}

              {executionTypeId === "LiveTrading" && selectedStrategy && (
                <div className="mt-4 p-4 bg-[#FEF3C7] dark:bg-yellow-900/20 border border-[#F59E0B] dark:border-yellow-500 rounded-lg flex gap-3 animate-in slide-in-from-top-2 duration-300">
                  <AlertTriangle className="w-5 h-5 text-[#F59E0B] dark:text-yellow-400 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-[#92400E] dark:text-yellow-400 mb-1">Capital Requirements Vary</div>
                    <div className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed mb-3">
                      Capital requirements are different for <strong>Expiry Day</strong> and <strong>Non-Expiry Day</strong>. Please ensure you have sufficient capital available.
                    </div>
                    <div className="bg-white dark:bg-gray-800 rounded-md p-3 border border-gray-200 dark:border-gray-700">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b border-gray-200 dark:border-gray-700">
                            <th className="text-left py-2 text-gray-600 dark:text-gray-400 font-semibold">Day Type</th>
                            <th className="text-left py-2 text-gray-600 dark:text-gray-400 font-semibold">Minimum Capital Required</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-b border-gray-100 dark:border-gray-700">
                            <td className="py-2 text-gray-700 dark:text-gray-300">Expiry Day</td>
                            <td className="py-2 font-semibold text-[#5266FC] dark:text-blue-400">
                              {(() => {
                                const expiryCapital = selectedStrategy.minCapital || selectedStrategy.requiredCapital || 0
                                return expiryCapital >= 100000 
                                  ? `₹${(expiryCapital / 100000).toFixed(2)}L`
                                  : expiryCapital >= 1000
                                  ? `₹${(expiryCapital / 1000).toFixed(2)}K`
                                  : `₹${expiryCapital.toLocaleString('en-IN')}`
                              })()}
                            </td>
                          </tr>
                          <tr>
                            <td className="py-2 text-gray-700 dark:text-gray-300">Non-Expiry Day</td>
                            <td className="py-2 font-semibold text-[#5266FC] dark:text-blue-400">
                              {(() => {
                                const expiryCapital = selectedStrategy.minCapital || selectedStrategy.requiredCapital || 0
                                const nonExpiryCapital = (selectedStrategy as any).nonExpiryCapital || Math.round(expiryCapital * 0.7)
                                return nonExpiryCapital >= 100000 
                                  ? `₹${(nonExpiryCapital / 100000).toFixed(2)}L`
                                  : nonExpiryCapital >= 1000
                                  ? `₹${(nonExpiryCapital / 1000).toFixed(2)}K`
                                  : `₹${nonExpiryCapital.toLocaleString('en-IN')}`
                              })()}
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* Margin Information - Single Row */}
              <div className="flex justify-between items-center pt-3 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-600 dark:text-gray-400">Margin Needed</span>
                  <span className="text-sm text-gray-900 dark:text-gray-100">
                    {new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 }).format(marginNeeded)}
                  </span>
                </div>
                <div className="flex items-center gap-2 ml-auto">
                  <span className="text-xs text-gray-600 dark:text-gray-400">Margin Available</span>
                  <span className="text-sm text-gray-900 dark:text-gray-100">
                    {new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(marginAvailable)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Buttons - Right Side */}
          <div className="px-5 py-3 border-t border-gray-200 dark:border-gray-700 flex justify-end gap-2">
            <Button
              type="button"
              onClick={() => handleDeployDialogClose(false)}
              disabled={deployLoading}
              className="px-4 py-1.5 bg-white dark:bg-gray-800 border border-[#5266FC] dark:border-blue-500 text-[#5266FC] dark:text-blue-400 hover:bg-gray-50 dark:hover:bg-gray-700 text-xs font-medium h-8"
            >
              CANCEL
            </Button>
            <Button
              type="button"
              onClick={handleDeploySubmit}
              disabled={deployLoading || !selectedStrategy || multiplier <= 0}
              className="px-4 py-1.5 bg-gradient-to-r from-[#3B5BD9] via-[#4D6FF7] to-[#00e8b0] dark:from-blue-500 dark:via-blue-600 dark:to-blue-500 text-white hover:opacity-90 text-xs font-medium h-8"
            >
              {deployLoading ? (
                <>
                  <Loader2 className="w-3 h-3 mr-1.5 animate-spin" />
                  Deploying...
                </>
              ) : (
                "Deploy"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share Modal */}
      <Dialog open={shareModalOpen} onOpenChange={setShareModalOpen}>
        <DialogContent className="sm:max-w-md p-6">
          <div className="flex flex-col items-center">
            {/* Share GIF */}
            <div className="mb-4 flex justify-center">
              <img 
                src="/images/share.gif" 
                alt="Share" 
                className="w-16 h-16 object-contain"
              />
            </div>

            {/* Title */}
            <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">Share Your Strategy</h2>
            
            {/* Description */}
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center mb-4">
              Use the link below to quickly share this strategy anywhere.
            </p>

            {/* Link Input and Copy Button */}
            <div className="flex items-center gap-2 w-full mb-4">
              <input
                type="text"
                value={`https://bigul.co/bigul-algos`}
                readOnly
                className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm text-gray-700 dark:text-gray-100 bg-gray-50 dark:bg-gray-800"
              />
              <Button
                onClick={() => {
                  navigator.clipboard.writeText('https://bigul.co/bigul-algos')
                }}
                className="px-4 py-2 bg-[#5266FC] dark:bg-blue-500 hover:bg-[#3d4fc7] dark:hover:bg-blue-600 text-white rounded-lg text-sm font-medium whitespace-nowrap"
              >
                Copy
              </Button>
            </div>

            {/* Also share on */}
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">Also share on:</p>

            {/* Social Media Icons */}
            <div className="flex items-center gap-2 w-full justify-center">
              {/* Facebook */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <span className="text-white font-bold text-sm">f</span>
              </button>
              
              {/* Email */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </button>
              
              {/* X (Twitter) */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </button>
              
              {/* Instagram */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </button>
              
              {/* YouTube */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                </svg>
              </button>
              
              {/* Telegram */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                </svg>
              </button>
              
              {/* WhatsApp */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Backtest Consent Dialog */}
      <Dialog open={backtestConsentOpen} onOpenChange={setBacktestConsentOpen}>
        <DialogContent className="sm:max-w-md p-0 gap-0">
          <div className="px-5 pt-5 pb-3">
            <DialogHeader>
              <DialogTitle className="text-base font-semibold text-[#1e293b] dark:text-gray-100 mb-0 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500 dark:text-amber-400" />
                Backtesting: Please note
              </DialogTitle>
            </DialogHeader>
            
            <div className="mt-4 space-y-2.5">
              <div className="flex items-start gap-2.5">
                <span className="text-[#5266FC] dark:text-blue-400 mt-0.5">•</span>
                <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                  Backtesting is based on historical market data and assumes ideal trading conditions.
                </p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="text-[#5266FC] dark:text-blue-400 mt-0.5">•</span>
                <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                  These results do not reflect actual trades or live market execution.
                </p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="text-[#5266FC] dark:text-blue-400 mt-0.5">•</span>
                <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                  Past performance is not indicative of future returns.
                </p>
              </div>
            </div>
          </div>

          <DialogFooter className="px-5 pb-4 pt-3 border-t border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-2 w-full">
              <Button
                variant="outline"
                onClick={() => {
                  setBacktestConsentOpen(false)
                  setPendingBacktestStrategy(null)
                }}
                className="flex-1 h-9 text-xs"
              >
                Cancel
              </Button>
              <Button
                onClick={handleBacktestConsent}
                disabled={backtestLoading}
                className="flex-1 h-9 text-xs bg-[#5266FC] hover:bg-[#4255E6] text-white disabled:opacity-50"
              >
                {backtestLoading ? (
                  <>
                    <Loader2 className="w-3 h-3 mr-1.5 animate-spin" />
                    Loading...
                  </>
                ) : (
                  "I understand. Backtest Now"
                )}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  )
}

// Memoize component to prevent unnecessary re-renders
export default React.memo(FeaturedStrategies)

