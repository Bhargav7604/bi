"use client"

import { useRef } from "react"
import { Star, ChevronLeft, ChevronRight } from "lucide-react"

export default function Testimonials() {
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const testimonials = [
    {
      id: 1,
      rating: 4,
      text: "I have used so many Algo platforms, but Bigul's is the best interface and smoothest quality, I have seen.",
      name: "Sagar Sharma, Delhi",
      date: "May 8, 2025",
    },
    {
      id: 2,
      rating: 5,
      text: "I forward tested this for 2 weeks and made ₹18K virtual profit. Now running live for 1 month — up ₹34K real money!",
      name: "Anant G, Mumbai",
      date: "Jun 12, 2025",
    },
    {
      id: 3,
      rating: 4,
      text: "I have been on Biguls Algo platform since last 3 months and has been a hassle free journey so far. Thank you.",
      name: "Aditya N, Indore",
      date: "May 5, 2025",
    },
  ]

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      const cardWidth = 280 // Base card width + gap
      scrollContainerRef.current.scrollBy({
        left: -cardWidth,
        behavior: "smooth",
      })
    }
  }

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      const cardWidth = 280 // Base card width + gap
      scrollContainerRef.current.scrollBy({
        left: cardWidth,
        behavior: "smooth",
      })
    }
  }

  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating)
    const totalStars = 5

    return (
      <div className="flex flex-row justify-start items-center gap-0.5">
        {[...Array(totalStars)].map((_, index) => (
          <Star
            key={index}
            className={`w-4 h-4 ${
              index < fullStars
                ? "fill-amber-400 dark:fill-amber-500 text-amber-400 dark:text-amber-500"
                : "fill-none text-gray-300 dark:text-gray-600 stroke-gray-300 dark:stroke-gray-600"
            }`}
          />
        ))}
      </div>
    )
  }

  return (
    <section className="w-full bg-[#F5F5F5] dark:bg-gray-950 py-3 sm:py-3.5 lg:py-4">
      <div className="w-full max-w-[1440px] mx-auto px-8 sm:px-12 lg:px-28">
        <div className="flex flex-col gap-2.5 sm:gap-3 lg:gap-3 justify-start items-center w-full">
          {/* Header - Centered */}
          <div className="flex flex-row justify-center items-center w-full">
            <h2 className="text-lg sm:text-xl font-medium leading-tight text-center text-gray-900 dark:text-gray-100">
              Testimonials
            </h2>
          </div>

          {/* Testimonials Slider with Navigation */}
          <div className="relative w-full">
            {/* Testimonials Slider - Centered */}
            <div
              ref={scrollContainerRef}
              className="w-full overflow-x-auto pb-2 hide-scrollbar scroll-smooth relative"
            >
              {/* Navigation Arrows - Inside the scroll container */}
              <button
                onClick={scrollLeft}
                className="absolute left-2 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full shadow-lg flex items-center justify-center hover:opacity-80 transition-all bg-[#5367FC33] dark:bg-blue-500/30"
                aria-label="Scroll left"
              >
                <ChevronLeft className="w-5 h-5 text-[#5367FC] dark:text-blue-400" />
              </button>

              <button
                onClick={scrollRight}
                className="absolute right-2 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full shadow-lg flex items-center justify-center hover:opacity-80 transition-all bg-[#5367FC33] dark:bg-blue-500/30"
                aria-label="Scroll right"
              >
                <ChevronRight className="w-5 h-5 text-[#5367FC] dark:text-blue-400" />
              </button>

              <div className="flex flex-row gap-2.5 sm:gap-3 lg:gap-3 justify-center items-stretch w-full">
                {testimonials.map((testimonial) => (
                  <div
                    key={testimonial.id}
                    className="flex flex-col gap-2.5 sm:gap-3 lg:gap-3 justify-start items-start w-[240px] sm:w-[260px] lg:w-[280px] flex-shrink-0 border border-gray-200 dark:border-gray-700 rounded-sm p-3.5 sm:p-4 lg:p-4 bg-white dark:bg-gray-800 shadow-sm hover:shadow-md transition-shadow"
                  >
                    {renderStars(testimonial.rating)}

                    <p className="text-xs sm:text-sm font-normal leading-4 sm:leading-5 text-left text-gray-500 dark:text-gray-400 w-full flex-1 line-clamp-4">
                      {testimonial.text}
                    </p>

                    <div className="flex flex-col gap-0.5 justify-start items-start w-full">
                      <p className="text-sm font-medium leading-5 text-left text-gray-900 dark:text-gray-100">
                        {testimonial.name}
                      </p>
                      <p className="text-xs font-normal leading-4 text-left text-gray-500 dark:text-gray-400">
                        {testimonial.date}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

