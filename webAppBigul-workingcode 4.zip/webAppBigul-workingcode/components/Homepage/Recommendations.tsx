"use client"

import { Link } from "react-router-dom"

export default function Recommendations() {
  const recommendations = [
    {
      id: 1,
      icon: "/images/img_group_289531_indigo_a200.svg",
      title: "Most Deployed Strategy",
      description: "Join the crowd with our most trusted and frequently deployed strategies.",
      link: "Explore Now >",
      isImage: true,
    },
    {
      id: 2,
      icon: "/images/img_group_289531_indigo_a200_56x56.svg",
      title: "Growth-Focused Equity Strategy",
      description: "Build long-term wealth with strategies designed for capital appreciation.",
      link: "Explore Now >",
      isImage: true,
    },
    {
      id: 3,
      icon: "/images/img_group_289531_56x56.svg",
      title: "Newly Added Strategy",
      description: "Check out the strategies that have been newly added to our pallette after extensive research and testing.",
      link: "Explore Now >",
      isImage: true,
    },
    {
      id: 4,
      icon: "/images/img_group_289531_1.svg",
      title: "High Risk-Reward Strategy",
      description: "Strategies built for traders willing to put in more capital and target higher returns.",
      link: "Explore Now >",
      isImage: true,
    },
  ]

  return (
    <section className="w-full bg-[#F5F5F5] dark:bg-gray-950 py-3 sm:py-3.5 lg:py-4">
      <div className="w-full max-w-[1440px] mx-auto px-8 sm:px-12 lg:px-28">
        <div className="flex flex-col gap-2.5 sm:gap-3 lg:gap-3 justify-start items-start w-full">
          <p className="text-lg sm:text-xl font-medium leading-tight text-left text-gray-900 dark:text-gray-100">
            You may also like:
          </p>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-2.5 sm:gap-3 lg:gap-3 w-full">
            {recommendations?.map((item) => (
              <div key={item?.id} className="flex flex-row gap-2.5 sm:gap-3 lg:gap-3 justify-start items-start w-full border border-gray-200 dark:border-gray-700 rounded-sm p-3 sm:p-4 bg-white dark:bg-gray-800 hover:shadow-md transition-shadow">
                {item?.isImage ? (
                  <img 
                    src={item?.icon} 
                    alt={item?.title}
                    className="w-14 h-14 flex-shrink-0"
                  />
                ) : (
                  <div className="text-3xl sm:text-4xl flex-shrink-0">{item?.icon}</div>
                )}
                <div className="flex flex-col gap-1.5 sm:gap-2 lg:gap-2 justify-start items-start flex-1">
                  <p className="text-lg font-medium leading-6 text-left text-gray-900 dark:text-gray-100">
                    {item?.title}
                  </p>
                  <p className="text-sm font-normal leading-5 text-left text-gray-500 dark:text-gray-400 whitespace-pre-line">
                    {item?.description}
                  </p>
                  <Link 
                    to="/discover"
                    className="text-sm font-normal leading-5 text-left text-[#5266FC] dark:text-blue-400 underline cursor-pointer hover:opacity-80 transition-opacity"
                  >
                    {item?.link}
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

