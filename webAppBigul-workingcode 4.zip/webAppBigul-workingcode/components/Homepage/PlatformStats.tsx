"use client"

export default function PlatformStats() {
  const stats = [
    {
      id: 1,
      value: "40k+",
      label: "Platform Users",
    },
    {
      id: 2,
      value: "20+",
      label: "Research Analysts",
    },
    {
      id: 3,
      value: "1.35L+",
      label: "Trades Taken",
    },
    {
      id: 4,
      value: "70L+",
      label: "Strategies Deployed",
    },
  ]

  return (
    <section className="w-full bg-[#F5F5F5] dark:bg-gray-950 py-3 sm:py-3.5 lg:py-4">
      <div className="w-full max-w-[1440px] mx-auto px-8 sm:px-12 lg:px-28">
        <div className="flex flex-row justify-start items-center w-full">
          <div className="flex flex-row justify-center items-center w-full rounded-lg py-3 sm:py-3.5 lg:py-4 min-h-[70px] sm:min-h-[85px] lg:min-h-[100px] relative overflow-hidden bg-[#5266FC] dark:bg-gray-800">
            {/* Rangoli decorative elements - Bottom Left Corner */}
            <div className="absolute bottom-0 left-0 w-32 h-32 sm:w-40 sm:h-40 lg:w-48 lg:h-48">
              <svg width="100%" height="100%" viewBox="0 0 192 192" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="0" cy="192" r="80" stroke="white" strokeWidth="2.5" fill="none" opacity="0.9" />
                <circle cx="0" cy="192" r="65" stroke="white" strokeWidth="2" fill="none" opacity="0.85" />
                <circle cx="0" cy="192" r="50" stroke="white" strokeWidth="2" fill="none" opacity="0.8" />
                <circle cx="0" cy="192" r="38" stroke="white" strokeWidth="1.8" fill="none" opacity="0.75" />
                <circle cx="0" cy="192" r="28" stroke="white" strokeWidth="1.5" fill="none" opacity="0.7" />
                <circle cx="0" cy="192" r="20" stroke="white" strokeWidth="1.5" fill="none" opacity="0.65" />
                <circle cx="0" cy="192" r="14" stroke="white" strokeWidth="1.2" fill="none" opacity="0.6" />
                <circle cx="0" cy="192" r="8" stroke="white" strokeWidth="1" fill="none" opacity="0.55" />
                <circle cx="0" cy="192" r="4" stroke="white" strokeWidth="1" fill="white" opacity="0.5" />
              </svg>
            </div>

            {/* Rangoli decorative elements - Top Right Corner */}
            <div className="absolute top-0 right-0 w-32 h-32 sm:w-40 sm:h-40 lg:w-48 lg:h-48">
              <svg width="100%" height="100%" viewBox="0 0 192 192" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="192" cy="0" r="80" stroke="white" strokeWidth="2.5" fill="none" opacity="0.9" />
                <circle cx="192" cy="0" r="65" stroke="white" strokeWidth="2" fill="none" opacity="0.85" />
                <circle cx="192" cy="0" r="50" stroke="white" strokeWidth="2" fill="none" opacity="0.8" />
                <circle cx="192" cy="0" r="38" stroke="white" strokeWidth="1.8" fill="none" opacity="0.75" />
                <circle cx="192" cy="0" r="28" stroke="white" strokeWidth="1.5" fill="none" opacity="0.7" />
                <circle cx="192" cy="0" r="20" stroke="white" strokeWidth="1.5" fill="none" opacity="0.65" />
                <circle cx="192" cy="0" r="14" stroke="white" strokeWidth="1.2" fill="none" opacity="0.6" />
                <circle cx="192" cy="0" r="8" stroke="white" strokeWidth="1" fill="none" opacity="0.55" />
                <circle cx="192" cy="0" r="4" stroke="white" strokeWidth="1" fill="white" opacity="0.5" />
              </svg>
            </div>

            {/* Stats content */}
            <div className="grid grid-cols-2 sm:flex sm:flex-row gap-4 sm:gap-6 lg:gap-8 justify-center items-center w-full px-4 sm:px-6 lg:px-8 z-10 relative">
              {stats?.map((stat) => (
                <div key={stat?.id} className="flex flex-col justify-start items-center w-auto">
                  <p className="text-lg sm:text-xl lg:text-2xl font-bold leading-tight text-center font-[Poppins] text-white dark:text-gray-100">
                    {stat?.value}
                  </p>
                  <p className="text-xs sm:text-base lg:text-lg font-normal leading-snug text-center font-[Poppins] text-white dark:text-gray-400">
                    {stat?.label}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

