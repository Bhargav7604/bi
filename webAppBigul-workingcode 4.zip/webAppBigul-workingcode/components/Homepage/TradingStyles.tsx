"use client"

import { Link } from "react-router-dom"

export default function TradingStyles() {
  const tradingStyles = [
    {
      id: 1,
      icon: "/images/img_group_289530.svg",
      title: "Intraday Equity",
      description: "Capitalize on daily stock volatility with zero overnight risk.",
      link: "Explore Now >",
      isImage: true,
    },
    {
      id: 2,
      icon: "/images/img_group_289531.svg",
      title: "Options Buying",
      description: "High-momentum strategies designed to catch explosive moves.",
      link: "Explore Now >",
      isImage: true,
    },
    {
      id: 3,
      icon: "/images/img_group_289532.svg",
      title: "Options Selling – Hedged",
      description: "Consistent income generation using time decay and defined risk.",
      link: "Explore Now >",
      isImage: true,
    },
    {
      id: 4,
      icon: "S",
      title: "Swing & Positional",
      description: "Trend-following algorithms that hold positions for days to weeks.",
      link: "Explore Now >",
      isTextIcon: true,
    },
  ]

  return (
    <section className="w-full bg-[#F5F5F5] dark:bg-gray-950 py-3 sm:py-3.5 lg:py-4">
      <div className="w-full max-w-[1440px] mx-auto px-8 sm:px-12 lg:px-28">
        <div className="flex flex-col gap-2.5 sm:gap-3 lg:gap-3 justify-start items-start w-full">
          <p className="text-lg sm:text-xl font-medium leading-tight text-left text-gray-900 dark:text-gray-100">
            Choose your Trading Style
          </p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-2.5 lg:gap-3 w-full">
            {tradingStyles?.map((style) => (
              <div key={style?.id} className="flex flex-col gap-2 sm:gap-2 lg:gap-2 justify-start items-start w-full border border-gray-200 dark:border-gray-700 rounded-sm p-3 sm:p-3 lg:p-3 bg-white dark:bg-gray-800 hover:shadow-md transition-shadow">
                {/* Icon */}
                <div className="w-12 h-12 flex items-center justify-center">
                  {style?.isTextIcon ? (
                    <div className="w-12 h-12 text-2xl font-medium leading-8 text-center font-[Poppins] text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
                      {style?.icon}
                    </div>
                  ) : style?.isImage ? (
                    <img 
                      src={style?.icon} 
                      alt={style?.title}
                      className="w-12 h-12"
                    />
                  ) : (
                    <div className="text-3xl">{style?.icon}</div>
                  )}
                </div>
                
                {/* Content */}
                <div className="flex flex-col gap-1.5 sm:gap-2 lg:gap-2 justify-start items-start flex-1 w-full">
                  <p className="text-base font-medium leading-5 text-left text-gray-900 dark:text-gray-100">
                    {style?.title}
                  </p>
                  <p className="text-xs sm:text-sm font-normal leading-4 sm:leading-5 text-left text-gray-600 dark:text-gray-400 w-full line-clamp-2">
                    {style?.description}
                  </p>
                  <Link 
                    to="/discover"
                    className="text-xs sm:text-sm font-normal leading-4 sm:leading-5 text-left text-[#5266FC] dark:text-blue-400 underline cursor-pointer hover:opacity-80 transition-opacity"
                  >
                    {style?.link}
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

