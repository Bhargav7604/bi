"use client"

import { useActiveStrategies } from "@/hooks/useActiveStrategies"

export default function DashboardMetrics() {
  const { activeStrategies, loading } = useActiveStrategies()

  // Filter strategies by LIVE execution type (matching MyStrategyPage default)
  const filteredStrategies = activeStrategies.filter((strategy) => {
    return strategy.execution === "LiveTrading"
  })

  // Calculate metrics from filtered strategies (matching MyStrategyPage logic)
  const activeStrategyCount = filteredStrategies.length
  const deployedCapital = filteredStrategies.reduce((sum, strategy) => sum + (strategy.capital || 0), 0)
  const totalMtm = filteredStrategies.reduce((sum, strategy) => sum + (strategy.strategyMtm || 0), 0)

  // Format capital (in lakhs) - matches user format like "42.00L"
  const formatCapital = (amount: number): string => {
    if (amount >= 100000) {
      return `${(amount / 100000).toFixed(2)}L`
    }
    if (amount >= 1000) {
      return `${(amount / 1000).toFixed(2)}K`
    }
    return `${amount.toLocaleString("en-IN")}`
  }

  // Format P&L
  const formatPnL = (amount: number): string => {
    const absAmount = Math.abs(amount)
    if (absAmount >= 100000) {
      return `₹${(absAmount / 100000).toFixed(2)}L`
    }
    if (absAmount >= 1000) {
      return `₹${(absAmount / 1000).toFixed(2)}K`
    }
    return `₹${absAmount.toLocaleString("en-IN")}`
  }

  const metrics = [
    {
      id: 1,
      value: loading ? "..." : String(activeStrategyCount || 0),
      label: "Active Strategy",
      icon: "/images/img_strategy_1.gif",
    },
    {
      id: 2,
      value: loading ? "..." : deployedCapital > 0 ? formatCapital(deployedCapital) : "₹0",
      label: "Deployed Capital",
      icon: "/images/img_revenue_1.gif",
    },
    {
      id: 3,
      value: loading ? "..." : totalMtm !== 0 ? formatPnL(totalMtm) : "₹0",
      label: "Today P&L",
      icon: "/images/Profit1.gif",
      valueColor: totalMtm >= 0 ? "text-green-500" : "text-red-500",
    },
    {
      id: 4,
      value: loading ? "..." : totalMtm !== 0 ? formatPnL(totalMtm) : "₹0",
      label: "Overall P&L",
      icon: "/images/InvestmentProfit.gif",
      valueColor: totalMtm >= 0 ? "text-green-500" : "text-red-500",
    },
  ]

  return (
    <section className="w-full bg-[#F5F5F5] dark:bg-gray-950 py-2.5 sm:py-3 lg:py-3.5">
      <div className="w-full max-w-[1440px] mx-auto px-8 sm:px-12 lg:px-28">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-2.5 lg:gap-2.5">
          {metrics?.map((metric) => (
            <div key={metric?.id} className="w-full">
              <div className="py-2 px-2.5 border border-gray-200 dark:border-gray-700 rounded-md flex items-center justify-between bg-white dark:bg-gray-800">
                <div className="flex flex-col gap-0 justify-start items-start flex-1">
                  <p className={`text-lg font-bold ${metric?.valueColor || "text-gray-900 dark:text-gray-100"} ${metric?.valueColor === "text-green-500" ? "dark:text-green-400" : ""} ${metric?.valueColor === "text-red-500" ? "dark:text-red-400" : ""}`}>
                    {metric?.value}
                  </p>
                  <p className="text-[10px] text-gray-500 dark:text-gray-400">
                    {metric?.label}
                  </p>
                </div>
                <div className="flex-shrink-0 ml-1.5">
                  <img 
                    src={metric?.icon} 
                    alt={metric?.label}
                    className="w-12 h-12 sm:w-14 sm:h-14 object-contain"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

