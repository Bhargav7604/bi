"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const faqs = [
    {
      id: 1,
      question: "What is Bigul Algo?",
      answer:
        "Bigul Algo is a comprehensive algorithmic trading platform that allows you to backtest, forward test, and deploy trading strategies in live markets with advanced analytics and risk management.",
    },
    {
      id: 2,
      question: "Can I use pre-built strategies?",
      answer:
        "Yes, we offer a wide range of pre-built, backtested strategies across different asset classes and trading styles that you can deploy directly or customize according to your preferences.",
    },
    {
      id: 3,
      question: "Is there any fee/subscription to use the Algo platform?",
      answer:
        "We offer flexible pricing plans including free tier for beginners and premium plans for advanced users. Check our pricing page for detailed information about features and costs.",
    },
    {
      id: 4,
      question: "Do I need coding knowledge to use Bigul Algo?",
      answer:
        "No coding knowledge is required. Our platform provides an intuitive drag-and-drop interface for strategy building, though we also support custom coding for advanced users who prefer it.",
    },
  ]

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <section className="w-full bg-[#F5F5F5] dark:bg-gray-950 py-3 sm:py-3.5 lg:py-4 pb-8 sm:pb-10 lg:pb-12">
      <div className="w-full max-w-[1440px] mx-auto px-8 sm:px-12 lg:px-28">
        <div className="flex flex-col gap-2.5 sm:gap-3 lg:gap-3 justify-start items-center w-full">
          <p className="text-lg sm:text-xl font-normal leading-tight text-center text-gray-900 dark:text-gray-100">
            Frequently Asked Questions
          </p>

          <div className="flex flex-col gap-2 sm:gap-2.5 lg:gap-3 w-full max-w-4xl">
            {faqs.map((faq, index) => (
              <div key={faq.id} className="flex flex-col">
                <button
                  onClick={() => toggleFAQ(index)}
                  className="flex flex-row justify-between items-center w-full bg-white dark:bg-gray-800 rounded-md p-3 sm:p-4 lg:p-4 hover:opacity-90 dark:hover:bg-gray-700 transition-opacity border border-gray-200 dark:border-gray-700"
                  aria-expanded={openIndex === index}
                  aria-controls={`faq-answer-${faq.id}`}
                >
                  <p className="text-lg font-normal leading-6 text-left text-gray-900 dark:text-gray-100 flex-1 text-left">
                    {faq.question}
                  </p>
                  <ChevronDown
                    className={`w-5 h-5 text-gray-600 dark:text-gray-400 transition-transform duration-200 flex-shrink-0 ${
                      openIndex === index ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {openIndex === index && (
                  <div
                    id={`faq-answer-${faq.id}`}
                    className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-sm p-3 sm:p-4 lg:p-4 mt-1.5"
                  >
                    <p className="text-sm font-normal leading-5 text-left text-gray-500 dark:text-gray-400">
                      {faq.answer}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

