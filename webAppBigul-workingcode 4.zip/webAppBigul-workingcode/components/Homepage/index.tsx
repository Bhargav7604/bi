"use client"

import HeroSection from "./HeroSection"
import DashboardMetrics from "./DashboardMetrics"
import FeaturedStrategies from "./FeaturedStrategies"
import TradingStyles from "./TradingStyles"
import PlatformStats from "./PlatformStats"
import Recommendations from "./Recommendations"
import Testimonials from "./Testimonials"
import FAQ from "./FAQ"

interface HomepageProps {
  onNavChange?: (nav: string) => void
}

export default function Homepage({ onNavChange }: HomepageProps) {
  return (
    <main className="min-h-screen bg-[#F5F5F5] dark:bg-gray-950 pb-8 sm:pb-10 lg:pb-12">
      <HeroSection onNavChange={onNavChange} />
      <DashboardMetrics />
      <FeaturedStrategies />
      <TradingStyles />
      <PlatformStats />
      <Recommendations />
      <Testimonials />
      <FAQ />
    </main>
  )
}

