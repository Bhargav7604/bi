import { Link } from "react-router-dom"

interface HeroSectionProps {
  onNavChange?: (nav: string) => void
}

export default function HeroSection({ onNavChange }: HeroSectionProps) {
  return (
    <section className="w-full flex justify-center items-center pt-20 sm:pt-24"> 
      <div className="w-full max-w-[1440px] mx-auto px-8 sm:px-12 lg:px-28"> 
        <div className="w-full bg-gradient-to-l from-[#16C9C3] to-[#4D6FF7] dark:bg-gray-800 shadow-lg">
          <div className="w-full px-5 py-4 sm:px-8 sm:py-6 md:px-10 lg:px-12">
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-2 lg:gap-3 w-full">
              <div className="flex flex-col gap-1 sm:gap-1.5 lg:gap-2 justify-start items-start flex-1 min-w-0">
                <h1 className="text-sm sm:text-xl lg:text-2xl font-black italic leading-tight text-left text-white dark:text-gray-100 break-words flex items-center flex-wrap gap-1 sm:gap-1.5">
                  <span className="text-white dark:text-gray-100">Backtest</span>
                  <span className="text-sm sm:text-xl lg:text-2xl text-white dark:text-gray-100 flex items-center">&gt;&gt;</span>
                  <span className="text-white dark:text-gray-100">Forward Test</span>
                  <span className="text-sm sm:text-xl lg:text-2xl text-white dark:text-gray-100 flex items-center">&gt;&gt;</span>
                  <span className="text-white dark:text-gray-100">Live Trade</span>
                </h1>
                <p className="text-xs sm:text-sm lg:text-base font-normal leading-snug text-left text-white/95 dark:text-gray-200">
                  The complete engine to explore Algos and optimize your future returns.
                </p>
              </div>
              <div className="flex justify-start sm:justify-end items-center flex-shrink-0">
                <Link 
                  to="/discover"
                  onClick={() => onNavChange?.("discover")}
                  className="px-3 sm:px-4 py-1.5 sm:py-2 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 border border-gray-200 dark:border-gray-700 rounded-md text-xs sm:text-sm font-medium hover:bg-gray-50 dark:hover:bg-gray-700 hover:shadow-md transition-all cursor-pointer whitespace-nowrap shadow-sm inline-block text-center w-full sm:w-auto"
                >
                  Discover Strategies
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}