'use client'

import { Toaster as Sonner } from 'sonner'

const Toaster = () => {
  return (
    <Sonner
      position="top-right"
      richColors
      closeButton
      duration={4000}
      className="toaster group"
      toastOptions={{
        style: {
          color: '#5F5BFB',
        },
        className: 'toast-blue-text',
      }}
    />
  )
}

export { Toaster }
