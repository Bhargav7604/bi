'use client'

import { cn } from '@/lib/utils'

interface CustomSwitchProps {
  checked?: boolean
  onChange?: (checked: boolean) => void
  className?: string
}

export default function CustomSwitch({
  checked = false,
  onChange,
  className,
}: CustomSwitchProps) {
  return (
    <div
      onClick={() => onChange?.(!checked)}
      className={cn(
        "relative inline-flex h-5 w-9 cursor-pointer rounded-full transition-colors",
        checked ? "bg-blue-600" : "bg-gray-300",
        className
      )}
    >
      <div
        className={cn(
          "absolute top-0.5 h-4 w-4 rounded-full bg-white shadow-sm transition-transform",
          checked ? "translate-x-4" : "translate-x-0.5"
        )}
      />
    </div>
  )
}

