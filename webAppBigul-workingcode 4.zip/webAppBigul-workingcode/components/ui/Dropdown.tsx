import React from 'react';
import { twMerge } from 'tailwind-merge';

interface DropdownOption {
  value: string;
  label: string;
}

interface DropdownProps extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, 'size'> {
  // Design system parameters
  placeholder?: string;
  text_font_size?: string;
  text_font_family?: string;
  text_font_weight?: string;
  text_color?: string;
  border_border?: string;
  border_border_radius?: string;
  padding?: string;
  layout_width?: string;
  options?: DropdownOption[];
  fill_background_color?: string;
}

const Dropdown: React.FC<DropdownProps> = ({
  placeholder = "Select",
  text_font_size = "11",
  text_font_family = "Poppins",
  text_font_weight = "400",
  text_color = "#5266FC",
  border_border = "1px solid #BFC5FF",
  border_border_radius = "3px",
  padding = "t=4px,r=22px,b=4px,l=10px",
  layout_width,
  options = [],
  fill_background_color = "#ffffff",
  className,
  ...props
}) => {
  // Map font size to Tailwind classes
  const getFontSizeClass = (size: string): string => {
    const sizeMap: Record<string, string> = {
      '7': 'text-sm',
      '8': 'text-base',
      '9': 'text-md',
      '10': 'text-lg',
      '11': 'text-xl',
      '12': 'text-2xl',
      '14': 'text-3xl'
    };
    return sizeMap?.[size] || `text-[${size}px]`;
  };

  const getFontWeightClass = (weight: string): string => {
    const weightMap: Record<string, string> = {
      '400': 'font-normal',
      '500': 'font-medium',
      '600': 'font-semibold'
    };
    return weightMap?.[weight] || `font-[${weight}]`;
  };

  const getTextColorClass = (color: string): string => {
    const colorMap: Record<string, string> = {
      '#5367fc': 'text-[#5367fc]',
      '#5266FC': 'text-[#5266FC]',
      '#BFC5FF': 'text-[#BFC5FF]',
      '#000000': 'text-black'
    };
    return colorMap?.[color] || `text-[${color}]`;
  };

  const getBorderRadiusClass = (radius: string): string => {
    const radiusMap: Record<string, string> = {
      '2px': 'rounded-sm',
      '3px': 'rounded-sm',
      '4px': 'rounded'
    };
    return radiusMap?.[radius] || `rounded-[${radius}]`;
  };

  const getBackgroundColorClass = (color: string): string => {
    const colorMap: Record<string, string> = {
      '#ffffff': 'bg-white',
      '#e7eaff': 'bg-[#e7eaff]'
    };
    return colorMap?.[color] || `bg-[${color}]`;
  };

  const parsePadding = (pad: string): string => {
    if (!pad) return '';
    const parts = pad.split(',');
    const paddingObj: { top?: string; right?: string; bottom?: string; left?: string } = {};
    parts.forEach(part => {
      const [key, value] = part.split('=');
      if (key === 't') paddingObj.top = value;
      if (key === 'r') paddingObj.right = value;
      if (key === 'b') paddingObj.bottom = value;
      if (key === 'l') paddingObj.left = value;
    });
    return `${paddingObj.top || '0'} ${paddingObj.right || '0'} ${paddingObj.bottom || '0'} ${paddingObj.left || '0'}`;
  };

  const baseClasses = [
    getFontSizeClass(text_font_size),
    getFontWeightClass(text_font_weight),
    getTextColorClass(text_color),
    getBorderRadiusClass(border_border_radius),
    getBackgroundColorClass(fill_background_color),
    `font-[${text_font_family}]`,
    'outline-none',
    'cursor-pointer',
    'appearance-none',
    'bg-no-repeat',
    'bg-right',
    layout_width ? `w-[${layout_width}]` : 'w-full'
  ]?.filter(Boolean)?.join(' ');

  return (
    <select
      className={twMerge(baseClasses, className)}
      style={{
        border: border_border,
        padding: parsePadding(padding),
        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%235266FC' d='M6 9L1 4h10z'/%3E%3C/svg%3E")`,
        backgroundPosition: 'right 10px center',
        backgroundSize: '12px',
        color: text_color,
        minHeight: '36px',
        height: '36px',
        boxSizing: 'border-box'
      }}
      {...props}
    >
      {placeholder && <option value="" style={{ color: '#5266FC' }}>{placeholder}</option>}
      {options?.map((option) => (
        <option key={option?.value} value={option?.value} style={{ color: '#000000' }}>
          {option?.label}
        </option>
      ))}
    </select>
  );
};

export default Dropdown;

