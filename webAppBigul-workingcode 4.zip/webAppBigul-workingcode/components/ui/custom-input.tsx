'use client'

import React from 'react'
import { cn } from '@/lib/utils'

interface CustomInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  text_font_size?: string
  text_color?: string
  fill_background_color?: string
  border_border?: string
  border_border_radius?: string
  padding?: string
  layout_width?: string
}

export default function CustomInput({
  text_font_size = "11",
  text_color = "#5367fc",
  fill_background_color = "#ffffff",
  border_border = "0 solid #bec5ff",
  border_border_radius = "3px",
  padding,
  layout_width,
  className,
  ...props
}: CustomInputProps) {
  const style: React.CSSProperties = {
    fontSize: text_font_size ? `${parseInt(text_font_size) * 2}px` : undefined,
    color: text_color,
    backgroundColor: fill_background_color,
    border: border_border,
    borderRadius: border_border_radius,
    padding: padding ? padding.split(',').map(p => {
      const [_key, val] = p.split('=')
      return val
    }).join(' ') : undefined,
    width: layout_width,
  }

  return (
    <input
      className={cn("font-[Poppins] focus:outline-none focus:ring-2 focus:ring-blue-500", className)}
      style={style}
      {...props}
    />
  )
}

