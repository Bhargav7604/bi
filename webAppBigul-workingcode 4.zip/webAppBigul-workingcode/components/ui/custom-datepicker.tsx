'use client'

import React, { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'

interface CustomDatePickerProps extends React.InputHTMLAttributes<HTMLInputElement> {
  text_font_size?: string
  text_color?: string
  fill_background_color?: string
  border_border?: string
  border_border_radius?: string
  padding?: string
  layout_width?: string
}

export default function CustomDatePicker({
  text_font_size = "11",
  text_color = "#5367fc",
  fill_background_color = "#ffffff",
  border_border = "0 solid #bec5ff",
  border_border_radius = "3px",
  padding,
  layout_width,
  className,
  type = "time",
  ...props
}: CustomDatePickerProps) {
  const [isDark, setIsDark] = useState(false)

  useEffect(() => {
    const checkDarkMode = () => {
      setIsDark(document.documentElement.classList.contains('dark'))
    }
    checkDarkMode()
    const observer = new MutationObserver(checkDarkMode)
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class']
    })
    return () => observer.disconnect()
  }, [])

  const style: React.CSSProperties = {
    fontSize: text_font_size ? `${parseInt(text_font_size) * 2}px` : undefined,
    color: isDark ? (text_color === "#5266FC" ? "#60A5FA" : text_color) : text_color,
    backgroundColor: isDark ? "#1F2937" : fill_background_color,
    border: border_border,
    borderRadius: border_border_radius,
    padding: padding ? padding.split(',').map(p => {
      const [_key, val] = p.split('=')
      return val
    }).join(' ') : undefined,
    width: layout_width,
  }

  return (
    <input
      type={type}
      className={cn("font-[Poppins] focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer", className)}
      style={style}
      {...props}
    />
  )
}

