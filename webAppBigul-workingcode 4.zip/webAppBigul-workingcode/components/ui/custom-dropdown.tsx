'use client'

import React, { useState, useRef, useEffect } from 'react'
import { ChevronDown } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Option {
  value: string
  label: string
}

interface CustomDropdownProps {
  placeholder?: string
  text_font_size?: string
  text_color?: string
  border_border?: string
  border_border_radius?: string
  padding?: string
  layout_width?: string
  options?: Option[]
  value?: string
  onChange?: (value: string) => void
  className?: string
}

export default function CustomDropdown({
  placeholder = "Select here",
  text_font_size = "9",
  text_color = "#5367fc",
  border_border = "0 solid #bec5ff",
  border_border_radius = "3px",
  padding,
  layout_width,
  options = [],
  value,
  onChange,
  className,
}: CustomDropdownProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [selectedValue, setSelectedValue] = useState(value || '')
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleOptionSelect = (option: Option) => {
    setSelectedValue(option.value)
    setIsOpen(false)
    onChange?.(option.value)
  }

  const displayValue = selectedValue 
    ? options.find(opt => opt.value === selectedValue)?.label || selectedValue
    : placeholder

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _borderParts = border_border.split(' ')
  const borderStyle: React.CSSProperties = {
    fontSize: text_font_size ? `${parseInt(text_font_size) * 2}px` : undefined,
    color: text_color,
    border: border_border,
    borderRadius: border_border_radius,
    padding: padding ? padding.split(',').map(p => {
      const [_key, val] = p.split('=')
      return val
    }).join(' ') : undefined,
    width: layout_width,
  }

  return (
    <div ref={dropdownRef} className={cn("relative inline-block w-full", className)}>
      <div
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between cursor-pointer font-[Poppins]"
        style={borderStyle}
      >
        <span className={selectedValue ? '' : 'opacity-60'}>
          {displayValue}
        </span>
        <ChevronDown className={cn("w-4 h-4 transition-transform", isOpen && "rotate-180")} />
      </div>
      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-sm shadow-lg max-h-60 overflow-auto">
          <ul className="py-1">
            {options.length === 0 ? (
              <li className="px-3 py-2 text-gray-500 text-sm">No options available</li>
            ) : (
              options.map((option, index) => (
                <li
                  key={index}
                  onClick={() => handleOptionSelect(option)}
                  className="px-3 py-2 cursor-pointer hover:bg-gray-100 text-sm transition-colors"
                >
                  {option.label}
                </li>
              ))
            )}
          </ul>
        </div>
      )}
    </div>
  )
}

