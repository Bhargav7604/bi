import { cn } from "@/lib/utils"

interface LoadingSpinnerProps {
  size?: "sm" | "md" | "lg"
  className?: string
  text?: string
}

export function LoadingSpinner({ size = "md", className, text }: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: "w-4 h-4",
    md: "w-8 h-8",
    lg: "w-12 h-12",
  }

  return (
    <div className={cn("flex flex-col items-center justify-center gap-3", className)}>
      <div className="relative">
        {/* Outer rotating ring with gradient */}
        <div
          className={cn(
            "rounded-full border-4 border-gray-100 animate-spin",
            sizeClasses[size]
          )}
          style={{
            borderTopColor: "#5266FC",
            borderRightColor: "#4d6ff7",
            borderBottomColor: "#3b9fd8",
            borderLeftColor: "#00e8b0",
          }}
        />
        {/* Inner pulsing dot */}
        <div
          className={cn(
            "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-r from-[#5266FC] to-[#00e8b0] animate-pulse",
            size === "sm" ? "w-1.5 h-1.5" : size === "md" ? "w-2 h-2" : "w-3 h-3"
          )}
        />
      </div>
      {text && (
        <p className="text-sm font-medium text-gray-600 animate-pulse">{text}</p>
      )}
    </div>
  )
}

// Skeleton loader for cards
export function StrategyCardSkeleton() {
  return (
    <div className="flex flex-col gap-2.5 border border-gray-200 rounded-sm p-4 sm:p-5 bg-white shadow-sm animate-pulse">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div className="flex-1 space-y-2">
          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
        </div>
        <div className="flex gap-2">
          <div className="w-4 h-4 bg-gray-200 rounded"></div>
          <div className="w-4 h-4 bg-gray-200 rounded"></div>
          <div className="w-4 h-4 bg-gray-200 rounded"></div>
        </div>
      </div>
      
      {/* Tags */}
      <div className="flex gap-1.5">
        <div className="h-5 bg-gray-200 rounded-full w-16"></div>
        <div className="h-5 bg-gray-200 rounded-full w-20"></div>
        <div className="h-5 bg-gray-200 rounded-full w-14"></div>
      </div>
      
      {/* Description */}
      <div className="space-y-2">
        <div className="h-3 bg-gray-200 rounded w-full"></div>
        <div className="h-3 bg-gray-200 rounded w-5/6"></div>
        <div className="h-3 bg-gray-200 rounded w-4/6"></div>
      </div>
      
      {/* Bottom metrics */}
      <div className="flex justify-between items-end mt-auto">
        <div className="space-y-1">
          <div className="h-2.5 bg-gray-200 rounded w-16"></div>
          <div className="h-3 bg-gray-200 rounded w-12"></div>
        </div>
        <div className="space-y-1">
          <div className="h-2.5 bg-gray-200 rounded w-16"></div>
          <div className="h-3 bg-gray-200 rounded w-14"></div>
        </div>
        <div className="space-y-1">
          <div className="h-2.5 bg-gray-200 rounded w-16"></div>
          <div className="h-3 bg-gray-200 rounded w-12"></div>
        </div>
        <div className="w-8 h-8 bg-gray-200 rounded-sm"></div>
      </div>
    </div>
  )
}

