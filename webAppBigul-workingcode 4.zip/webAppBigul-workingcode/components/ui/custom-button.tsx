'use client'

import React from 'react'
import { cn } from '@/lib/utils'

interface CustomButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  text?: string
  text_font_size?: string
  text_color?: string
  fill_background_color?: string
  fill_background?: string
  border_border?: string
  border_border_radius?: string
  padding?: string
  layout_width?: string
  margin?: string
}

export default function CustomButton({
  text,
  text_font_size = "12",
  text_color = "#ffffff",
  fill_background_color = "#5367fc",
  fill_background,
  border_border,
  border_border_radius = "4px",
  padding,
  layout_width,
  margin,
  className,
  children,
  ...props
}: CustomButtonProps) {
  const style: React.CSSProperties = {
    fontSize: text_font_size ? `${parseInt(text_font_size) * 2}px` : undefined,
    color: text_color,
    backgroundColor: fill_background || fill_background_color,
    border: border_border,
    borderRadius: border_border_radius,
    padding: padding ? padding.split(',').map(p => {
      const [_key, val] = p.split('=')
      return val
    }).join(' ') : undefined,
    width: layout_width,
    margin: margin ? margin.split(',').map(m => {
      const [_key, val] = m.split('=')
      return val
    }).join(' ') : undefined,
  }

  return (
    <button
      className={cn("font-[Poppins] transition-all duration-200 hover:opacity-90", className)}
      style={style}
      {...props}
    >
      {children || text}
    </button>
  )
}

