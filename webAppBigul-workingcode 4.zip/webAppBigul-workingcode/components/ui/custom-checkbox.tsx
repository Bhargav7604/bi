'use client'

import React from 'react'
import { cn } from '@/lib/utils'

interface CustomCheckboxProps {
  text?: string
  text_font_size?: string
  text_color?: string
  text_font_weight?: string
  checked?: boolean
  onChange?: () => void
  className?: string
}

export default function CustomCheckbox({
  text,
  text_font_size = "9",
  text_color = "#000000",
  text_font_weight = "500",
  checked = false,
  onChange,
  className,
}: CustomCheckboxProps) {
  const style: React.CSSProperties = {
    fontSize: text_font_size ? `${parseInt(text_font_size) * 2}px` : undefined,
    color: text_color,
    fontWeight: text_font_weight,
  }

  return (
    <label className={cn("flex items-center gap-2 cursor-pointer font-[Poppins]", className)}>
      <input
        type="checkbox"
        checked={checked}
        onChange={onChange}
        className="w-4 h-4 rounded-sm border-2 border-gray-300 checked:bg-blue-600 checked:border-blue-600 focus:ring-2 focus:ring-blue-500"
      />
      {text && <span style={style}>{text}</span>}
    </label>
  )
}

