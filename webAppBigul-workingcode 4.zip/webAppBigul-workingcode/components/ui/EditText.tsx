import React from 'react';
import { twMerge } from 'tailwind-merge';

interface EditTextProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  // Design system parameters
  text_font_size?: string;
  text_font_family?: string;
  text_font_weight?: string;
  text_color?: string;
  border_border?: string;
  border_border_radius?: string;
  padding?: string;
  layout_width?: string;
  fill_background_color?: string;
}

const EditText: React.FC<EditTextProps> = ({
  placeholder = "",
  text_font_size = "9",
  text_font_family = "Poppins",
  text_font_weight = "400",
  text_color = "#5266FC",
  border_border = "1px solid #BFC5FF",
  border_border_radius = "3px",
  padding = "t=4px,r=20px,b=4px,l=20px",
  layout_width,
  fill_background_color = "#ffffff",
  className,
  ...props
}) => {
  // Map font size to Tailwind classes
  const getFontSizeClass = (size: string): string => {
    const sizeMap: Record<string, string> = {
      '7': 'text-sm',
      '8': 'text-base',
      '9': 'text-md',
      '10': 'text-lg',
      '11': 'text-xl'
    };
    return sizeMap?.[size] || `text-[${size}px]`;
  };

  const getFontWeightClass = (weight: string): string => {
    const weightMap: Record<string, string> = {
      '400': 'font-normal',
      '500': 'font-medium',
      '600': 'font-semibold'
    };
    return weightMap?.[weight] || `font-[${weight}]`;
  };

  const getTextColorClass = (color: string): string => {
    const colorMap: Record<string, string> = {
      '#5367fc': 'text-[#5367fc]',
      '#5266FC': 'text-[#5266FC]',
      '#BFC5FF': 'text-[#BFC5FF]',
      '#000000': 'text-black'
    };
    return colorMap?.[color] || `text-[${color}]`;
  };

  const getBorderRadiusClass = (radius: string): string => {
    const radiusMap: Record<string, string> = {
      '2px': 'rounded-sm',
      '3px': 'rounded-sm',
      '4px': 'rounded'
    };
    return radiusMap?.[radius] || `rounded-[${radius}]`;
  };

  const getBackgroundColorClass = (color: string): string => {
    const colorMap: Record<string, string> = {
      '#ffffff': 'bg-white',
      '#e7eaff': 'bg-[#e7eaff]'
    };
    return colorMap?.[color] || `bg-[${color}]`;
  };

  const parsePadding = (pad: string): string => {
    if (!pad) return '';
    const parts = pad.split(',');
    const paddingObj: { top?: string; right?: string; bottom?: string; left?: string } = {};
    parts.forEach(part => {
      const [key, value] = part.split('=');
      if (key === 't') paddingObj.top = value;
      if (key === 'r') paddingObj.right = value;
      if (key === 'b') paddingObj.bottom = value;
      if (key === 'l') paddingObj.left = value;
    });
    return `${paddingObj.top || '0'} ${paddingObj.right || '0'} ${paddingObj.bottom || '0'} ${paddingObj.left || '0'}`;
  };

  const baseClasses = [
    getFontSizeClass(text_font_size),
    getFontWeightClass(text_font_weight),
    getTextColorClass(text_color),
    getBorderRadiusClass(border_border_radius),
    getBackgroundColorClass(fill_background_color),
    `font-[${text_font_family}]`,
    'outline-none',
    'focus:ring-2',
    'focus:ring-[#5367fc]',
    'focus:ring-opacity-50',
    'transition-all',
    'duration-200',
    layout_width ? `w-[${layout_width}]` : 'w-full'
  ]?.filter(Boolean)?.join(' ');

  return (
    <input
      type="text"
      placeholder={placeholder}
      className={twMerge(baseClasses, className)}
      style={{
        border: border_border,
        padding: parsePadding(padding),
        color: text_color,
        minHeight: '36px',
        height: '36px',
        boxSizing: 'border-box'
      }}
      {...props}
    />
  );
};

export default EditText;

