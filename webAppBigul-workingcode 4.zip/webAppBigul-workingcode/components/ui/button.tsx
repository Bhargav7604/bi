import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { twMerge } from 'tailwind-merge';

const buttonClasses = cva(
  'inline-flex items-center justify-center font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-90 active:scale-95',
  {
    variants: {
      variant: {
        primary: 'text-white bg-blue-600 hover:bg-blue-700 focus:ring-blue-500',
        secondary: 'bg-gray-200 text-gray-800 hover:bg-gray-300 focus:ring-gray-500',
        outline: 'border-2 bg-transparent hover:bg-opacity-10 focus:ring-blue-500',
        ghost: 'bg-transparent hover:bg-opacity-10',
      },
      size: {
        small: 'text-xs px-2 py-1',
        medium: 'text-sm px-3 py-2',
        large: 'text-base px-4 py-3',
        icon: 'h-10 w-10',
        default: 'text-sm px-3 py-2',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'medium',
    },
  }
);

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonClasses> {
  // Design system parameters
  text?: string;
  text_font_size?: string;
  text_font_family?: string;
  text_font_weight?: string;
  text_line_height?: string;
  text_text_align?: string;
  text_color?: string;
  text_text_transform?: string;
  fill_background_color?: string;
  fill_background?: string;
  border_border_radius?: string;
  border_border?: string;
  layout_width?: string;
  padding?: string;
  position?: string;
  layout_gap?: string;
  margin?: string;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(({
  // Required parameters with defaults
  text = "Easy Strategy Templates",
  text_font_size = "12",
  text_font_family = "Poppins",
  text_font_weight = "400",
  text_line_height = "18px",
  text_text_align = "left",
  text_color = "#ffffff",
  fill_background_color = "#5367fc",
  border_border_radius = "4px",
  
  // Optional parameters (no defaults)
  border_border,
  text_text_transform,
  fill_background,
  layout_width,
  padding,
  position,
  layout_gap,
  margin,
  
  // Standard React props
  variant,
  size,
  disabled = false,
  className,
  children,
  onClick,
  type = "button",
  ...props
}, ref) => {
  // Safe validation for optional parameters
  const hasValidWidth = layout_width && typeof layout_width === 'string' && layout_width?.trim() !== '';
  const hasValidPadding = padding && typeof padding === 'string' && padding?.trim() !== '';
  const hasValidMargin = margin && typeof margin === 'string' && margin?.trim() !== '';
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _hasValidPosition = position && typeof position === 'string' && position?.trim() !== '';
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _hasValidGap = layout_gap && typeof layout_gap === 'string' && layout_gap?.trim() !== '';
  const hasValidBorder = border_border && typeof border_border === 'string' && border_border?.trim() !== '';
  const hasValidTransform = text_text_transform && typeof text_text_transform === 'string' && text_text_transform?.trim() !== '';
  const hasValidBackground = fill_background && typeof fill_background === 'string' && fill_background?.trim() !== '';

  // Parse padding
  const parsePadding = (pad: string): string => {
    if (!pad) return '';
    const parts = pad.split(',');
    const paddingObj: { top?: string; right?: string; bottom?: string; left?: string } = {};
    parts.forEach(part => {
      const [key, value] = part.split('=');
      if (key === 't') paddingObj.top = value;
      if (key === 'r') paddingObj.right = value;
      if (key === 'b') paddingObj.bottom = value;
      if (key === 'l') paddingObj.left = value;
    });
    return `${paddingObj.top || '0'} ${paddingObj.right || '0'} ${paddingObj.bottom || '0'} ${paddingObj.left || '0'}`;
  };

  // Parse margin
  const parseMargin = (marg: string): string => {
    if (!marg) return '';
    const parts = marg.split(',');
    const marginObj: { top?: string; right?: string; bottom?: string; left?: string } = {};
    parts.forEach(part => {
      const [key, value] = part.split('=');
      if (key === 't') marginObj.top = value;
      if (key === 'r') marginObj.right = value;
      if (key === 'b') marginObj.bottom = value;
      if (key === 'l') marginObj.left = value;
    });
    return `${marginObj.top || '0'} ${marginObj.right || '0'} ${marginObj.bottom || '0'} ${marginObj.left || '0'}`;
  };

  // Map font size to Tailwind classes with fallback
  const getFontSizeClass = (size: string): string => {
    const sizeMap: Record<string, string> = {
      '6': 'text-xs',
      '7': 'text-sm', 
      '8': 'text-base',
      '9': 'text-md',
      '10': 'text-lg',
      '11': 'text-xl',
      '12': 'text-2xl',
      '14': 'text-3xl',
      '16': 'text-4xl',
      '22': 'text-5xl'
    };
    return sizeMap?.[size] || `text-[${size}px]`;
  };

  // Map font weight to Tailwind classes
  const getFontWeightClass = (weight: string): string => {
    const weightMap: Record<string, string> = {
      '400': 'font-normal',
      '500': 'font-medium',
      '600': 'font-semibold'
    };
    return weightMap?.[weight] || `font-[${weight}]`;
  };

  // Map line height to Tailwind classes
  const getLineHeightClass = (height: string): string => {
    const heightMap: Record<string, string> = {
      '10px': 'leading-xs',
      '12px': 'leading-sm',
      '13px': 'leading-base',
      '14px': 'leading-md',
      '15px': 'leading-lg',
      '16px': 'leading-xl',
      '17px': 'leading-2xl',
      '18px': 'leading-3xl',
      '19px': 'leading-4xl',
      '20px': 'leading-5xl',
      '21px': 'leading-6xl',
      '24px': 'leading-7xl',
      '33px': 'leading-8xl'
    };
    return heightMap?.[height] || `leading-[${height}]`;
  };

  // Map colors to Tailwind classes
  const getTextColorClass = (color: string): string => {
    const colorMap: Record<string, string> = {
      '#5367fc': 'text-[#5367fc]',
      '#ffffff': 'text-white',
      '#000000': 'text-black',
      '#5f5b5b': 'text-gray-600'
    };
    return colorMap?.[color] || `text-[${color}]`;
  };

  const getBackgroundColorClass = (color: string): string => {
    const colorMap: Record<string, string> = {
      '#5367fc': 'bg-[#5367fc]',
      '#ffffff': 'bg-white',
      '#e7eaff': 'bg-[#e7eaff]',
      '#009900': 'bg-green-600',
      'transparent': 'bg-transparent'
    };
    return colorMap?.[color] || `bg-[${color}]`;
  };

  const getBorderRadiusClass = (radius: string): string => {
    const radiusMap: Record<string, string> = {
      '2px': 'rounded-sm',
      '3px': 'rounded-sm',
      '4px': 'rounded',
      '6px': 'rounded-md',
      '8px': 'rounded-lg',
      '12px': 'rounded-xl'
    };
    return radiusMap?.[radius] || `rounded-[${radius}]`;
  };

  // Build Tailwind classes from parameters
  const parameterClasses = [
    getFontSizeClass(text_font_size),
    getFontWeightClass(text_font_weight),
    getLineHeightClass(text_line_height),
    `text-${text_text_align}`,
    getTextColorClass(text_color),
    hasValidBackground ? '' : getBackgroundColorClass(fill_background_color),
    getBorderRadiusClass(border_border_radius),
    `font-[${text_font_family}]`,
    hasValidWidth ? `w-[${layout_width}]` : '',
    hasValidTransform ? text_text_transform : '',
    hasValidBorder ? '' : ''
  ]?.filter(Boolean)?.join(' ');

  // Safe click handler
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>): void => {
    if (disabled) return;
    if (typeof onClick === 'function') {
      onClick(event);
    }
  };

  const style: React.CSSProperties = {
    ...(hasValidBackground && fill_background ? { background: fill_background } : {}),
    ...(hasValidBorder && border_border ? { border: border_border } : {}),
    ...(hasValidPadding && padding ? { padding: parsePadding(padding) } : {}),
    ...(hasValidMargin && margin ? { margin: parseMargin(margin) } : {}),
  };

  return (
    <button
      ref={ref}
      type={type}
      disabled={disabled}
      onClick={handleClick}
      className={twMerge(
        buttonClasses({ variant, size }),
        parameterClasses,
        className
      )}
      style={style}
      aria-disabled={disabled}
      {...props}
    >
      {children || text}
    </button>
  );
});

Button.displayName = 'Button';

export default Button;
export { Button };
export const buttonVariants = buttonClasses;
