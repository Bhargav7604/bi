import { useState, useEffect, useCallback, useRef } from "react"
import { useSearchParams, useNavigate } from "react-router-dom"
import { Search, Bookmark, Share2, ArrowUpRight, Minus, Plus, ChevronDown, ChevronUp, Loader2, AlertTriangle, Info } from "lucide-react"
import { LoadingSpinner, StrategyCardSkeleton } from "@components/ui/LoadingSpinner"
import { strategyService } from "@/lib/api/strategy.service"
import type { ReadyToDeployStrategy, ActiveStrategy } from "@/lib/api/types"
import { toastr } from "@/lib/utils/toastr"
import { useAuthStore } from "@/store/auth.store"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@components/ui/dialog"
import { Button } from "@components/ui/button"
import { ToggleGroup, ToggleGroupItem } from "@components/ui/toggle-group"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@components/ui/collapsible"

export default function DiscoverStrategy() {
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  
  // Set initial tab from URL parameter, default to "in-house"
  const getInitialTab = () => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search)
      const tab = params.get("tab")
      if (tab === "popular") return "popular"
      if (tab === "in-house" || tab === "inhouse") return "in-house"
    }
    return "in-house"
  }
  
  const [activeTab, setActiveTab] = useState(getInitialTab)
  const [bookmarkedStrategies, setBookmarkedStrategies] = useState<number[]>([])
  const [underlyingSearch, setUnderlyingSearch] = useState("")
  const [strategies, setStrategies] = useState<ReadyToDeployStrategy[]>([])
  const [allStrategies, setAllStrategies] = useState<ReadyToDeployStrategy[]>([]) // Store unfiltered strategies
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState<string>("")
  const [activeStrategies, setActiveStrategies] = useState<ActiveStrategy[]>([])
  const [openFilters, setOpenFilters] = useState<Set<string>>(new Set(["type"])) // First filter (Type) open by default
  const fetchingRef = useRef(false)
  
  // Cache strategies per tab to avoid refetching
  const strategiesCache = useRef<Record<string, ReadyToDeployStrategy[]>>({})
  const allStrategiesCache = useRef<ReadyToDeployStrategy[] | null>(null)
  
  // Deploy dialog state
  const [deployDialogOpen, setDeployDialogOpen] = useState(false)
  const [selectedStrategy, setSelectedStrategy] = useState<ReadyToDeployStrategy | null>(null)
  
  // Share modal state
  const [shareModalOpen, setShareModalOpen] = useState(false)
  const [multiplier, setMultiplier] = useState<number>(1)
  const [executionTypeId, setExecutionTypeId] = useState<string>("LiveTrading")
  const [deployLoading, setDeployLoading] = useState(false)
  const [deployError, setDeployError] = useState<string | null>(null)
  const [marginNeeded, setMarginNeeded] = useState<number>(0)
  const [marginAvailable] = useState<number>(15425.10)
  const [backtestConsentOpen, setBacktestConsentOpen] = useState(false)
  const [pendingBacktestStrategy, setPendingBacktestStrategy] = useState<string | null>(null)
  const [backtestLoading, setBacktestLoading] = useState(false)
  
  // Description modal state
  const [descriptionModalOpen, setDescriptionModalOpen] = useState(false)
  const [selectedDescription, setSelectedDescription] = useState<{ title: string; description: string } | null>(null)

  const [filters, setFilters] = useState({
    type: [] as string[],
    capitalRequired: [] as string[],
    duration: [] as string[],
    segment: [] as string[],
    underlying: [] as string[],
  })

  const tabs = [
    { id: "in-house", label: "In-House", apiCategory: "inhouse" },
    { id: "popular", label: "Popular", apiCategory: "popular" },
    { id: "bookmarked", label: "Bookmarked Strategies", apiCategory: null },
  ]

  const filterSections = [
    {
      title: "Type",
      key: "type",
      options: ["All", "Most Deployed", "Newly Added"],
    },
    {
      title: "Minimum Capital",
      key: "capitalRequired",
      options: ["All", "₹50,000 – ₹1,00,000", "₹1,00,000 – ₹5,00,000", "Above ₹5,00,000"],
    },
    {
      title: "Duration",
      key: "duration",
      options: ["All", "Intraday", "Positional", "BTST / STBT"],
    },
    {
      title: "Segment",
      key: "segment",
      options: ["All", "Equity (Cash)", "F&O (Futures & Options)", "Commodity"],
    },
  ]

  const underlyingOptions = ["All", "Nifty", "Bank Nifty", "Midcap Nifty", "FinNifty", "Sensex"]

  // Map underlying IDs to names
  // Get underlying name for tags (full names)
  const getUnderlyingNameForTags = (underlying: string | number | undefined): string => {
    const underlyingMap: Record<string | number, string> = {
      1: "Nifty",
      2: "Bank Nifty",
      3: "FinNifty",
      4: "Sensex",
      5: "Bankex",
    }
    // Handle both string and number keys
    const key = typeof underlying === "string" ? parseInt(underlying) : underlying
    return underlyingMap[key as number] || "Nifty"
  }

  // Generate tags from strategy data
  const generateTags = (strategy: ReadyToDeployStrategy): string[] => {
    const tags: string[] = []
    
    // Add underlying (full names in tags)
    if (strategy.underlying) {
      tags.push(getUnderlyingNameForTags(strategy.underlying))
    }
    
    // Add position type
    if (strategy.positionType) {
      tags.push(strategy.positionType)
    }
    
    // Add risk level as a tag (always show, default to "Medium" if not provided)
    const riskLevel = strategy.riskLevel || "Medium"
    tags.push(String(riskLevel))
    
    return tags
  }

  // Map tab ID to API category key
  const getCategoryKey = (tabId: string): string | null => {
    const tab = tabs.find(t => t.id === tabId)
    return tab?.apiCategory || null
  }

  // Fetch active strategies to check deployment status
  const fetchActiveStrategies = useCallback(async () => {
    const userId = useAuthStore.getState().userId
    if (!userId) {
      console.warn("⚠️ DiscoverStrategy: No userId available, skipping active strategies fetch")
      return
    }

    try {
      const response = await strategyService.getActiveStrategies(userId)
      if (response.success && response.data) {
        const responseData = response.data as any
        // Extract active strategies from response
        let activeStrategiesData: ActiveStrategy[] = []
        if (responseData?.data?.activeStrategiesResponse) {
          activeStrategiesData = responseData.data.activeStrategiesResponse
        } else if (responseData?.activeStrategiesResponse) {
          activeStrategiesData = responseData.activeStrategiesResponse
        }
        setActiveStrategies(activeStrategiesData)
        console.log("✅ DiscoverStrategy: Active strategies loaded:", activeStrategiesData.length)
      }
    } catch (err) {
      console.error("❌ DiscoverStrategy: Failed to fetch active strategies:", err)
    }
  }, [])

  // Check if a strategy is deployed
  const isStrategyDeployed = useCallback((strategyId: number): boolean => {
    return activeStrategies.some((active) => active.sid === strategyId)
  }, [activeStrategies])

  // Filter strategies based on active filters and search query
  const applyFilters = useCallback((strategiesToFilter: ReadyToDeployStrategy[]): ReadyToDeployStrategy[] => {
    // Check if "All" is selected in any filter category - if so, skip filtering for that category
    // Check if any non-"All" filters are active
    const hasActiveFilters = 
      (filters.type.length > 0 && !filters.type.includes("All")) ||
      (filters.capitalRequired.length > 0 && !filters.capitalRequired.includes("All")) ||
      (filters.duration.length > 0 && !filters.duration.includes("All")) ||
      (filters.segment.length > 0 && !filters.segment.includes("All")) ||
      (filters.underlying.length > 0 && !filters.underlying.includes("All"))

    // If no filters are selected and no search query, return all strategies from the current tab
    if (!hasActiveFilters && !searchQuery.trim()) {
      return [...strategiesToFilter]
    }

    let filtered = [...strategiesToFilter]

    // Apply search query filter (search in title and description)
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter((strategy) => {
        const title = String(strategy.title || strategy.name || "").toLowerCase()
        const description = String(strategy.description || "").toLowerCase()
        return title.includes(query) || description.includes(query)
      })
    }

    // Filter by Type
    if (filters.type.length > 0 && !filters.type.includes("All")) {
      filtered = filtered.filter((strategy) => {
        // If multiple types are selected, strategy should match ANY of them (OR logic)
        return filters.type.some((type) => {
          if (type === "Most Deployed") {
            // Check if strategy is deployed (in activeStrategies)
            return activeStrategies.some((active) => active.sid === strategy.id)
          }
          if (type === "Newly Added") {
            // Check if strategy was created recently (within last 30 days)
            if (strategy.createdAt) {
              const createdDate = new Date(strategy.createdAt)
              const thirtyDaysAgo = new Date()
              thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
              return createdDate >= thirtyDaysAgo
            }
            return false
          }
          return false
        })
      })
    }

    // Filter by Capital Required
    if (filters.capitalRequired.length > 0 && !filters.capitalRequired.includes("All")) {
      filtered = filtered.filter((strategy) => {
        const capital = strategy.minCapital || 0
        return filters.capitalRequired.some((range) => {
          if (range === "₹50,000 – ₹1,00,000") {
            return capital >= 50000 && capital <= 100000
          }
          if (range === "₹1,00,000 – ₹5,00,000") {
            return capital >= 100000 && capital <= 500000
          }
          if (range === "Above ₹5,00,000") {
            return capital > 500000
          }
          return false
        })
      })
    }


    // Filter by Duration (Intraday, Positional, BTST / STBT)
    if (filters.duration.length > 0 && !filters.duration.includes("All")) {
      filtered = filtered.filter((strategy) => {
        const positionType = strategy.positionType || ""
        const positionLower = positionType.toLowerCase()
        return filters.duration.some((duration) => {
          if (duration === "Intraday") {
            return positionLower.includes("intraday") || positionLower === "intraday"
          }
          if (duration === "Positional") {
            return positionLower.includes("positional") || positionLower === "positional"
          }
          if (duration === "BTST / STBT") {
            return positionLower.includes("btst") || positionLower.includes("stbt")
          }
          return false
        })
      })
    }

    // Filter by Segment (Equity (Cash), F&O (Futures & Options), Commodity)
    // Note: This might need to be inferred from underlying or other fields
    if (filters.segment.length > 0 && !filters.segment.includes("All")) {
      filtered = filtered.filter((strategy) => {
        // For now, we'll check if it's F&O based on underlying (Nifty, Bank Nifty are typically F&O)
        // This is a simplified logic - you may need to adjust based on actual API data
        const underlying = strategy.underlying
        return filters.segment.some((segment) => {
          if (segment === "F&O (Futures & Options)") {
            // Nifty, Bank Nifty, FinNifty are typically F&O
            return underlying === 1 || underlying === 2 || underlying === 3 || underlying === "1" || underlying === "2" || underlying === "3"
          }
          if (segment === "Equity (Cash)") {
            // Sensex, Bankex might be equity
            return underlying === 4 || underlying === 5 || underlying === "4" || underlying === "5"
          }
          if (segment === "Commodity") {
            // Commodity strategies might have different underlying values
            // This is a placeholder - adjust based on actual data
            return false
          }
          return false
        })
      })
    }

    // Filter by Underlying
    if (filters.underlying.length > 0 && !filters.underlying.includes("All")) {
      filtered = filtered.filter((strategy) => {
        const underlyingName = getUnderlyingNameForTags(strategy.underlying)
        return filters.underlying.some((filterUnderlying) => {
          if (filterUnderlying === "All") return true
          return underlyingName === filterUnderlying
        })
      })
    }

    return filtered
  }, [filters, activeStrategies, searchQuery])

  // Fetch all strategies from all categories
  const fetchAllStrategies = useCallback(async (forceRefresh = false) => {
    if (fetchingRef.current) return
    fetchingRef.current = true
    
    // Check cache first if not forcing refresh
    if (!forceRefresh && allStrategiesCache.current) {
      console.log(`📦 DiscoverStrategy: Using cached all strategies`)
      const cachedAllStrategies = allStrategiesCache.current
      setAllStrategies(cachedAllStrategies)
      // Don't set strategies here - let the useEffect handle filtering
      fetchingRef.current = false
      return
    }
    
    // Clear strategies immediately when fetching all
    setAllStrategies([])
    setStrategies([])
    
    setLoading(true)
    setError(null)

    try {
      // Fetch from any category - the response contains all categories
      const response = await strategyService.getReadyToDeployStrategies("inhouse")
      
      if (response.success && response.data) {
        const responseData = response.data as any
        let allStrategiesData: ReadyToDeployStrategy[] = []
        
        // Extract strategies from all categories
        const categoryMap: Record<string, string> = {
          "inHouse": "inHouse",
          "popular": "popular",
          "diy": "diy",
          "preBuilt": "preBuilt",
        }
        
        // Get strategies from all categories
        const strategiesObj = responseData.strategies || responseData.data?.strategies || {}
        
        Object.keys(categoryMap).forEach((key) => {
          if (strategiesObj[key] && Array.isArray(strategiesObj[key])) {
            allStrategiesData = [...allStrategiesData, ...strategiesObj[key]]
          }
        })
        
        console.log(`📊 DiscoverStrategy: Extracted all categories strategies count:`, allStrategiesData.length)

        // Transform API data to match component structure
        const transformedStrategies = allStrategiesData.map((strategy) => ({
          ...strategy,
          id: strategy.id,
          title: strategy.name || "Untitled Strategy",
          tags: generateTags(strategy),
          description: strategy.description || "",
          minCapital: strategy.minCapital || 0,
          avgReturn: "Backtest",
          riskLevel: "Medium",
          lastDeployed: "",
        }))

        // Store all strategies (unfiltered) - filters will be applied by useEffect
        setAllStrategies(transformedStrategies)
        // Cache all strategies
        allStrategiesCache.current = transformedStrategies
        console.log(`💾 DiscoverStrategy: Cached ${transformedStrategies.length} all strategies`)
      } else {
        setError(response.error?.message || "Failed to fetch strategies")
        setStrategies([])
      }
    } catch (err) {
      console.error("Error fetching all strategies:", err)
      setError(err instanceof Error ? err.message : "An error occurred")
      setStrategies([])
    } finally {
      setLoading(false)
      fetchingRef.current = false
    }
  }, [])

  // Fetch ready to deploy strategies from API
  const fetchReadyToDeployStrategies = useCallback(async (tabId: string, forceRefresh = false) => {
    if (fetchingRef.current) return
    fetchingRef.current = true
    
    const apiCategory = getCategoryKey(tabId)
    
    // Don't fetch for bookmarked tab (no API category)
    if (!apiCategory) {
      setAllStrategies([])
      setStrategies([])
      setLoading(false)
      fetchingRef.current = false
      return
    }

    // Check cache first if not forcing refresh
    if (!forceRefresh && strategiesCache.current[tabId]) {
      console.log(`📦 DiscoverStrategy: Using cached strategies for ${tabId}`)
      const cachedStrategies = strategiesCache.current[tabId]
      setAllStrategies(cachedStrategies)
      // Don't set strategies here - let the useEffect handle filtering
      fetchingRef.current = false
      return
    }
    
    // Clear strategies immediately when switching tabs to avoid showing stale data
    setAllStrategies([])
    setStrategies([])

    setLoading(true)
    setError(null)

    try {
      let strategiesData: ReadyToDeployStrategy[] = []
      
      // For popular tab, call both popular and prebuilt APIs separately
      if (apiCategory === "popular") {
        console.log(`📡 DiscoverStrategy: Popular tab - Calling both popular and prebuilt APIs`)
        
        // Call popular API
        const popularResponse = await strategyService.getReadyToDeployStrategies("popular")
        let popularStrategies: ReadyToDeployStrategy[] = []
        
        if (popularResponse.success && popularResponse.data) {
          const popularResponseData = popularResponse.data as any
          const strategiesObj = popularResponseData.strategies || popularResponseData.data?.strategies || {}
          
          if (strategiesObj["popular"] && Array.isArray(strategiesObj["popular"])) {
            popularStrategies = strategiesObj["popular"]
          }
          console.log(`📊 DiscoverStrategy: Popular API returned ${popularStrategies.length} strategies`)
        }
        
        // Call prebuilt API
        const prebuiltResponse = await strategyService.getReadyToDeployStrategies("prebuilt")
        let preBuiltStrategies: ReadyToDeployStrategy[] = []
        
        if (prebuiltResponse.success && prebuiltResponse.data) {
          const prebuiltResponseData = prebuiltResponse.data as any
          const strategiesObj = prebuiltResponseData.strategies || prebuiltResponseData.data?.strategies || {}
          
          if (strategiesObj["preBuilt"] && Array.isArray(strategiesObj["preBuilt"])) {
            preBuiltStrategies = strategiesObj["preBuilt"]
          }
          console.log(`📊 DiscoverStrategy: Prebuilt API returned ${preBuiltStrategies.length} strategies`)
        }
        
        // Combine both arrays - popular first, then preBuilt
        strategiesData = [...popularStrategies, ...preBuiltStrategies]
        console.log(`📊 DiscoverStrategy: Popular tab - Combined ${popularStrategies.length} popular + ${preBuiltStrategies.length} preBuilt = ${strategiesData.length} total strategies`)
      } else {
        // For other tabs, use the original logic with single API call
        const response = await strategyService.getReadyToDeployStrategies(apiCategory)
        
        if (response.success && response.data) {
          const responseData = response.data as any
          
          // Map API category parameter (lowercase) to response keys (camelCase)
          const categoryMap: Record<string, string> = {
            "inhouse": "inHouse",
            "popular": "popular",
            "diy": "diy",
            "prebuilt": "preBuilt",
          }
          
          const responseKey = categoryMap[apiCategory] || apiCategory
          
          console.log(`🔍 DiscoverStrategy: API category: ${apiCategory}, Response key: ${responseKey}`)
          
          // Try to extract strategies from the response
          const strategiesObj = responseData.strategies || responseData.data?.strategies || {}
          
          if (strategiesObj[responseKey] && Array.isArray(strategiesObj[responseKey])) {
            strategiesData = strategiesObj[responseKey]
          } else {
            strategiesData = []
            console.warn(`⚠️ DiscoverStrategy: Key "${responseKey}" not found in response. Available keys:`, Object.keys(strategiesObj))
          }
          
          console.log(`📊 DiscoverStrategy: Extracted ${apiCategory} (${responseKey}) strategies count:`, strategiesData.length)
        } else {
          setError(response.error?.message || "Failed to fetch strategies")
          setAllStrategies([])
          setStrategies([])
          fetchingRef.current = false
          setLoading(false)
          return
        }
      }

      // Transform API data to match component structure
      const transformedStrategies = strategiesData.map((strategy) => ({
        ...strategy, // Keep all other properties first
        id: strategy.id,
        title: strategy.name || "Untitled Strategy",
        tags: generateTags(strategy),
        description: strategy.description || "",
        minCapital: strategy.minCapital || 0,
        avgReturn: "Backtest", // Default value as API doesn't provide this
        riskLevel: "Medium", // Default value as API doesn't provide this
        lastDeployed: "", // Can be calculated from createdAt if needed
      }))

      // Store all strategies (unfiltered) - filters will be applied by useEffect
      setAllStrategies(transformedStrategies)
      // Cache the strategies for this tab (even if empty)
      strategiesCache.current[tabId] = transformedStrategies
      console.log(`💾 DiscoverStrategy: Cached ${transformedStrategies.length} strategies for ${tabId}`)
      
      // If no strategies found for this tab, ensure strategies state is empty
      if (transformedStrategies.length === 0) {
        setStrategies([])
      }
    } catch (err) {
      console.error("Error fetching ready to deploy strategies:", err)
      setError(err instanceof Error ? err.message : "An error occurred")
      setAllStrategies([])
      setStrategies([])
      // Clear cache for this tab on error
      delete strategiesCache.current[tabId]
    } finally {
      setLoading(false)
      fetchingRef.current = false
    }
  }, [])

  // Fetch strategies when tab changes
  // Ref to prevent duplicate active strategies fetch
  const activeStrategiesFetchedRef = useRef(false)

  // Fetch active strategies only once on mount
  useEffect(() => {
    if (!activeStrategiesFetchedRef.current) {
      activeStrategiesFetchedRef.current = true
      fetchActiveStrategies()
    }
  }, []) // Empty deps - only fetch once on mount

  // Update active tab when URL parameter changes
  useEffect(() => {
    const tabFromUrl = searchParams.get("tab")
    if (tabFromUrl === "popular") {
      setActiveTab("popular")
    } else if (tabFromUrl === "in-house" || tabFromUrl === "inhouse") {
      setActiveTab("in-house")
    }
  }, [searchParams])

  // Check if "All" is selected in any filter category

  // Track previous values to prevent unnecessary fetches
  const prevActiveTabRef = useRef<string | null>(null)
  const prevAllSelectedRef = useRef(false)
  const hasInitialFetchRef = useRef(false)

  // Initial fetch on mount
  useEffect(() => {
    if (!hasInitialFetchRef.current) {
      hasInitialFetchRef.current = true
      prevActiveTabRef.current = activeTab
      // Fetch strategies for the initial tab (default is "in-house")
      const initialTab = activeTab || "in-house"
      fetchReadyToDeployStrategies(initialTab)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []) // Only run once on mount

  // Fetch strategies when tab changes or when "All" filter is toggled
  useEffect(() => {
    // Check if "All" is selected in any filter category
    const allSelected = Object.values(filters).some((filterArray) => filterArray.includes("All"))
    
    // Only fetch if tab changed or "All" selection status changed
    const tabChanged = prevActiveTabRef.current !== activeTab
    const allSelectionChanged = prevAllSelectedRef.current !== allSelected
    
    if (tabChanged || allSelectionChanged) {
      // Clear strategies immediately when tab changes to avoid showing stale data
      if (tabChanged) {
        setAllStrategies([])
        setStrategies([])
      }
      
      prevActiveTabRef.current = activeTab
      prevAllSelectedRef.current = allSelected
      
      // If "All" is selected in any filter, fetch all strategies from all tabs
      if (allSelected) {
        fetchAllStrategies(false) // Use cache if available
      } else {
        // Otherwise, fetch strategies for the current tab (use cache if available)
        fetchReadyToDeployStrategies(activeTab, false)
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, filters.type, filters.capitalRequired, filters.duration, filters.segment, filters.underlying])

  // Listen for global search events
  useEffect(() => {
    const handleGlobalSearch = (event: CustomEvent) => {
      const { query, path } = event.detail
      // Only apply search if we're on the discover page
      if (path === "/discover") {
        setSearchQuery(query)
      }
    }

    // Check for search query from sessionStorage on mount
    const storedQuery = sessionStorage.getItem('globalSearchQuery')
    const storedPath = sessionStorage.getItem('globalSearchPath')
    if (storedQuery && storedPath === "/discover") {
      setSearchQuery(storedQuery)
      // Clear after using
      sessionStorage.removeItem('globalSearchQuery')
      sessionStorage.removeItem('globalSearchPath')
    }

    window.addEventListener('globalSearch', handleGlobalSearch as EventListener)
    return () => window.removeEventListener('globalSearch', handleGlobalSearch as EventListener)
  }, [])

  // Apply filters whenever filters, activeStrategies, or searchQuery change
  useEffect(() => {
    if (allStrategies.length > 0) {
      const filtered = applyFilters(allStrategies)
      setStrategies(filtered)
    } else {
      // If allStrategies is empty, ensure strategies is also empty
      setStrategies([])
    }
  }, [filters, allStrategies, activeStrategies, applyFilters])

  const formatCapital = (capital: number | string | undefined): string => {
    if (!capital) return "N/A"
    if (typeof capital === "string") {
      // If already formatted, return as is
      if (capital.includes("₹")) return capital
      // Try to parse and format
      const num = parseFloat(capital)
      if (isNaN(num)) return capital
      capital = num
    }
    if (typeof capital === "number") {
      if (capital >= 100000) {
        return `₹${(capital / 100000).toFixed(2)}L`
      }
      if (capital >= 1000) {
        return `₹${(capital / 1000).toFixed(2)}K`
      }
      return `₹${capital.toLocaleString("en-IN")}`
    }
    return String(capital)
  }

  // Format profit target or max loss - show "No Limit" if value is 0
  const getTagStyle = (_tag: string) => {
    // All tags (Nifty, Intraday, Live Trading, Available, etc.) use the same blue color
    return "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400"
  }


  // Format status text - show "Deployed" when status is "Active"
  const formatStatus = (status: string | undefined): string => {
    if (!status) return "Unknown"
    const statusLower = status.toLowerCase()
    if (statusLower === "active") {
      return "Deployed"
    }
    return status.charAt(0).toUpperCase() + status.slice(1).toLowerCase()
  }

  // Get deployed timestamp for a strategy
  const getDeployedTimestamp = (strategyId: number): string | null => {
    const activeStrategy = activeStrategies.find((s) => s.sid === strategyId)
    return activeStrategy?.deployedOn || null
  }

  // Format time difference (e.g., "15 minutes ago")
  const formatTimeAgo = (timestamp: string): string => {
    try {
      const deployedDate = new Date(timestamp)
      const now = new Date()
      const diffMs = now.getTime() - deployedDate.getTime()
      const diffMins = Math.floor(diffMs / 60000)
      const diffHours = Math.floor(diffMs / 3600000)
      const diffDays = Math.floor(diffMs / 86400000)

      if (diffMins < 1) {
        return "just now"
      } else if (diffMins < 60) {
        return `${diffMins} minute${diffMins !== 1 ? "s" : ""} ago`
      } else if (diffHours < 24) {
        return `${diffHours} hour${diffHours !== 1 ? "s" : ""} ago`
      } else {
        return `${diffDays} day${diffDays !== 1 ? "s" : ""} ago`
      }
    } catch (error) {
      console.error("Error formatting time:", error)
      return ""
    }
  }

  const toggleBookmark = (strategyId: number) => {
    setBookmarkedStrategies((prev) =>
      prev.includes(strategyId) ? prev.filter((id) => id !== strategyId) : [...prev, strategyId],
    )
  }

  const toggleFilter = (key: string, value: string) => {
    setFilters((prev) => {
      const current = prev[key as keyof typeof filters] as string[]
      if (value === "All") {
        // If "All" is clicked, toggle it - if it's already selected, deselect it
        if (current.includes("All")) {
          return { ...prev, [key]: [] }
        } else {
          // Select "All" and clear other selections for this category
          return { ...prev, [key]: ["All"] }
        }
      }
      // If "All" is currently selected and user selects a specific option, remove "All"
      const newArray = current.includes("All") 
        ? [value]
        : current.includes(value)
          ? current.filter((v) => v !== value)
          : [...current, value]
      return { ...prev, [key]: newArray }
    })
  }

  // Get strategy initials for icon
  const getStrategyInitials = (name: string): string => {
    const words = name.split(/\s+/)
    if (words.length >= 2) {
      return (words[0][0] + words[1][0]).toUpperCase()
    }
    return name.substring(0, 2).toUpperCase()
  }

  // Format title to replace abbreviations and control line breaks
  const formatTitle = (title: string): string => {
    let formatted = title
    
    // Keep "Delta Neutral" together, allow "Hedge" to wrap to next line
    formatted = formatted.replace(/(Delta)\s+(Neutral)\s+(Hedge)/gi, '$1\u00A0$2 $3')
    
    return formatted
  }

  // Calculate margin needed based on multiplier and strategy
  const calculateMarginNeeded = useCallback((mult: number, strategy: ReadyToDeployStrategy | null): number => {
    if (!strategy) return 0
    const baseMargin = strategy.minCapital || 0
    return baseMargin * mult
  }, [])

  // Handle multiplier change
  const handleMultiplierChange = (delta: number) => {
    setMultiplier((prev) => {
      const newMultiplier = Math.max(0, Math.min(100, prev + delta))
      if (selectedStrategy) {
        const newMargin = calculateMarginNeeded(newMultiplier, selectedStrategy)
        setMarginNeeded(newMargin)
      }
      return newMultiplier
    })
  }

  // Update margin when multiplier or strategy changes
  useEffect(() => {
    if (selectedStrategy && deployDialogOpen) {
      const calculatedMargin = calculateMarginNeeded(multiplier, selectedStrategy)
      setMarginNeeded(calculatedMargin)
    }
  }, [multiplier, selectedStrategy, deployDialogOpen, calculateMarginNeeded])

  // Handle deploy button click
  // Handle deploy submission
  const handleDeploySubmit = async () => {
    if (!selectedStrategy) return

    setDeployLoading(true)
    setDeployError(null)

    try {
      const response = await strategyService.oneClickDeploy({
        strategyId: selectedStrategy.id,
        multiplier: multiplier,
        executionTypeId: executionTypeId,
      })

      if (response.success) {
        // Success - close dialog, refresh active strategies, and refresh current tab
        setDeployDialogOpen(false)
        setSelectedStrategy(null)
        await fetchActiveStrategies() // Refresh active strategies
        // If "All" is selected, fetch all strategies, otherwise fetch current tab
        // Force refresh after deployment to get updated data
        const allSelected = Object.values(filters).some((filterArray) => filterArray.includes("All"))
        if (allSelected) {
          await fetchAllStrategies(true) // Force refresh
        } else {
          await fetchReadyToDeployStrategies(activeTab, true) // Force refresh
        }
        console.log("✅ Strategy deployed successfully:", response)
      } else {
        const errorMsg = response.error?.message || "Failed to deploy strategy"
        setDeployError(errorMsg)
      }
    } catch (err) {
      console.error("Error deploying strategy:", err)
      const errorMsg = err instanceof Error ? err.message : "An error occurred while deploying"
      setDeployError(errorMsg)
    } finally {
      setDeployLoading(false)
    }
  }

  // Handle undeploy

  // Close deploy dialog
  const handleDeployDialogClose = (open: boolean) => {
    if (!deployLoading && !open) {
      setDeployDialogOpen(false)
      setSelectedStrategy(null)
      setDeployError(null)
    }
  }

  // Handle backtest click - show consent dialog first
  const handleBacktestClick = (strategy: ReadyToDeployStrategy, e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    
    const strategyName = (strategy.name || strategy.title || "") as string
    if (!strategyName) {
      toastr.error("Error", "Strategy name not found")
      return
    }

    // Show consent dialog
    setPendingBacktestStrategy(strategyName)
    setBacktestConsentOpen(true)
  }

  // Handle consent confirmation
  const handleBacktestConsent = () => {
    if (pendingBacktestStrategy) {
      setBacktestConsentOpen(false)
      setBacktestLoading(true)
      // Navigate immediately - the page will handle loading
      navigate(`/backtest-results?strategyName=${encodeURIComponent(pendingBacktestStrategy)}`)
      setPendingBacktestStrategy(null)
    }
  }


  return (
    <main className="pt-20 pb-6">
      <div className="max-w-[1600px] mx-auto px-8 sm:px-12 lg:px-28">
        {/* Header */}
        <div className="mb-3">
          <h1 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-gray-100 mb-0.5">Discover Strategy</h1>
          <p className="text-gray-500 dark:text-gray-400 text-xs hidden sm:block">
            If the value of either Profit Target or Max Loss is set to 0, that will be considered as having no limit
            (i.e. infinite).
          </p>
        </div>

        {/* Search Bar - Above tabs on mobile, to the right on desktop */}
        <div className="mb-3 md:hidden">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500" />
            <input
              type="text"
              placeholder="Search strategies..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 dark:text-gray-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#5266FC] dark:focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Tabs and Search (Desktop) */}
        <div className="hidden md:flex items-center justify-between gap-3 mb-3">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-1 flex items-center gap-1 overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 text-sm font-medium rounded-md transition whitespace-nowrap ${
                  activeTab === tab.id ? "bg-[#5266FC] dark:bg-blue-500 text-white" : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
          <div className="relative flex-shrink-0">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500" />
            <input
              type="text"
              placeholder="Search strategies..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 dark:text-gray-100 rounded-lg text-sm w-64 focus:outline-none focus:ring-2 focus:ring-[#5266FC] dark:focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Tabs (Mobile) */}
        <div className="md:hidden mb-3">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-1 flex items-center gap-1 overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-2 text-xs sm:text-sm font-medium rounded-md transition whitespace-nowrap flex-shrink-0 ${
                  activeTab === tab.id ? "bg-[#5266FC] dark:bg-blue-500 text-white" : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Mobile Filters - Shown below tabs on mobile */}
        <div className="lg:hidden mb-4">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-3">Filter</h3>
          <div className="space-y-3">
            {filterSections.map((section) => {
              const isOpen = openFilters.has(section.key)
              return (
                <Collapsible
                  key={section.key}
                  open={isOpen}
                  onOpenChange={(open) => {
                    setOpenFilters(prev => {
                      const newSet = new Set(prev)
                      if (open) {
                        newSet.add(section.key)
                      } else {
                        newSet.delete(section.key)
                      }
                      return newSet
                    })
                  }}
                  className="bg-white dark:bg-gray-800 rounded-lg"
                >
                  <CollapsibleTrigger className="w-full flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors rounded-lg">
                    <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">{section.title}</h4>
                    {isOpen ? (
                      <ChevronUp className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                    )}
                  </CollapsibleTrigger>
                  <CollapsibleContent className="px-3 pb-3">
                    <div className="space-y-0">
                      {section.options.map((option) => (
                        <label
                          key={option}
                          className="flex items-center gap-3 cursor-pointer group py-2 border-b border-gray-100 dark:border-gray-700 last:border-b-0"
                        >
                          <input
                            type="checkbox"
                            checked={(filters[section.key as keyof typeof filters] as string[]).includes(option)}
                            onChange={() => toggleFilter(section.key, option)}
                            className="w-4 h-4 border-gray-300 dark:border-gray-600 dark:bg-gray-800 rounded-sm text-[#5266FC] dark:text-blue-400 focus:ring-[#5266FC] dark:focus:ring-blue-500"
                          />
                          <span className="text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-gray-200">{option}</span>
                        </label>
                      ))}
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              )
            })}

            {/* Underlying with Search - mobile */}
            <Collapsible
              open={openFilters.has("underlying")}
              onOpenChange={(open) => {
                setOpenFilters(prev => {
                  const newSet = new Set(prev)
                  if (open) {
                    newSet.add("underlying")
                  } else {
                    newSet.delete("underlying")
                  }
                  return newSet
                })
              }}
              className="bg-white dark:bg-gray-800 rounded-lg"
            >
              <CollapsibleTrigger className="w-full flex items-center justify-between p-3 hover:bg-gray-50 transition-colors rounded-lg">
                <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">Underlying</h4>
                {openFilters.has("underlying") ? (
                  <ChevronUp className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                )}
              </CollapsibleTrigger>
              <CollapsibleContent className="px-3 pb-3">
                <div className="relative mb-3">
                  <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="Search"
                    value={underlyingSearch}
                    onChange={(e) => setUnderlyingSearch(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 text-sm border border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-100 rounded focus:outline-none focus:border-[#5266FC] dark:focus:border-blue-500"
                  />
                </div>
                <div className="space-y-0">
                  {underlyingOptions
                    .filter((opt) => opt.toLowerCase().includes(underlyingSearch.toLowerCase()))
                    .map((option) => (
                      <label
                        key={option}
                        className="flex items-center gap-3 cursor-pointer group py-2 border-b border-gray-100 last:border-b-0"
                      >
                        <input
                          type="checkbox"
                          checked={filters.underlying.includes(option)}
                          onChange={() => toggleFilter("underlying", option)}
                          className="w-4 h-4 border-gray-300 rounded-sm text-[#5266FC] focus:ring-[#5266FC]"
                        />
                        <span className="text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-gray-200">{option}</span>
                      </label>
                    ))}
                </div>
              </CollapsibleContent>
            </Collapsible>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex flex-col lg:flex-row gap-4 lg:gap-8">
          {/* Filter Sidebar - Hidden on mobile, shown on desktop */}
          <div className="hidden lg:block w-56 flex-shrink-0">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-4">Filter</h3>

            {filterSections.map((section) => {
              const isOpen = openFilters.has(section.key)
              return (
                <Collapsible
                  key={section.key}
                  open={isOpen}
                  onOpenChange={(open) => {
                    setOpenFilters(prev => {
                      const newSet = new Set(prev)
                      if (open) {
                        newSet.add(section.key)
                      } else {
                        newSet.delete(section.key)
                      }
                      return newSet
                    })
                  }}
                  className="mb-3 bg-white dark:bg-gray-800 rounded-lg"
                >
                  <CollapsibleTrigger className="w-full flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors rounded-lg">
                    <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">{section.title}</h4>
                    {isOpen ? (
                      <ChevronUp className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                    )}
                  </CollapsibleTrigger>
                  <CollapsibleContent className="px-3 pb-3">
                    <div className="space-y-0">
                      {section.options.map((option) => (
                        <label
                          key={option}
                          className="flex items-center gap-3 cursor-pointer group py-2 border-b border-gray-100 dark:border-gray-700 last:border-b-0"
                        >
                          <input
                            type="checkbox"
                            checked={(filters[section.key as keyof typeof filters] as string[]).includes(option)}
                            onChange={() => toggleFilter(section.key, option)}
                            className="w-4 h-4 border-gray-300 dark:border-gray-600 dark:bg-gray-800 rounded-sm text-[#5266FC] dark:text-blue-400 focus:ring-[#5266FC] dark:focus:ring-blue-500"
                          />
                          <span className="text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-gray-200">{option}</span>
                        </label>
                      ))}
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              )
            })}

            {/* Underlying with Search - separate white container */}
            <Collapsible
              open={openFilters.has("underlying")}
              onOpenChange={(open) => {
                setOpenFilters(prev => {
                  const newSet = new Set(prev)
                  if (open) {
                    newSet.add("underlying")
                  } else {
                    newSet.delete("underlying")
                  }
                  return newSet
                })
              }}
              className="mb-3 bg-white dark:bg-gray-800 rounded-lg"
            >
              <CollapsibleTrigger className="w-full flex items-center justify-between p-3 hover:bg-gray-50 transition-colors rounded-lg">
                <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">Underlying</h4>
                {openFilters.has("underlying") ? (
                  <ChevronUp className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                )}
              </CollapsibleTrigger>
              <CollapsibleContent className="px-3 pb-3">
                <div className="relative mb-3">
                  <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="Search"
                    value={underlyingSearch}
                    onChange={(e) => setUnderlyingSearch(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 text-sm border border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-100 rounded focus:outline-none focus:border-[#5266FC] dark:focus:border-blue-500"
                  />
                </div>
                <div className="space-y-0">
                  {underlyingOptions
                    .filter((opt) => opt.toLowerCase().includes(underlyingSearch.toLowerCase()))
                    .map((option) => (
                      <label
                        key={option}
                        className="flex items-center gap-3 cursor-pointer group py-2 border-b border-gray-100 last:border-b-0"
                      >
                        <input
                          type="checkbox"
                          checked={filters.underlying.includes(option)}
                          onChange={() => toggleFilter("underlying", option)}
                          className="w-4 h-4 border-gray-300 rounded-sm text-[#5266FC] focus:ring-[#5266FC]"
                        />
                        <span className="text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-gray-200">{option}</span>
                      </label>
                    ))}
                </div>
              </CollapsibleContent>
            </Collapsible>
          </div>

          {/* Strategy Cards */}
          <div className="flex-1">
            {loading && (
              <div className="py-12">
                <LoadingSpinner size="lg" text="Loading strategies..." className="mb-8" />
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-3 lg:gap-3">
                  {[...Array(6)].map((_, index) => (
                    <StrategyCardSkeleton key={index} />
                  ))}
                </div>
              </div>
            )}
            
            {error && (
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3 mb-3">
                <p className="text-red-800 dark:text-red-400 text-sm">{error}</p>
              </div>
            )}

            {!loading && !error && strategies.length === 0 && getCategoryKey(activeTab) && (
              <div className="flex flex-col items-center justify-center py-12 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
                <p className="text-gray-500 dark:text-gray-400 text-base font-medium mb-2">No strategies available</p>
                <p className="text-gray-400 dark:text-gray-500 text-sm">This category doesn't have any strategies at the moment.</p>
              </div>
            )}

            {!loading && strategies.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-3 lg:gap-3 w-full">
              {strategies.map((strategy) => (
                <div
                  key={strategy.id}
                  className="flex flex-col gap-2 sm:gap-2.5 lg:gap-2.5 justify-start items-start border border-gray-200 dark:border-gray-700 rounded-sm p-4 sm:p-5 lg:p-5 bg-white dark:bg-gray-800 shadow-sm hover:shadow-md transition-shadow overflow-hidden min-w-0"
                >
                  {/* Line 1: Strategy Name */}
                  <div className="flex flex-row justify-between items-start w-full min-w-0 gap-2">
                    <div className="flex flex-col gap-1 sm:gap-1 lg:gap-1 justify-start items-start flex-1 pr-2 min-w-0">
                      <p className="text-xs sm:text-sm font-medium leading-4 sm:leading-5 text-left text-gray-900 dark:text-gray-100 break-words w-full line-clamp-1">
                        {formatTitle(String(strategy.title || strategy.name || ""))}
                      </p>
                    </div>
                    <div className="flex flex-col justify-start items-end gap-1 flex-shrink-0">
                      <div className="flex flex-row justify-end items-start gap-1.5 sm:gap-2">
                        <button
                          onClick={() => toggleBookmark(strategy.id)}
                          className={`transition ${
                            bookmarkedStrategies.includes(strategy.id)
                              ? "text-[#5266FC] dark:text-blue-400"
                              : "text-gray-400 dark:text-gray-500 hover:text-[#5266FC] dark:hover:text-blue-400"
                          }`}
                        >
                          <Bookmark
                            className="w-4 h-4 cursor-pointer"
                            fill={bookmarkedStrategies.includes(strategy.id) ? (document.documentElement.classList.contains('dark') ? "#60A5FA" : "#5266FC") : "none"}
                          />
                        </button>
                        <button 
                          onClick={() => {
                            setShareModalOpen(true)
                          }}
                          className="text-gray-400 dark:text-gray-500 hover:text-[#5266FC] dark:hover:text-blue-400 transition-colors cursor-pointer"
                        >
                          <Share2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Line 2: Tags and Last Deployed (Same Line) - Fixed Height */}
                  <div className="flex items-center w-full min-h-[28px]">
                    <div className="flex flex-row flex-wrap items-center gap-1 sm:gap-1.5 lg:gap-1.5 w-full">
                      {(() => {
                        const tagArray = Array.isArray(strategy.tags) ? strategy.tags : []
                        const hasLastDeployed = isStrategyDeployed(strategy.id) && getDeployedTimestamp(strategy.id)
                        // Limit to 2 tags when Last Deployed exists
                        const tagsToShow = hasLastDeployed ? tagArray.slice(0, 2) : tagArray
                        
                        return (
                          <>
                            {tagsToShow.map((tag: string, index: number) => {
                              // Check if this is a risk level tag (but not the hardcoded "Medium" at the end)
                              const isLastMedium = tag === "Medium" && index === tagArray.length - 1
                              const isRiskLevel = (tag === "Low" || tag === "Medium" || tag === "High") && !isLastMedium
                              return (
                                <span 
                                  key={index} 
                                  className={`text-[9px] sm:text-[10px] font-normal leading-3 text-left rounded px-1.5 sm:px-2 py-0.5 whitespace-nowrap ${
                                    isRiskLevel 
                                      ? "bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400" 
                                      : getTagStyle(tag)
                                  }`}
                                >
                                  {tag}
                                </span>
                              )
                            })}
                            {hasLastDeployed && (
                              <span className="text-[9px] sm:text-[10px] font-medium px-2.5 sm:px-3 py-0.5 rounded bg-gradient-to-r from-[#5266FC] via-[#3b9fd8] to-[#00e8b0] text-white whitespace-nowrap ml-auto">
                                Last deployed {formatTimeAgo(getDeployedTimestamp(strategy.id)!)}
                              </span>
                            )}
                          </>
                        )
                      })()}
                    </div>
                  </div>

                  {/* Lines 4-5: Description with Show more */}
                  <div className="w-full min-h-[60px]">
                    <p className="text-[10px] sm:text-xs font-normal leading-4 sm:leading-5 text-left text-gray-500 dark:text-gray-400 w-full line-clamp-2 overflow-hidden mb-2">
                      {strategy.description}
                    </p>
                    {strategy.description && strategy.description.length > 80 && (
                      <button
                        onClick={() => {
                          const title = String(strategy.title || strategy.name || "")
                          const description = String(strategy.description || "")
                          setSelectedDescription({ title: formatTitle(title), description })
                          setDescriptionModalOpen(true)
                        }}
                        className="text-[10px] sm:text-xs font-semibold text-[#5266FC] dark:text-blue-400 hover:underline cursor-pointer"
                      >
                        Show more
                      </button>
                    )}
                  </div>

                  {/* Bottom Row */}
                  <div className="flex flex-row items-end w-full mt-auto min-w-0">
                    <div className="flex flex-col justify-start items-start min-w-0 flex-1">
                      <p className="text-[8px] sm:text-[9px] font-normal leading-3 text-left text-gray-500 dark:text-gray-400 whitespace-nowrap">
                        Min Capital
                      </p>
                      <div className="flex items-baseline gap-1.5">
                        <p className="text-[11px] sm:text-xs font-medium leading-4 text-left text-gray-900 dark:text-gray-100 whitespace-nowrap">
                          {(() => {
                            // Show Non-Expiry Day capital by default
                            // If strategy has nonExpiryCapital field, use it; otherwise calculate as 70% of expiry capital
                            const expiryCapital = (strategy.minCapital || strategy.requiredCapital) as number | undefined
                            const nonExpiryCapital = (strategy as any).nonExpiryCapital || (expiryCapital ? Math.round(expiryCapital * 0.7) : undefined)
                            return formatCapital(nonExpiryCapital as number | string | undefined)
                          })()}
                        </p>
                        <span className="relative inline-block group">
                          <span className="text-[10px] sm:text-[11px] text-gray-400 dark:text-gray-500 cursor-help hover:text-[#5266FC] dark:hover:text-blue-400 transition-colors">ℹ️</span>
                          <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2.5 py-1.5 bg-gray-900 dark:bg-gray-700 text-white text-[10px] rounded whitespace-nowrap opacity-0 invisible group-hover:opacity-100 group-hover:visible pointer-events-none transition-all duration-200 z-[100]">
                            {(() => {
                              const expiryCapital = (strategy.minCapital || strategy.requiredCapital) as number | undefined
                              const nonExpiryCapital = (strategy as any).nonExpiryCapital || (expiryCapital ? Math.round(expiryCapital * 0.7) : undefined)
                              const expiryFormatted = formatCapital(expiryCapital as number | string | undefined)
                              const nonExpiryFormatted = formatCapital(nonExpiryCapital as number | string | undefined)
                              return `Expiry: ${expiryFormatted} | Non-Expiry: ${nonExpiryFormatted}`
                            })()}
                            <span className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-gray-900 dark:border-t-gray-700"></span>
                          </span>
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col justify-start items-start min-w-0 flex-1 px-2">
                      <p className="text-[8px] sm:text-[9px] font-normal leading-3 text-left text-gray-500 dark:text-gray-400 whitespace-nowrap">
                        Avg Return
                        <span className="relative inline-block ml-1 group">
                          <span className="text-[10px] sm:text-[11px] text-gray-400 dark:text-gray-500 cursor-help hover:text-[#5266FC] dark:hover:text-blue-400 transition-colors">*</span>
                          <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2.5 py-1.5 bg-gray-900 dark:bg-gray-700 text-white text-[10px] rounded whitespace-nowrap opacity-0 invisible group-hover:opacity-100 group-hover:visible pointer-events-none transition-all duration-200 z-[100]">
                            Information is based on last 3 month trades
                            <span className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-gray-900 dark:border-t-gray-700"></span>
                          </span>
                        </span>
                      </p>
                      <button
                        onClick={(e) => handleBacktestClick(strategy, e)}
                        className="text-[11px] sm:text-xs font-semibold leading-4 text-left whitespace-nowrap truncate w-full cursor-pointer hover:opacity-80 transition-opacity relative"
                        type="button"
                      >
                        <span className="relative inline-block">
                          <span 
                            className="inline-block bg-gradient-to-r from-[#4d6ff7] to-[#00e8b0] bg-clip-text text-transparent"
                            style={{
                              backgroundImage: 'linear-gradient(to right, #4d6ff7, #00e8b0)',
                              WebkitBackgroundClip: 'text',
                              WebkitTextFillColor: 'transparent',
                              backgroundClip: 'text',
                            }}
                          >
                            {String(strategy.avgReturn || "Backtest")}
                          </span>
                          <span 
                            className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[85%] h-[1.5px] bg-gradient-to-r from-[#4d6ff7] to-[#00e8b0]"
                          />
                        </span>
                      </button>
                    </div>
                    <div className="flex flex-col justify-start items-start min-w-0 flex-1">
                      <p className="text-[8px] sm:text-[9px] font-normal leading-3 text-left text-gray-500 dark:text-gray-400 whitespace-nowrap">
                        Status
                      </p>
                      {(() => {
                        const statusText = formatStatus(strategy.status || (strategy as any).strategyStatus || "Available")
                        const statusLower = statusText.toLowerCase()
                        const statusColor = statusLower === "deployed" 
                          ? "text-green-600 dark:text-green-400" 
                          : statusLower === "error" 
                          ? "text-red-600 dark:text-red-400" 
                          : "text-amber-600 dark:text-amber-400"
                        return (
                          <p className={`text-[11px] sm:text-xs font-medium leading-4 text-left ${statusColor} whitespace-nowrap truncate w-full`}>
                            {statusText}
                          </p>
                        )
                      })()}
                    </div>
                    <button 
                      onClick={() => {
                        const title = String(strategy.title || strategy.name || "")
                        const description = String(strategy.description || "")
                        navigate(`/performance?strategyId=${strategy.id}&tab=performance&from=discover`, { state: { from: "Discover Strategy", strategyTitle: formatTitle(title), strategyDescription: description } })
                      }}
                      className="w-7 h-7 sm:w-8 sm:h-8 p-1.5 bg-gradient-to-br from-[#5367fc] via-[#4d6ff7] to-[#00e8b0] rounded-sm hover:opacity-90 transition-opacity flex items-center justify-center flex-shrink-0 cursor-pointer ml-3"
                      title="View Performance"
                    >
                      <ArrowUpRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            )}

            {!loading && !getCategoryKey(activeTab) && activeTab === "bookmarked" && (
              <div className="flex items-center justify-center py-12">
                <p className="text-gray-500 dark:text-gray-400">Bookmarked strategies feature coming soon</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Deploy Strategy Dialog */}
      <Dialog open={deployDialogOpen} onOpenChange={handleDeployDialogClose}>
        <DialogContent className="sm:max-w-md p-0 gap-0 max-h-[90vh]">
          {deployError && (
            <div className="bg-red-50 dark:bg-red-900/20 border-b border-red-200 dark:border-red-800 px-6 py-3">
              <p className="text-red-800 dark:text-red-400 text-sm">{deployError}</p>
            </div>
          )}

          <div className="px-5 pt-5 pb-3">
            {/* Header with Icon and Title */}
            {selectedStrategy && (
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-full bg-[#5266FC] dark:bg-blue-500 flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-semibold text-xs">
                    {getStrategyInitials(selectedStrategy.name)}
                  </span>
                </div>
                <div>
                  <DialogTitle className="text-base font-semibold text-[#1e293b] dark:text-gray-100 mb-0">
                    {selectedStrategy.name} ({selectedStrategy.id})
                  </DialogTitle>
                </div>
              </div>
            )}

            <div className="space-y-3">
              {/* Multiplier and Execution Type - Labels on left, controls on right */}
              <div className="space-y-3">
                {/* Multiplier */}
                <div className="flex items-center justify-between gap-3">
                  <label className="text-xs font-medium text-gray-700 dark:text-gray-300">
                    Multiplier
                  </label>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleMultiplierChange(-1)}
                      disabled={deployLoading || multiplier <= 0}
                      className="w-8 h-8 flex items-center justify-center rounded border-0 bg-[#4D6FF7] dark:bg-blue-500 text-white hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={multiplier}
                      onChange={(e) => {
                        const val = parseInt(e.target.value) || 0
                        setMultiplier(Math.max(0, Math.min(100, val)))
                        if (selectedStrategy) {
                          setMarginNeeded(calculateMarginNeeded(val, selectedStrategy))
                        }
                      }}
                      className="w-12 h-8 px-1 text-center text-sm font-medium border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100 rounded focus:outline-none focus:ring-1 focus:ring-[#5266FC] dark:focus:ring-blue-500 focus:border-transparent"
                      disabled={deployLoading}
                    />
                    <button
                      type="button"
                      onClick={() => handleMultiplierChange(1)}
                      disabled={deployLoading || multiplier >= 100}
                      className="w-8 h-8 flex items-center justify-center rounded border-0 bg-[#4D6FF7] dark:bg-blue-500 text-white hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Divider Line */}
                <div className="border-t border-gray-200 dark:border-gray-700"></div>

                {/* Execution Type */}
                <div className="flex items-center justify-between gap-3">
                  <label className="text-xs font-medium text-gray-700 dark:text-gray-300">
                    Execution Type
                  </label>
                  <ToggleGroup
                    type="single"
                    value={executionTypeId === "PaperTrading" ? "PaperTrading" : "LiveTrading"}
                    onValueChange={(value) => {
                      if (value) {
                        setExecutionTypeId(value === "PaperTrading" ? "PaperTrading" : "LiveTrading")
                      }
                    }}
                    disabled={deployLoading}
                    className="bg-[#E8EAFF] dark:bg-gray-800 rounded border-0 overflow-hidden w-auto"
                  >
                    <ToggleGroupItem
                      value="PaperTrading"
                      className="h-7 px-3 data-[state=on]:bg-[#5266FC] dark:data-[state=on]:bg-blue-500 data-[state=on]:text-white data-[state=off]:bg-transparent data-[state=off]:text-[#5266FC] dark:data-[state=off]:text-blue-400 border-0 rounded-none text-xs font-medium py-0 flex flex-col items-center justify-center"
                    >
                      <span>FORWARD</span>
                      <span className="text-[9px] font-normal leading-none">Simulation Trade</span>
                    </ToggleGroupItem>
                    <ToggleGroupItem
                      value="LiveTrading"
                      className="h-7 px-3 data-[state=on]:bg-[#5266FC] dark:data-[state=on]:bg-blue-500 data-[state=on]:text-white data-[state=off]:bg-transparent data-[state=off]:text-[#5266FC] dark:data-[state=off]:text-blue-400 border-0 rounded-none text-xs font-medium py-0"
                    >
                      LIVE
                    </ToggleGroupItem>
                  </ToggleGroup>
                </div>
              </div>

              {/* Deployment Nudges */}
              {executionTypeId === "PaperTrading" && (
                <div className="mt-4 p-4 bg-[#E8EAFF] dark:bg-blue-900/20 border border-[#5266FC] dark:border-blue-500 rounded-lg flex gap-3 animate-in slide-in-from-top-2 duration-300">
                  <Info className="w-5 h-5 text-[#5266FC] dark:text-blue-400 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-[#5266FC] dark:text-blue-400 mb-1">Forward Test Mode</div>
                    <div className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                      <strong>No real money will be used</strong> and <strong>no real trades will be placed on the exchange</strong>. This is a simulation mode to test your strategy performance using historical and live market data without any financial risk.
                    </div>
                  </div>
                </div>
              )}

              {executionTypeId === "LiveTrading" && selectedStrategy && (
                <div className="mt-4 p-4 bg-[#FEF3C7] dark:bg-yellow-900/20 border border-[#F59E0B] dark:border-yellow-500 rounded-lg flex gap-3 animate-in slide-in-from-top-2 duration-300">
                  <AlertTriangle className="w-5 h-5 text-[#F59E0B] dark:text-yellow-400 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-[#92400E] dark:text-yellow-400 mb-1">Capital Requirements Vary</div>
                    <div className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed mb-3">
                      Capital requirements are different for <strong>Expiry Day</strong> and <strong>Non-Expiry Day</strong>. Please ensure you have sufficient capital available.
                    </div>
                    <div className="bg-white dark:bg-gray-800 rounded-md p-3 border border-gray-200 dark:border-gray-700">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b border-gray-200 dark:border-gray-700">
                            <th className="text-left py-2 text-gray-600 dark:text-gray-400 font-semibold">Day Type</th>
                            <th className="text-left py-2 text-gray-600 dark:text-gray-400 font-semibold">Minimum Capital Required</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-b border-gray-100 dark:border-gray-700">
                            <td className="py-2 text-gray-700 dark:text-gray-300">Expiry Day</td>
                            <td className="py-2 font-semibold text-[#5266FC] dark:text-blue-400">
                              {(() => {
                                const expiryCapital = selectedStrategy.minCapital || selectedStrategy.requiredCapital || 0
                                return expiryCapital >= 100000 
                                  ? `₹${(expiryCapital / 100000).toFixed(2)}L`
                                  : expiryCapital >= 1000
                                  ? `₹${(expiryCapital / 1000).toFixed(2)}K`
                                  : `₹${expiryCapital.toLocaleString('en-IN')}`
                              })()}
                            </td>
                          </tr>
                          <tr>
                            <td className="py-2 text-gray-700 dark:text-gray-300">Non-Expiry Day</td>
                            <td className="py-2 font-semibold text-[#5266FC] dark:text-blue-400">
                              {(() => {
                                const expiryCapital = selectedStrategy.minCapital || selectedStrategy.requiredCapital || 0
                                const nonExpiryCapital = (selectedStrategy as any).nonExpiryCapital || Math.round(expiryCapital * 0.7)
                                return nonExpiryCapital >= 100000 
                                  ? `₹${(nonExpiryCapital / 100000).toFixed(2)}L`
                                  : nonExpiryCapital >= 1000
                                  ? `₹${(nonExpiryCapital / 1000).toFixed(2)}K`
                                  : `₹${nonExpiryCapital.toLocaleString('en-IN')}`
                              })()}
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* Margin Information - Single Row */}
              <div className="flex justify-between items-center pt-3 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-600 dark:text-gray-400">Margin Needed</span>
                  <span className="text-sm text-gray-900 dark:text-gray-100">
                    {new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 }).format(marginNeeded)}
                  </span>
                </div>
                <div className="flex items-center gap-2 ml-auto">
                  <span className="text-xs text-gray-600 dark:text-gray-400">Margin Available</span>
                  <span className="text-sm text-gray-900 dark:text-gray-100">
                    {new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(marginAvailable)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Buttons - Right Side */}
          <div className="px-5 py-3 border-t border-gray-200 dark:border-gray-700 flex justify-end gap-2">
            <Button
              type="button"
              onClick={() => handleDeployDialogClose(false)}
              disabled={deployLoading}
              className="px-4 py-1.5 bg-white dark:bg-gray-800 border border-[#5266FC] dark:border-blue-500 text-[#5266FC] dark:text-blue-400 hover:bg-gray-50 dark:hover:bg-gray-700 text-xs font-medium h-8"
            >
              CANCEL
            </Button>
            <Button
              type="button"
              onClick={handleDeploySubmit}
              disabled={deployLoading || !selectedStrategy || multiplier <= 0}
              className="px-4 py-1.5 bg-gradient-to-r from-[#3B5BD9] via-[#4D6FF7] to-[#00e8b0] dark:from-blue-500 dark:via-blue-600 dark:to-blue-500 text-white hover:opacity-90 text-xs font-medium h-8"
            >
              {deployLoading ? (
                <>
                  <LoadingSpinner size="sm" className="mr-1.5" />
                  Deploying...
                </>
              ) : (
                "Deploy"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share Modal */}
      <Dialog open={shareModalOpen} onOpenChange={setShareModalOpen}>
        <DialogContent className="sm:max-w-md p-6">
          <div className="flex flex-col items-center">
            {/* Share GIF */}
            <div className="mb-4 flex justify-center">
              <img 
                src="/images/share.gif" 
                alt="Share" 
                className="w-16 h-16 object-contain"
              />
            </div>

            {/* Title */}
            <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">Share Your Strategy</h2>
            
            {/* Description */}
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center mb-4">
              Use the link below to quickly share this strategy anywhere.
            </p>

            {/* Link Input and Copy Button */}
            <div className="flex items-center gap-2 w-full mb-4">
              <input
                type="text"
                value={`https://bigul.co/bigul-algos`}
                readOnly
                className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm text-gray-700 dark:text-gray-100 bg-gray-50 dark:bg-gray-800"
              />
              <Button
                onClick={() => {
                  navigator.clipboard.writeText('https://bigul.co/bigul-algos')
                }}
                className="px-4 py-2 bg-[#5266FC] dark:bg-blue-500 hover:bg-[#3d4fc7] dark:hover:bg-blue-600 text-white rounded-lg text-sm font-medium whitespace-nowrap"
              >
                Copy
              </Button>
            </div>

            {/* Also share on */}
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">Also share on:</p>

            {/* Social Media Icons */}
            <div className="flex items-center gap-2 w-full justify-center">
              {/* Facebook */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <span className="text-white font-bold text-sm">f</span>
              </button>
              
              {/* Email */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </button>
              
              {/* X (Twitter) */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </button>
              
              {/* Instagram */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </button>
              
              {/* YouTube */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                </svg>
              </button>
              
              {/* Telegram */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                </svg>
              </button>
              
              {/* WhatsApp */}
              <button className="w-10 h-10 bg-[#5266FC] dark:bg-blue-500 rounded-lg flex items-center justify-center hover:bg-[#3d4fc7] dark:hover:bg-blue-600 transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Backtest Consent Dialog */}
      <Dialog open={backtestConsentOpen} onOpenChange={setBacktestConsentOpen}>
        <DialogContent className="sm:max-w-md p-0 gap-0">
          <div className="px-5 pt-5 pb-3">
            <DialogHeader>
              <DialogTitle className="text-base font-semibold text-[#1e293b] dark:text-gray-100 mb-0 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500 dark:text-amber-400" />
                Backtesting: Please note
              </DialogTitle>
            </DialogHeader>
            
            <div className="mt-4 space-y-2.5">
              <div className="flex items-start gap-2.5">
                <span className="text-[#5266FC] dark:text-blue-400 mt-0.5">•</span>
                <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                  Backtesting is based on historical market data and assumes ideal trading conditions.
                </p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="text-[#5266FC] dark:text-blue-400 mt-0.5">•</span>
                <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                  These results do not reflect actual trades or live market execution.
                </p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="text-[#5266FC] dark:text-blue-400 mt-0.5">•</span>
                <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                  Past performance is not indicative of future returns.
                </p>
              </div>
            </div>
          </div>

          <DialogFooter className="px-5 pb-4 pt-3 border-t border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-2 w-full">
              <Button
                variant="outline"
                onClick={() => {
                  setBacktestConsentOpen(false)
                  setPendingBacktestStrategy(null)
                }}
                className="flex-1 h-9 text-xs"
              >
                Cancel
              </Button>
              <Button
                onClick={handleBacktestConsent}
                disabled={backtestLoading}
                className="flex-1 h-9 text-xs bg-[#5266FC] hover:bg-[#4255E6] text-white disabled:opacity-50"
              >
                {backtestLoading ? (
                  <>
                    <Loader2 className="w-3 h-3 mr-1.5 animate-spin" />
                    Loading...
                  </>
                ) : (
                  "I understand. Backtest Now"
                )}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Description Modal */}
      <Dialog open={descriptionModalOpen} onOpenChange={setDescriptionModalOpen}>
        <DialogContent className="sm:max-w-lg max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              {selectedDescription?.title || "Strategy Description"}
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto px-1">
            <DialogDescription asChild>
              <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed whitespace-pre-wrap">
                {selectedDescription?.description || ""}
              </p>
            </DialogDescription>
          </div>
          <DialogFooter>
            <Button
              onClick={() => setDescriptionModalOpen(false)}
              className="bg-[#5266FC] hover:bg-[#4255E6] text-white"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  )
}
